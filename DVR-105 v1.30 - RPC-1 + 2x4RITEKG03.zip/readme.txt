Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.30
Patch:			RPC-1 (Region Free) + 2x speed for RITEKG03
Date:			2003.03.28 - 00:39
Author:			Gradius
Release Notes:		This firmware will allow you to burn RITEKG03 DVD-R
			media at 2x (but removes 2x speed for TAIYOYUDEN)
Flashing Instructions:	Run the .BAT file. For more detailled instructions:
			http://forum.rpc1.org/viewtopic.php?t=12632
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
