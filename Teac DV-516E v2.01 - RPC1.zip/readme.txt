TEAC DV-516E RPC-1 firmware

Author: 	>NIL:
Date:		2003.05.11 23:03 GMT
Notes:		This firmware will turn your drive into a region free (RPC-1) drive.
		The DV-516E is actually a Pioneer DVD-118 (or DVD-500M)
		This firmware will not apply on a Teac DV-516EA (the 256KB 
		buffer version of the 516E)
Flashing inst:	You need to use MTKFlash. Please follow the instructions at:
		http://forum.rpc1.org/viewtopic.php?p=37395#37395
		DON'T MAIL ME ON HOW TO FLASH - I WON'T REPLY! Use the forum instead.
Useful Links:	http://pioneerdvd.rpc1.org
		http://forum.rpc1.org
