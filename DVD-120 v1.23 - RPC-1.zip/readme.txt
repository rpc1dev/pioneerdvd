Drive:			Pioneer DVD-120
Firmware Rev.:		v1.23
Patch:			RPC-1 (Region Free)
Date:			2003.06.12 - 01:26 GMT
Author:			>NIL:
Release Notes:		This firmare WILL NOT APPLY to the DVD-120S 
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Open a DOS window and type the command:     
			UPGDVD /F atpio123.hex
			You don't need to downgrade if you run in Windows ;)
Useful Links:		http://forum.rpc1.org/
			http://pioneerdvd.rpc1.org/
