DVD-K11TA - RPC-1 ;)   **** UNTESTED *****
by >NIL: - 2001.09.30 

Upgrade procedure is as the following.

1. DVD-K11TA connect to Secondary IDE channel with master configuration.
2. Boot the PC with MS-DOS mode.
(Attention ! : Upgarade utility cannot work on MS-DOS window.)
3. Execute up.bat

This Floppy Disk includes the following files.

K11F103.HEX (Firmware file)
UPG4.EXE (Upgrade Utility)
UP.BAT (Upgrade Batch File)
README.TXT (This File)
