Firmware Upgrade Instructions(DVD-304S/DVD-U04S) 1.04 RPC-1 ;)



If you are not experiencing problems with your DVD-ROM drive, 
there is no need to upgrade your firmware.  For more information 
about what firmware revision your drive contains, look in the 
Device Manager in Windows 95/98.  To access the Device Manager,
click the start button, settings, control panel, system.  Click on 
the tab "Device Manager".  Click on the "+" next to the CD-ROM 
icon.  Click on the appropriate Pioneer DVD-ROM drive you wish to 
update, then click the "Properties" tab.  Next click on the tab 
"settings".  On this tab is located the current firmware revision 
of this drive.

Steps to take before update process:
-Make sure the target DVD-ROM drive is free of any disc.
-Set the drive ID to 0 via the jumper pin on the rear of the 
drive.
-Disable SCAM, Reconnect, and synchronous transfer on your SCSI 
card

-Because this update prgram uses ASPI manager, add a command line 
that enables ASPI manger into the CONFIG.SYS, if it is not already
included.  Consult your SCSI card's user's manual for further 
explanation.
(Example of how to add ASPI manger to CONFIG.SYS for Adaptec 
AHA-2940)
	In Windows 95/98, open CONFIG.SYS with an editor, such as 
	"Notepad" and type in the command line:
	DEVICE=C:\ASPI8DOS.SYS /D
	After entering the command line, save, then exit
* Please use caution when making changes to the CONFIG.SYS.  Back 
up the information contained within the CONFIG.SYS before 
attempting any changes.
* The file CONFIG.SYS is located at C:\.
* If running a pure Windows NT environment, use an MS-DOS 6.0 or 
later/Windows 95 or 98 Startup Disk


1.  Download the appropriate zip file for the target DVD-ROM drive
Recommended save locations are C:\ or A:\. (Because Directory 
names morethan 8 characters are truncated in MS-DOS, it is 
recommended the name of the directory to which the zip file is 
saved be no longer than 8 characters)

2.  Unzip the zip file.  Extract the unzipped files either to your
Hard disk drive or flopy disk drive.

Confirm the following files have been unzipped:
	VersionUp program	UPG4S.EXE
	Firmware file		G4SSxxxF.HEX(xxx's refer to the 
				firmware revision)

3.  Enter MS-DOS 6.0 or later/Windows 95/98 MS-DOS mode.(A Windows 
95/98 MS-DOS Window will not work properly)
	How to enter MS-DOS mode(in Windows 95/98)
	Click the start button, shut down, restart in MS-DOS mode,
	then OK.  If running a pure Windows NT environment, use 
	a DOS 6.0 or later/Windows95/98 startup disk.

4.  Move to the directory to which the zip files were extracted.
If the files are located at C:\, type "C:\" and press the ENTER 
key, then type "cd \" and press the ENTER key.
You should now be at C:\

If the files are located at A:\, insert the floppy disk with the 
unzipped files into your system and type "A:\" and press the ENTER 
key, then type "cd \" and press the ENTER key.
You should now be at A:\

Firmware update command
Type the following and press the ENTER key at the end.
UPG4S /0 G4SSxxxF.HEX
   -In the xxx's, type the exact .HEX filename as the one 
    downloaded.

Example:  Downloaded .HEX filename:  G4SS104.HEX
	  Command:  UPG4S /0 G4SS104F.HEX
	(*CAUTION-This example has the drive set for SCSI ID = 0)

The update process shall begin.  This may take a few minutes.
DO NOT operate your PC in any way(clicking the mouse buttons, 
typing on the keyboard, etc.) or turn off the power on your system
during the update process.
If the upgrade process is interrupted mid-transfer, it may result 
in an inoperable drive.

5.  After the process is completed, you shall be notified of a 
firmware revision.  Make certain this is the firmware revision 
you intended to use.

6. After this process has been completed, shut down your PC, then
turn the power supply of your system OFF before using it again.

It is highly recommended to use an Adaptec brand SCSI board, ASPI 
manager, and setting the DVD-304S/U04S SCSI ID = 0 when changing 
the firmware revision.