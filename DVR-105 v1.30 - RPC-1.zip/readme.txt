Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.30
Patch:			RPC-1 (Region Free) ONLY
Date:			2003.03.28 - 00:30 GMT
Author:			>NIL:
Release Notes:		This firmware has been tested and works ;�
Flashing Instructions:	Run the .BAT file
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		FLASHMAN, Gradius and zaitec2! ;)
