ATAPI DVD-105S, DVD-A05S REGION FREE FIRMWARE
This upgrade should NOT be applied to any other model DVD-ROM drive.
This upgrade improves the playability increment and decreases vibration within the drive.

Files:
105f_133.hex  : Firmware Version 1.33 (RPC-1 :�)
upg5a.exe     : Upgrade Utility program
up105.bat     : Batch program to execute the upgrade.

PROCEDURE:
1. Connect Pioneer DVD-ROM drive on the Secondary IDE Port with the drive set as Master.
    Turn ON the PC.
2. If Windows 95/98 is used, quit Windows mode and re-boot into MS-DOS mode by selecting the Start menu on Windows 95/98.
3. Make sure there is no disc in the drive unit  before the  firmware upgrade is executed.
4. Execute the UP105.BAT file.
5. The current version number of the firmware will be shown and the new firmware will be uploaded.
6. When the DOS prompt returns reboot the computer by powering OFF then ON.

Do not turn OFF the PC while upgrade is executed or the firmware upgrade will fail. Retry upgrade procedure from 4 through 6 if the firmware upgrade is fails.
Apply power cycle (OFF/ON) if the firmware upgrade fails.

IMPORTANT:
The upgrade will not function and permanent failure of the drive could occur unless the drive is connected as per point 1.
PLEASE READ THE dvd-rom_atapi_up.txt BEFORE UPGRADING THE FIRMWARE

NOTE:
This RPC-1 firmware is NOT supported by Pioneer.
For additional information on this patch, read the .nfo file.