Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.33
Patch:			RPC-1 (Region Free) + 2xDVD-R + 12xRip (pressed DVDs)
Date:			2003.06.14 - 19:52 GMT
Authors:		Gradius, >NIL:
Release Notes:		This is the release version of the 2x4all DVD-R 
			including the anti 2x Rip Speed patch ;)
			The 2xDVD-R patch DOES NOT change the burning strategy 
			for Pioneer 2x authorized media.
			PROPER BURN OF 2X NON AUTHORIZED MEDIA IS NOT GUARANTEED!
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Then run UPGRADE.BAT.
			You don't need to downgrade if you run in Windows ;)
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		Flash, Depl0y, zaitec2
