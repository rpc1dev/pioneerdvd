Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.30
Patch:			RPC-1 (Region Free) + 2xDVD-R + 12xRip
Date:			2003.04.07 - 23:35 GMT
Authors:		zaitec2, >NIL: & Gradius for the write strategy
Release Notes:		This is the release version of the 2x4all DVD-R 
			including the anti 2x Rip Speed patch ;)
			The 2xDVD-R patch DOES NOT affect the burning process 
			for media media that already burned at 2x.
			The 2xDVD-R enables burning non 2x DVD-R's at 2x BUT
			PROPER BURN IS NOT GUARANTEED! It depends on the media
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Then run UPGRADE.BAT. This should run fine
			on Japanese systems as well. For more info:
			http://forum.rpc1.org/viewtopic.php?t=12632
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		Flash, Depl0y and everybody who contributes to the 
			R/RW section of the forum
