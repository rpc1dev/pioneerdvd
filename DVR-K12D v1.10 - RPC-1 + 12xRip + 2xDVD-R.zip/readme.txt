Drive:			Pioneer DVR-K12 (Slim DVD+/- Burner), Sony rebadged version
Also known as:		DVR-SK12D
Firmware Rev.:		v1.10
Author:			>NIL:
Date:			2004.04.04 - 23:39 GMT
Patched:		o RPC-1 (Region Free):
			  Remember, patching your drive to region free is only half
			  the job. A region free drive will not turn your system 
			  region free by itself. For more info, please read
			  http://forum.rpc1.org/viewtopic.php?t=239
			o 12xRip (Unlimited ripping speed):
			  The official firmware from Pioneer limits the ripping 
			  speed on video discs. This limitation has been removed.
			  12x is only the maximum THEORETICAL speed that the drive
			  can achieve, but not the sustained speed you are likely to
			  get when ripping. Most DVD's will start ripping around 2x 
			  to 4x and end up around 8x or 10x. THIS is normal.
			o 2x4all DVD-R (2x burning for all DVD-R media):
			  This firmware allows you to select 2x burning speed on all
			  DVD-R media. The official firmware from Pioneer only allows
			  a limited set of Pioneer approved media to use these 
			  specific speeds but this patch removes that limitation.
			  The write strategies for approved media are left unchanged.
			  PROPER BURN OF NON APPROVED MEDIA IS NOT GUARANTEED!
Release Notes:		Since Pioneer did not release any firmware for this drive, 
			the Sony re-badged version of the firmware was used. 
			Don't be surprised if your Pioneer drive seems to become a
			Sony then.
Flashing Instructions:	1/ Download the latest version of DVRFlash from
			http://pioneerdvd.rpc1.org and extract the executable you 
			need (Windows, DOS or Linux) in the directory where you 
			extracted the patched firmwares
			2/ READ THE DVRFLASH INSTRUCTIONS!!!
			3/ If you are flashing from windows, and I: is your DVR-K12
			drive, open a DOS window and type a command like:
			  DVRFlash -v I: S2127052.110 S2127152.110
			*** MAKE SURE YOU USE UPPERCASE FOR THE DRIVE LETTER ***
Useful Links:		http://forum.rpc1.org/  	(DVD-R/RAM/+RW section)
			http://pioneerdvd.rpc1.org/
Thanks to:		Flash, Agent Smith and all the rpc1.org crew + supporters ;)