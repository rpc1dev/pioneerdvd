Drive:			Pioneer DVD-120S
Firmware Rev.:		v1.01
Patch:			RPC-1 (Region Free)
Date:			2003.08.21 - 00:06 GMT
Author:			>NIL:
Release Notes:		This firmare applies to the DVD-120S only, NOT THE DVD-120!!! 
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Open a DOS window and type the command:     
			UPGDVD /F aspi101.hex
			You don't need to downgrade if you run in Windows ;)
Useful Links:		http://forum.rpc1.org/
			http://pioneerdvd.rpc1.org/
