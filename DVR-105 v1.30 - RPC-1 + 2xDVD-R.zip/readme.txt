Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.30
Patch:			RPC-1 (Region Free) + 2xR (2x for all DVD-R's)
Date:			2003.04.06 - 12:28 GMT
Author:			>NIL:
Release Notes:		This is the release version of the 2x4all DVD-R
			Note that it is SAFE to use this firmware, unlike the 
			4xDVD-R/2xDVD-RW one
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Then run UPGRADE.BAT. For more info:
			http://forum.rpc1.org/viewtopic.php?t=12632
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		Gradius, Flash, Depl0y, zaitec2, etc.
