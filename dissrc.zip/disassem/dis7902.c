/*

Program orignally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

*/

// Modifications:
// 26 jul 2001: added some $xxxxxxxx,X mangled output
// 20 may 2001: added DPR1-3 handling for direct mode adressing
// 20 may 2001: corrected JMP/JSR ABS
// 20 may 2001: corrected PHT
// 20 may 2001: corrected LDX/Y abs,X
// 24 may 2001: minor correction to MVP/MVN

// This disassembler was not yet fully checked. I'm pretty sure it will output some badly
// disassembled instructions. More debugging is needed.

// The assembly encoding understood by the processor depends on the x and m
// flags, Yes, the binary format of the instructions depends on some flags, yuk!
// I have provided no real way to handle it properly (is there one, anyway?)
// You may define FORCEXM to force x and m to default values.
// If FORCEXM is not defined, this program provides a minimal way to track
// x and m changes. It assumes that the flags default to 0 and are explicitly set
// before instructions that depends on it. (You may invert the defaults with DEFAULTm/x).
// Currently, this seems to be ok with the firmwares I work on.

#include <stdlib.h>
#include <stdio.h>

unsigned long OFFSET;		// real-life address of rom[0];

//#define FORCEXM
#define DEFAULTm 0
#define DEFAULTx 0

char m=DEFAULTm;
char x=DEFAULTx;

unsigned char rom[1024*1024+16];

unsigned long pc,oldpc;
unsigned char op,oph,opl;
char operationb[256];
char operandb[1024];
char *operation;
char *operand;
char rupt;

char *pulreg[8]={"A","B","X","Y","DPR0","DT","PG","PS"};
char *flags[8]={"C","Z","I","D","x","m","V","N"};
char cond[16][8]={"??","PL","RA","MI",
		 		  "GTU","VC","LEU","VS",
				  "GT","CC","LE","CS",
				  "GE","NE","LT","EQ" };
char *M8;
char m8;
short MULTIDPR;

#define DPR(x) (MULTIDPR ? (((x)>>6)&3) : 0), (MULTIDPR ? ((x)&0x3F):(x))

char *imm816()
{
static char c[64];
unsigned short x;

if (m==0)
	{
	x = rom[pc++];
	x += 256*rom[pc++];
	sprintf(c,"$%04hX",x);
	} else
	{
	sprintf(c,"$%02hX",rom[pc++]);
	}
return c;
}


char *imx816()
{
static char c[64];
unsigned short y;

if (x==0)
	{
	y = rom[pc++];
	y += 256*rom[pc++];
	sprintf(c,"$%04hX",y);
	} else
	{
	sprintf(c,"$%02hX",rom[pc++]);
	}
return c;
}


unsigned long sext8(unsigned char x8)
{
return (signed char) x8;
}


unsigned long sext16(unsigned short x16)
{
return (signed short) x16;
}


void table1(void)
{
unsigned char op;
unsigned short oph,opl;
char *op1[4]={"ADDX","ADDY","SUBX","SUBY"};
char *op2[3]={"BSS","??","BSC"};
char *op3[2]={"DXBNE","DYBNE"};

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch(oph)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		operation=op1[oph/2];
		sprintf(operand,"#$%02hX",(oph&1)*16+opl);
		pc+=2;
		break;
	case 0x8:
	case 0xa:
		operation=op2[oph-8];
		sprintf(operand,"A,#$%1hX,$%08lX",opl,OFFSET+pc+3+sext8(rom[pc+2]));
		pc+=3;
		break;
	case 0x9:
		break;
	case 0xb:
		break;
	case 0xc:
	case 0xd:
	case 0xe:
	case 0xf:
		operation=op3[(oph-0xc)/2];
		sprintf(operand,"#$%02hX,$%08lX",(oph&1)*16+opl,OFFSET+pc+3+sext8(rom[pc+2]));
		pc+=3;
		break;
	}
}


void table2(void)
{
unsigned char op,oph,opl;
char *op1[15]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","LDAD","ADDD","SUBD","CMPD","STAB","STA","STAD"};
char *reg[2]={"A","E"};
char r;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;

if (oph==0xf) return;
switch(opl)
	{
	case 0x5:
	case 0x7:
	case 0xa:
	case 0xb:
	case 0xe:
	case 0xf:
		return;
		break;
	}
if (opl >7)
	{
	switch(oph)
		{
		case 0x0:
		case 0x1:
		case 0x8:
		case 0xc:
		case 0xd:
		case 0xe:
			return;
			break;
		}
	}
switch(oph)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
	case 0xc:
	case 0xd:
		r=0;
		break;
	default:
		r=1;
		break;
	}
operation=op1[oph];
switch(opl)
	{
	case 0x0:
		sprintf(operand,"%s,(DPR%d+$%02hX)",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x1:
		sprintf(operand,"%s,(DPR%d+$%02hX,X)",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x2:
		sprintf(operand,"%s,L(DPR%d+$%02hX)",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x3:
		sprintf(operand,"%s,DPR%d+$%02hX,S",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x4:
		sprintf(operand,"%s,(DPR%d+$%02hX,S),Y",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x6:
		sprintf(operand,"%s,$%02hX%02hX,Y",reg[r],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x8:
		sprintf(operand,"%s,(DPR%d+$%02hX),Y",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x9:
		sprintf(operand,"%s,L(DPR%d+$%02hX),Y",reg[r],DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0xc:
		sprintf(operand,"%s,$%02hX%02hX%02hX",reg[r],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=5;
		break;
	case 0xd:
		sprintf(operand,"%s,$%02hX%02hX%02hX,X",reg[r],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=5;
		break;
	}
}


void table3(int ab)
{
unsigned char op,oph,opl;
char *dst;
char *op1[16]={"ASL","ROL","LSR","ROR","ASR","??","??","??","ADC","ADCD","SBC","SBCD","MPY","MPYS","DIV","DIVS"};

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;

if ( (oph==0x5) || (oph==0x6) || (oph==0x7) )  return;
if ( (opl==0x5) || (opl==0x7) )  return;
if (ab)
	{
	if ( (oph!=0x8) && (oph!=0xa) ) return;
	}
if (oph<8)
	{
	if (opl < 0xa) return;
	if (opl == 0xc) return;
	if (opl == 0xd) return;
	}
operation = op1[oph];
dst = ab ? "B,":"A,";
if ((oph==0x9) || (oph==0xb)) dst="E,";
switch(opl)
	{
	case 0x0:
		sprintf(operand, "%s(DPR%d+$%02hX)",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x1:
		sprintf(operand, "%s(DPR%d+$%02hX,X)",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x2:
		sprintf(operand, "%sL(DPR%d+$%02hX)",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x3:
		sprintf(operand, "%s$%02hX,S",dst,(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x4:
		sprintf(operand, "%s($%02hX,S),Y",dst,(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x5:
		break;
	case 0x6:
		sprintf(operand, "%s$%02hX%02hX,Y",dst,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x7:
		break;
	case 0x8:
		sprintf(operand, "%s(DPR%d+$%02hX),Y",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x9:
		sprintf(operand, "%sL(DPR%d+$%02hX),Y",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0xa:
		sprintf(operand, "%sDPR%d+$%02hX",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0xb:
		sprintf(operand, "%sDPR%d+$%02hX,X",dst,DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0xc:
		sprintf(operand, "%s$%02hX%02hX%02hX",dst,(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=5;
		break;
	case 0xd:
		sprintf(operand, "%s$%02hX%02hX%02hX,X",dst,(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=5;
		break;
	case 0xe:
		sprintf(operand, "%s$%02hX%02hX",dst,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0xf:
		sprintf(operand, "%s$%02hX%02hX,X",dst,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	}
}


void table4(int ab)
{
unsigned char op,opl,oph;
char *dst1;
char *z;
char *op1[4]={"MPY","MPYS","DIV","DIVS"};
unsigned short rel;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;

dst1 = ab ? "B":"A";

switch(op)
	{
	case 0x10:
		if (ab) return;
		operation = "WIT";
		pc+=2;
		break;
	case 0x30:
		if (ab) return;
		operation = "STP";
		pc+=2;
		break;
	case 0x40:
		if (ab) return;
		operation = "PHT";
		pc+=2;
		break;
	case 0x50:
		if (ab) return;
		operation = "PLT";
		pc+=2;
		break;
	case 0x60:
		if (ab) return;
		operation = "PHG";
		pc+=2;
		break;
	case 0x70:
		if (ab) return;
		operation = "TSD";
		pc+=2;
		break;
	case 0x80:
		if (ab) return;
		operation = "NEGD";
		operand = "E";
		pc+=2;
		break;
	case 0x90:
		if (ab) return;
		operation = "ABSD";
		operand = "E";
		pc+=2;
		break;
	case 0xa0:
		if (ab) return;
		operation = "EXTZD";
		operand = "E";
		pc+=2;
		break;
	case 0xb0:
		if (ab) return;
		operation = "EXTSD";
		operand = "E";
		pc+=2;
		break;
	case 0x02:
	case 0x12:
	case 0x22:
	case 0x32:
		sprintf(operation,"T%sD",dst1);
		sprintf(operand,"%d",oph & 0x3);
		pc+=2;
		break;
	case 0x42:
	case 0x52:
	case 0x62:
	case 0x72:
		sprintf(operation,"TD%s",dst1);
		sprintf(operand,"%d",oph & 0x3);
		pc+=2;
		break;
	case 0x82:
		if (ab) return;
		operation = "TAS";
		pc+=2;
		break;
	case 0x92:
		if (ab) return;
		operation = "TSA";
		pc+=2;
		break;
	case 0xc2:
		if (ab) return;
		operation = "TXY";
		pc+=2;
		break;
	case 0xd2:
		if (ab) return;
		operation = "TYX";
		pc+=2;
		break;
	case 0xe2:
		if (ab) return;
		operation = "TXS";
		pc+=2;
		break;
	case 0xf2:
		if (ab) return;
		operation = "TSX";
		pc+=2;
		break;
	case 0x73:
		if (ab) return;
		operation = "TDS";
		pc+=2;
		break;
	case 0x07:
		if (ab) return;
		operation = "RLA";
		pc += 2;
		z = imm816();
		sprintf(operand,"A,%s",z);
		break;
	case 0x47:
		if (ab) return;
		operation = "MOVM";
		pc += 2;
		z = imm816();
		sprintf(operand,"DPR%d+$%02hX,X,#%s",DPR((unsigned short) rom[pc]),z);
		pc++;
		break;
	case 0x57:
		if (ab) return;
		operation = "MOVM";
		pc += 2;
		z = imm816();
		sprintf(operand,"$%02hX%02hX,X,#%s",(unsigned short) rom[pc+1],(unsigned short) rom[pc],z);
		pc += 2;
		break;
	case 0x87:
		operation = "ADC";
		pc += 2;
		z = imm816();
		sprintf(operand,"%s,#%s",dst1,z);
		break;
	case 0xa7:
		operation = "SBC";
		pc += 2;
		z = imm816();
		sprintf(operand,"%s,#%s",dst1,z);
		break;
	case 0xc7:
	case 0xd7:
	case 0xe7:
	case 0xf7:
		if (ab) return;
		operation = op1[oph-0xc];
		pc += 2;
		z = imm816();
		sprintf(operand,"#%s",z);
		break;
	case 0x0a:
		if (ab) return;
		operation="ADDS";
		sprintf(operand,"#$%02hX",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x0b:
		if (ab) return;
		operation="SUBS";
		sprintf(operand,"#$%02hX",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x1a:
		operation="ADCB";
		sprintf(operand,"%s,#$%02hX",dst1,(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x1b:
		operation="SBCB";
		sprintf(operand,"%s,#$%02hX",dst1,(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x1c:
		if (ab) return;
		operation="ADCD";
		sprintf(operand,"E,#$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+5],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=6;
		break;
	case 0x1d:
		if (ab) return;
		operation="SBCD";
		sprintf(operand,"E,#$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+5],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=6;
		break;
	case 0x2b:
		if (ab) return;
		operation="MVP";
		sprintf(operand,"$%02hX,$%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x2c:
		if (ab) return;
		operation="MVN";
		sprintf(operand,"$%02hX,$%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x3a:
		if (ab) return;
		operation="MOVMB";
		sprintf(operand,"DPR%d+$%02hX,X,#$%02hX",DPR((unsigned short) rom[pc+3]),(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x3b:
		if (ab) return;
		operation="MOVMB";
		sprintf(operand,"$%02hX%02hX,X,#$%02hX",(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=5;
		break;
	case 0x4a:
		if (ab) return;
		operation="LDT";
		sprintf(operand,"#$%02hX",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x5a:
		if (ab) return;
		operation="RMPA";
		sprintf(operand,"#$%02hX",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x4b:
		if (ab) return;
		operation="PEI";
		sprintf(operand,"DPR%d+$%02hX",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x4c:
		if (ab) return;
		operation="PEA";
		sprintf(operand,"$%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x4d:
		if (ab) return;
		operation="PEA";	// documentation says unsigned disp, strange?
		rel = rom[pc+2] & 0xff;
		rel += (rom[pc+3] & 0xFF)*256;
		//sprintf(operand,"$%08lX",OFFSET+pc+4+sext16(rel));
		sprintf(operand,"$%08lX",OFFSET+pc+4+rel);
		pc+=4;
		break;
	case 0x5c:
		if (ab) return;
		operation="JMP";
		sprintf(operand,"($%02hX%02hX)",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x5d:
		if (ab) return;
		operation="JMPL";
		sprintf(operand,"L($%02hX%02hX)",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	}
}


void table5(void)
{
unsigned char op,opl,oph,dd;
unsigned short abs;
char *z;
signed char rel8;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch (op)
	{
	case 0x05:
	case 0x1b:
	case 0xe5:
	case 0xfb:
		sprintf(operation,"%s%s",(oph<8)?"LD":"ST",(opl<8)?"X":"Y");
		sprintf(operand,"DPR%d+$%02hX,%s",DPR((unsigned short) rom[pc+2]),(opl<8)?"Y":"X");
		pc+=3;
		break;
	case 0x06:
	case 0x1f:
		sprintf(operation,"LD%s",(opl<8)?"X":"Y");
		sprintf(operand,"$%02hX%02hX,%s",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(opl<8)?"Y":"X");
		pc+=4;
		break;
	case 0x8b:
	case 0x9b:
		sprintf(operation,"%s",(oph==8)?"INC":"DEC");
		sprintf(operand,"DPR%d+$%02hX,X",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x8f:
	case 0x9f:
		sprintf(operation,"%s",(oph==8)?"INC":"DEC");
		sprintf(operand,"$%02hX%02hX,X",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x2e:
	case 0x3e:
		sprintf(operation,"CP%s",(oph==2)?"X":"Y");
		sprintf(operand,"DPR%d+$%02hX",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x4a:
	case 0x5a:
		sprintf(operation,"%s",(oph==4)?"BBS":"BBC");
		dd=rom[pc+2];
		pc+=3;
		z=imm816();
		rel8=rom[pc++];
		sprintf(operand,"#%s,DPR%d+$%02hX,%08lX",z,DPR((unsigned short) dd),OFFSET+pc+sext8(rel8));
		break;
	case 0x4e:
	case 0x5e:
		sprintf(operation,"%s",(oph==4)?"BBS":"BBC");
		abs=rom[pc+2]+rom[pc+3]*256;
		pc+=4;
		z=imm816();
		rel8=rom[pc++];
		sprintf(operand,"#%s,$%04hX,%08lX",z,abs,OFFSET+pc+sext8(rel8));
		break;
	case 0x6a:
	case 0x7a:
		sprintf(operation,"%s",(oph==6)?"CBEQ":"CBNE");
		dd=rom[pc+2];
		pc+=3;
		z=imm816();
		rel8=rom[pc++];
		sprintf(operand,"DPR%d+$%02hX,#%s,%08lX",DPR((unsigned short) dd),z,OFFSET+pc+sext8(rel8));
		break;
	}
}


void table6(void)
{
unsigned char op,opl,oph,dd;
unsigned short abs;
char *z;
char *op1[8]={"ADDM","SUBM","CMPM","ORAM","??","??","ANDM","EORM"};

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch (op)
	{
	case 0x02:
	case 0x12:
	case 0x22:
	case 0x32:
	case 0x62:
	case 0x72:
		sprintf(operation,"%sB",op1[oph]);
		sprintf(operand,"DPR%d+$%02hX,#$%02hX",DPR((unsigned short) rom[pc+2]),(unsigned short) rom[pc+3]);
		pc+=4;
		break;
	case 0x06:
	case 0x16:
	case 0x26:
	case 0x36:
	case 0x66:
	case 0x76:
		sprintf(operation,"%sB",op1[oph]);
		sprintf(operand,"$%02hX%02hX,#$%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+4]);
		pc+=5;
		break;
	case 0x03:
	case 0x13:
	case 0x23:
	case 0x33:
	case 0x63:
	case 0x73:
		operation=op1[oph];
		dd=rom[pc+2];
		pc+=3;
		z=imm816();
		sprintf(operand,"DPR%d+$%02hX,#%s",DPR((unsigned short) dd),z);
		break;
	case 0x07:
	case 0x17:
	case 0x27:
	case 0x37:
	case 0x67:
	case 0x77:
		operation=op1[oph];
		abs=rom[pc+2]+256*rom[pc+3];
		pc+=4;
		z=imm816();
		sprintf(operand,"$%04hX,#%s",abs,z);
		break;
	case 0x83:
	case 0x93:
	case 0xa3:
	case 0xb3:
	case 0xe3:
	case 0xf3:
		sprintf(operation,"%sD",op1[oph & 7]);
		sprintf(operand,"DPR%d+$%02hX,#$%02hX%02hX%02hX%02hX",DPR((unsigned short) rom[pc+2]),(unsigned short) rom[pc+6],(unsigned short) rom[pc+5],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3]);
		pc+=7;
		break;
	case 0x87:
	case 0x97:
	case 0xa7:
	case 0xb7:
	case 0xe7:
	case 0xf7:
		sprintf(operation,"%sD",op1[oph &7]);
		sprintf(operand,"$%02hX%02hX,#$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+7],(unsigned short) rom[pc+6],(unsigned short) rom[pc+5],(unsigned short) rom[pc+4]);
		pc+=8;
		break;
	}
}


void table7(void)
{
unsigned char op,opl,oph,dd;
int i;
char str[1024];
char *z;
unsigned short abs;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch(oph)
	{
	case 0x0:
		operation="MOVRB";
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", $%02hX,#$%02hX",(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
			pc+=2;
			strcat(operand,str);
			}
		break;
	case 0x1:
		operation="MOVR";
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			z=imm816();
			dd=rom[pc++];
			sprintf(str,", DPR%d+$%02hX,#%s",DPR((unsigned short) dd),z);
			strcat(operand,str);
			}
		break;
	case 0x2:
		operation="MOVRB";
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", $%02hX%02hX,#$%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
			pc+=3;
			strcat(operand,str);
			}
		break;
	case 0x3:
		operation="MOVR";
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			z=imm816();
			abs=rom[pc]+256*rom[pc+1];
			pc+=2;
			sprintf(str,", $%04hX,#%s",abs,z);
			strcat(operand,str);
			}
		break;
	case 0x4:
	case 0x5:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", DPR%d+$%02hX,DPR%d+$%02hX",DPR((unsigned short) rom[pc+1]),DPR((unsigned short) rom[pc]));
			pc+=2;
			strcat(operand,str);
			}
		break;
	case 0x6:
	case 0x7:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", $%02hX%02hX,DPR%d+$%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1],DPR((unsigned short) rom[pc]));
			pc+=3;
			strcat(operand,str);
			}
		break;
	case 0x8:
	case 0x9:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", DPR%d+$%02hX,$%02hX%02hX",DPR((unsigned short) rom[pc+2]),(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
			pc+=3;
			strcat(operand,str);
			}
		break;
	case 0xa:
	case 0xb:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", $%02hX%02hX,$%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
			pc+=4;
			strcat(operand,str);
			}
		break;
	}
}


void table8(void)
{
unsigned char op,opl,oph;
int i;
char str[1024];

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch(oph)
	{
	case 0x0:
	case 0x1:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", DPR%d+$%02hX,$%02hX%02hX,X",DPR((unsigned short) rom[pc+2]),(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
			pc+=3;
			strcat(operand,str);
			}
		break;
	case 0x6:
	case 0x7:
		sprintf(operation,"MOVR%s",(oph&1)?"":"B");
		pc+=2;
		sprintf(operand,"%d",opl);
		for (i=0; i<opl; i++)
			{
			sprintf(str,", $%02hX%02hX,DPR%d+$%02hX,X",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1],DPR((unsigned short) rom[pc]));
			pc+=3;
			strcat(operand,str);
			}
		break;
	case 0x8:
	case 0xa:
		operation=(oph==0x8)?"BSS":"BSC";
		sprintf(operand,"%1hx,DPR%d+$%02hX,%08lX",(unsigned short) opl,DPR((unsigned short) rom[pc+2]),OFFSET+pc+4+sext8(rom[pc+3]));
		pc+=4;
		break;
	case 0xc:
	case 0xe:
		operation=(oph==0xc)?"BSS":"BSC";
		sprintf(operand,"%1hx,$%02hX%02hX,%08lX",(unsigned short) opl,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],OFFSET+pc+5+sext8((unsigned short) rom[pc+4]));
		pc+=5;
		break;
	}
}


void table10(void)
{
unsigned char op,oph,opl;
char *op1[14]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","??","??","??","?","STAB","STA"};
char r;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;

if (oph==0xf) return;
switch(opl)
	{
	case 0x5:
	case 0x7:
	case 0xa:
	case 0xb:
	case 0xe:
	case 0xf:
		return;
		break;
	}
if (opl >7)
	{
	switch(oph)
		{
		case 0x0:
		case 0x1:
		case 0x8:
		case 0xc:
		case 0xd:
		case 0xe:
			return;
			break;
		}
	}
switch(oph)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
	case 0xc:
	case 0xd:
		r=0;
		break;
	case 0x8:
	case 0x9:
	case 0xa:
	case 0xb:
	case 0xe:
		return;
		break;
	}
operation=op1[oph];
switch(opl)
	{
	case 0x0:
		sprintf(operand,"B,(DPR%d+$%02hX)",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x1:
		sprintf(operand,"B,(DPR%d+$%02hX,X)",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x2:
		sprintf(operand,"B,L(DPR%d+$%02hX)",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x3:
		sprintf(operand,"B,$%02hX,S",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x4:
		sprintf(operand,"B,($%02hX,S),Y",(unsigned short) rom[pc+2]);
		pc+=3;
		break;
	case 0x6:
		sprintf(operand,"B,$%02hX%02hX,Y",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=4;
		break;
	case 0x8:
		sprintf(operand,"B,(DPR%d+$%02hX),Y",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0x9:
		sprintf(operand,"B,L(DPR%d+$%02hX),Y",DPR((unsigned short) rom[pc+2]));
		pc+=3;
		break;
	case 0xc:
		sprintf(operand,"B,$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+5],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=6;
		break;
	case 0xd:
		sprintf(operand,"B,$%02hX%02hX%02hX%02hX,X",(unsigned short) rom[pc+5],(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2]);
		pc+=6;
		break;
	}
}


void table13(void)
{
unsigned char op,opl,oph;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch(oph)
	{
	case 0x0:
		operation="LSR";
		sprintf(operand,"A,#$%hX",(unsigned short) opl);
		pc+=2;
		break;
	case 0x2:
		operation="ROR";
		sprintf(operand,"A,#$%hX",(unsigned short) opl);
		pc+=2;
		break;
	case 0x4:
		operation="ASL";
		sprintf(operand,"A,#$%hX",(unsigned short) opl);
		pc+=2;
		break;
	case 0x6:
		operation="ROL";
		sprintf(operand,"A,#$%hX",(unsigned short) opl);
		pc+=2;
		break;
	case 0x8:
		operation="ASR";
		sprintf(operand,"A,#$%hX",(unsigned short) opl);
		pc+=2;
		break;
	case 0xa:
	case 0xb:
		operation="DEBNE";
		sprintf(operand,"DPR%d+$%02hX,#$%02hX,%08lX",DPR((unsigned short) rom[pc+2]),(unsigned short) (op & 0x1F),OFFSET+pc+4+sext8(rom[pc+3]));
		pc+=4;
		break;
	}
}


void table14(void)
{
unsigned char op,opl,oph;

op = rom[pc+1];
opl=op & 0xF;
oph=(op>>4) & 0xF;
switch(oph)
	{
	case 0x0:
	case 0x1:
		operation="LSRD";
		sprintf(operand,"E,#$%hX",(unsigned short) (op & 0x1F));
		pc+=2;
		break;
	case 0x2:
	case 0x3:
		operation="RORD";
		sprintf(operand,"E,#$%hX",(unsigned short) (op & 0x1F));
		pc+=2;
		break;
	case 0x4:
	case 0x5:
		operation="ASLD";
		sprintf(operand,"E,#$%hX",(unsigned short) (op & 0x1F));
		pc+=2;
		break;
	case 0x6:
	case 0x7:
		operation="ROLD";
		sprintf(operand,"E,#$%hX",(unsigned short) (op & 0x1F));
		pc+=2;
		break;
	case 0x8:
	case 0x9:
		operation="ASRD";
		sprintf(operand,"E,#$%hX",(unsigned short) (op & 0x1F));
		pc+=2;
		break;
	case 0xe:
	case 0xf:
		operation="DEBNE";
		sprintf(operand,"$%02hX%02hX,#$%02hX,%08lX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) (op & 0x1F),OFFSET+pc+5+sext8(rom[pc+4]));
		pc+=5;
		break;
	}
}


void dis(void)
{
unsigned long prefixpc;

oldpc = pc;
M8="A";
m8=0;
rupt=0;

doprefix:
	prefixpc=pc;
	operationb[0]=0;
	operandb[0]=0;
	operation = operationb;
	operand = operandb;

if ((m8==0) && (rom[pc] == 0x81))
	{
    M8="B";
	m8=1;
	pc++;
	goto doprefix;
	}

op = rom[pc];
opl = op & 0xF;
oph = (op >> 4) & 0xF;

if ( (oph==0xf) && (opl>=0x8))
	{
	short x;
	
	operation="BSR";
	x = (op & 0x07)*256+rom[pc+1];
	if (x & 0x400) x |= 0xf800;
	sprintf(operand,"$%08lX",OFFSET+pc+2+sext16(x));
	pc += 2;
	} else
	{
	switch (opl)
		{
		case 0x0:
			if ((oph == 0) && (rom[pc+1] == 0x74))
				{
				if (m8) break;
				operation="BRK";
				pc += 2;
				return;
				}	
			if (oph != 0)
				{
				if (m8) break;
				if (oph==0) break;
				sprintf(operation,"B%s",cond[oph]);
				sprintf(operand,"$%08lX",OFFSET+pc+2+sext8(rom[pc+1]));
				if (oph==2) rupt=1;
				pc += 2;
				return;
				}
			break;
		case 0x1:
			switch(oph)
				{
				case 0x0:
					if (!m8) table1();
					break;
				case 0x1:
					if (!m8) table2();
					break;
				case 0x2:
					if (!m8) table3(0);
					break;
				case 0x3:
					if (!m8) table4(0);
					break;
				case 0x4:
					if (!m8) table5();
					break;
				case 0x5:
					if (!m8) table6();
					break;
				case 0x6:
					if (!m8) table7();
					break;
				case 0x7:
					if (!m8) table8();
					break;
				case 0x8:
					// 0x81 prefix, handled elsewhere
					break;
				case 0x9:
					if (!m8) table10();
					break;
				case 0xa:
					if (!m8) table3(1);
					break;
				case 0xb:
					if (!m8) table4(1);
					break;
				case 0xc:
					if (!m8) table13();
					break;
				case 0xd:
					if (!m8) table14();
					break;
				case 0xe:
					operation="ABS";
					operand=M8;
					pc++;
					break;
				case 0xf:
					if (m8) break;
					operation="RTI";
					rupt=2;
					pc++;
					break;
				}
			break;
		case 0x2:
			{
			char *op1[16]={"LDX","LDY","CPX","CPY","??","??","??","??","INC","DEC","??","??","CLRMB","CLRM","STX","STY"};
			char *op2[4]={"BBSB","BBCB","CBEQB","CBNEB"};
			char *op3[2]={"CBEQB","CBNEB"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x8:
				case 0x9:
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation = op1[oph];
					sprintf(operand,"DPR%d+$%02hX",DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
					if (m8) break;
					operation = op2[oph-4];
					sprintf(operand,"#$%02hX,DPR%d+$%02hX,$%08lX",(unsigned short) rom[pc+2],DPR((unsigned short) rom[pc+1]),OFFSET+pc+4+sext8(rom[pc+3]));
					pc+=4;
					break;
				case 0xa:
				case 0xb:
					operation = op3[oph-0xa];
					sprintf(operand,"%s,#$%02hX,$%08lX",M8,(unsigned short) rom[pc+1],OFFSET+pc+3+sext8(rom[pc+2]));
					pc+=3;
					break;
				}
			}
			break;
		case 0x3:
			{
			char *op1[12]={"ASL","ROL","??","??","LSR","ROR","??","??","??","??","INC","DEC"};
			char *op2[5]={"ANDB","EORB","??","??","ORAB"};
			char *op3[8]={"PHD","PLD","??","??","INX","INY","DEX","DEY"};
			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x4:
				case 0x5:
				case 0xa:
				case 0xb:
					operation=op1[oph];
					operand=M8;
					pc++;
					break;
				case 0x2:
				case 0x3:
				case 0x6:
					operation=op2[oph-2];
					sprintf(operand,"%s,#$%02hX",M8,(unsigned short) rom[pc+1]);
					pc+=2;
					break;
				case 0x7:
					break;
				case 0x8:
				case 0x9:
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation=op3[oph-8];
					pc++;
					break;
				}
			}
			break;
		case 0x4:
			{
			char *op1[16]={"SEC","CLC","??","??","??","??","??","NOP",
							"RTS","RTL","??","??","??","??","CLRX","CLRY"};
			char *op2[5]={"NEG","EXTZ","CLRB","CLR","ASR"};
			char *op3[4]={"TX%s","TY%s","T%sX","T%sY"};
			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x7:
				case 0x8:
				case 0x9:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation = op1[oph];
					if (oph==8) rupt=2;
					if (oph==9) rupt=2;
					pc++;
					break;
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
					operation = op2[oph-2];
					operand=M8;
					pc++;
					break;
				case 0xa:
				case 0xb:
				case 0xc:
				case 0xd:
					sprintf(operation,op3[oph-0xa],M8);
					pc++;
					break;
				}
			}
			break;
		case 0x5:
			{
			char *op1[16]={"SEI","CLI","SEM","??","CLM","XAB","CLV","??",
						   "??","??","PHP","PLP","PHX","PLX","PHY","PLY"};
			char *op2[2]={"PH%s","PL%s"};
			
			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0xa:
				case 0xb:
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation = op1[oph];
					pc++;
#ifndef FORCEXM
					if (oph==2) m=1;			// update m flag!
					if (oph==4) m=0;
#endif
					break;
				case 0x7:
					break;
				case 0x3:
					operation="EXTS";
					operand=M8;
					pc++;
					break;
				case 0x8:
				case 0x9:
					sprintf(operation,op2[oph-8],M8);
					pc++;
					break;
				}
			}
			break;
		case 0x6:
			{
			char *op1[7]={"LDA","ADD","SUB","CMP","ORA","AND","EOR"};
			char *op2[2]={"CBEQ","CBNE"};
			char *op3[4]={"LDX","LDY","CPX","CPY"};
			char *z;
			
			switch(oph)
				{
				case 0x0:
					break;
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
					operation = op1[oph-1];
					pc++;
					z=imm816();
					sprintf(operand,"%s,#%s",M8,z);
					break;
				case 0x8:
					if (m8) break;
					operation="MOVM";
					pc++;
					z=imm816();
					sprintf(operand,"DPR%d+$%02hX,#%s",DPR((unsigned short) rom[pc]),z);
					pc++;
					break;
				case 0x9:
					if (m8) break;
					operation="MOVM";
					pc++;
					z=imm816();
					sprintf(operand,"$%02hX%02hX,#%s",(unsigned short) rom[pc+1],(unsigned short) rom[pc],z);
					pc+=2;
					break;
				case 0xa:
				case 0xb:
					operation=op2[oph-0xa];
					pc++;
					z=imm816();
					sprintf(operand,"%s,#%s,$%08lX",M8,z,OFFSET+pc+1+sext8(rom[pc]));
					pc++;
					break;
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation=op3[oph-0xc];
					pc++;
					z=imx816();
					sprintf(operand,"#%s",z);
					break;
				}
			}
			break;
		case 0x7:
			{
			char *op1[16]={"LDX","LDY","??","??","??","??","??","??","INC","DEC","??","??","CLRMB","CLRM","STX","STY"};
			char *op2[2]={"LDXB","LDYB"};
			char *op3[2]={"BBSB","BBCB"};
			char *op4[13]={"PLD","??","??","??","??","??","??","??","RTSD","??","??","??","RTLD"};
			short b,i;

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x8:
				case 0x9:
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					if (m8) break;
					operation=op1[oph];
					sprintf(operand,"$%02hX%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0x2:
				case 0x3:
					if (m8) break;
					operation=op2[oph-2];
					sprintf(operand,"#$%02hX",(unsigned short) rom[pc+1]);
					pc += 2;
					break;
				case 0x4:
				case 0x5:
					if (m8) break;
					operation=op3[oph-4];
					sprintf(operand,"#$%02hX,$%02hX%02hX,$%08lX",(unsigned short) rom[pc+3],
																 (unsigned short) rom[pc+2],(unsigned short) rom[pc+1],
																 OFFSET+pc+5+sext8(rom[pc+4]));
					pc+=5;
					break;
				case 0x6:
					if (m8) break;
					operation="PUL";
					b=rom[pc+1];
					
					if (b==0) break; // nothing
					if (b&0x40) break; // invalid bit
					
					strcpy(operand,"");
					for (i=7; i>=0; i--)
						{
						if (b & (1<<i))
							{
							strcat(operand,pulreg[i]);
							b &= ~(1<<i);
							if (b) strcat(operand,",");
							}
						}
					pc+=2;
					break;
				case 0x7:
					if (m8) break;
					b=rom[pc+1];
					if (( (b>>4) & 0xf) == 0) break;
					switch(b & 0x0f)
						{
						case 0x0:
						case 0x8:
						case 0xc:
							operation=op4[b & 0x0f];
							if ( (b & 0x0f) == 0x8) rupt = 2;
							if ( (b & 0x0f) == 0xc) rupt = 2;
							b = (b>>4) & 0x0f;
							strcpy(operand,"(");
							for (i=3; i>=0; i--)
								{
								if (b & (1<<i))
									{
									char str[8];
									
									sprintf(str,"%hd",i);
									strcat(operand,str);
									b &= ~(1<<i);
									if (b)
										{
										strcat(operand,",");
										}
									}
								}
							strcat(operand,")");
							break;
						}
					pc+=2;
					break;
				case 0xa:
					if (m8) break;
					operation="BRAL";
					rupt=1;
					b = rom[pc+1];
					b += 256* rom[pc+2];
					sprintf(operand,"$%08lX",OFFSET+pc+3+sext16(b));
					pc+=3;
					break;
				case 0xb:
					break;
				}
			}
			break;
		case 0x8:
			{
			char *op1[16]={"LDAB","LDA","??","??","??","??","??","??",
							 "??","??","??","??","STAB","STA","??","??"};
			char *op2[2]={"LDAB","CMPB"};
			char *op3[8]={"LDAD","??","??","??","??","??","STAD","??"};
			char *op4[2]={"MOVMB","MOVM"};
			int b,i,h,l,ld,n;

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,(DPR%d+$%02hX),Y",M8,DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x2:
				case 0x3:
					operation=op2[oph-2];
					sprintf(operand,"%s,#$%02hX",M8,(unsigned short) rom[pc+1]);
					pc+=2;
					break;
				case 0x4:
				case 0x5:
					if (m8) break;
					operation=op4[oph-4];
					sprintf(operand,"DPR%d+$%02hX,DPR%d+$%02hX",DPR((unsigned short) rom[pc+2]),DPR((unsigned short) rom[pc+1]));
					pc+=3;
					break;
				case 0x6:
				case 0x7:
					if (m8) break;
					operation=op4[oph-6];
					sprintf(operand,"$%02hX%02hX,DPR%d+$%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],DPR((unsigned short) rom[pc+1]));
					pc+=4;
					break;
				case 0x8:
				case 0xe:
					if (m8) break;
					operation=op3[oph-8];
					sprintf(operand,"E,(DPR%d+$%02hX),Y",DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x9:
					if (m8) break;
					operation="CLP";
					b = rom[pc+1];
#ifndef FORCEXM
					if (b & 0x10) x=0;
					if (b & 0x20) m=0;
#endif
					strcpy(operand,"");
					for (i=0; i<8; i++)
						{
						if (b & (1<<i))
							{
							strcat(operand,flags[i]);
							b &= ~(1<<i);
							if (b) strcat(operand,",");
							}
						}
					pc+=2;
					break;
				case 0xa:
					if (m8) break;
					operation="PSH";
					b=rom[pc+1];
					if (b==0) break;
					strcpy(operand,"");
					for (i=0; i<8; i++)
						{
						if (b & (1<<i))
							{
							strcat(operand,pulreg[i]);
							b &= ~(1<<i);
							if (b) strcat(operand,",");
							}
						}
					pc+=2;
					break;
				case 0xb:
					if (m8) break;
					b = rom[pc+1];
					if (b==0) break;
					l = b & 0xF;
					h = (b>>4) & 0xF;
					if (l==0)
						{
						operation="LDD";
						pc+=2;
						b = h;
						ld = 1;
						}
					if (h==0)
						{
						operation="PHD";
						pc+=2;
						b = l;
						ld = 0;
						}
					if ((l!=0) && (h!=00))
						{
						if (h != l) break;
						pc+=2;
						operation="PHLD";
						b = l;
						ld = 1;
						}
					n = 0;
					strcpy(operand,"(");
					for (i=0; i<4; i++)
						{
						char str[8];
						
						if (b & (1<<i))
							{
							n++;
							sprintf(str,"%d",i);
							strcat(operand,str);
							b &= ~(1<<i);
							if (b) strcat(operand,",");
							}
						}
					strcat(operand,")");
					if (ld)
						{
						for (i=0; i<n; i++)
							{
							char str[8];

							strcat(operand,",");
							sprintf(str,"$%02hX%02hX",(unsigned short) rom[pc+1],(unsigned short) rom[pc]);
							strcat(operand,str);
							pc+=2;
							}
						}
					break;
				}
			}
			break;
		case 0x9:
			{
			char *op1[16]={"LDAB","LDA","??","??","??","??","??","??",
							 "??","??","??","??","STAB","STA","??","??"};
			char *op2[2]={"ADDB","SUBB"};
			char *op3[8]={"LDAD","??","??","??","??","??","STAD","??"};
			char *op4[2]={"MOVMB","MOVM"};
			int b,i;
			
			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,L(DPR%d+$%02hX),Y",M8,DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x2:
				case 0x3:
					operation=op2[oph-2];
					sprintf(operand,"%s,#$%02hX",M8,(unsigned short) rom[pc+1]);
					pc+=2;
					break;
				case 0x4:
				case 0x5:
					break;
				case 0x6:
				case 0x7:
					if (m8) break;
					operation=op4[oph-6];
					sprintf(operand,"$%02hX%02hX,DPR%d+$%02hX,X",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],DPR((unsigned short) rom[pc+1]));
					pc+=4;
					break;
				case 0x8:
				case 0xe:
					if (m8) break;
					operation=op3[oph-8];
					sprintf(operand,"E,L(DPR%d+$%02hX),Y",DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x9:
					if (m8) break;
					operation="SEP";
					b = rom[pc+1];
#ifndef FORCEXM
					if (b & 0x10) x=1;
					if (b & 0x20) m=1;
#endif
					strcpy(operand,"");
					for (i=0; i<8; i++)
						{
						if (b & (1<<i))
							{
							strcat(operand,flags[i]);
							b &= ~(1<<i);
							if (b) strcat(operand,",");
							}
						}
					pc+=2;
					break;
				case 0xa:
					if (m8) break;
					operation="MOVMB";
					sprintf(operand,"DPR%d+$%02hX,#$%02hX",DPR((unsigned short) rom[pc+2]),(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0xb:
					if (m8) break;
					operation="MOVMB";
					sprintf(operand,"$%02hX%02hX,#$%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				}
			}
			break;
		case 0xa:
			{
			char *op1[14]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","??","??","??","??","STAB","STA"};
			char *op2[7]={"LDAD","ADDD","SUBD","CMPD","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,DPR%d+$%02hX",M8,DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x8:
				case 0x9:
				case 0xa:
				case 0xb:
				case 0xe:
					if (m8) break;
					operation=op2[oph-8];
					sprintf(operand,"E,DPR%d+$%02hX",DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				}
			}
			break;
		case 0xb:
			{
			char *op1[14]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","??","??","??","??","STAB","STA"};
			char *op2[7]={"LDAD","ADDD","SUBD","CMPD","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,DPR%d+$%02hX,X",M8,DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				case 0x8:
				case 0x9:
				case 0xa:
				case 0xb:
				case 0xe:
					if (m8) break;
					operation=op2[oph-8];
					sprintf(operand,"E,DPR%d+$%02hX,X",DPR((unsigned short) rom[pc+1]));
					pc+=2;
					break;
				}
			}
			break;
		case 0xc:
			{
			char *op1[14]={"LDAB","LDA","??","??","??","??","??","??","??","??","??","??","STAB","STA"};
			char *op2[2]={"LDAD","CMPD"};
			char *op3[2]={"MOVMB","MOVM"};
			char *op4[7]={"LDAD","??","??","??","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,$%02hX%02hX%02hX",M8,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x2:
				case 0x3:
					if (m8) break;
					operation=op2[oph-2];
					sprintf(operand,"E,$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=5;
					break;
				case 0x4:
				case 0x5:
					if (m8) break;
					operation=op3[oph-4];
					sprintf(operand,"DPR%d+$%02hX,$%02hX%02hX",DPR((unsigned short) rom[pc+3]),(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x6:
				case 0x7:
					if (m8) break;
					operation=op3[oph-6];
					sprintf(operand,"$%02hX%02hX,$%02hX%02hX",(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=5;
					break;
				case 0x8:
				case 0xe:
					if (m8) break;
					operation=op4[oph-8];
					sprintf(operand,"E,$%02hX%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x9:
					if (m8) break;
					operation="JMP";
					sprintf(operand,"$%02hX%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0xa:
					if (m8) break;
					operation="JMPL";
					sprintf(operand,"$00%02hX%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0xb:
					if (m8) break;
					operation="JMP";
					sprintf(operand,"($%02hX%02hX,X)",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				}
			}
			break;
		case 0xd:
			{
			char *op1[14]={"LDAB","LDA","??","??","??","??","??","??","??","??","??","??","STAB","STA"};
			char *op2[2]={"ADDD","SUBD"};
			char *op3[2]={"MOVMB","MOVM"};
			char *op4[7]={"LDAD","??","??","??","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,$%02hX%02hX%02hX,X",M8,(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x2:
				case 0x3:
					if (m8) break;
					operation=op2[oph-2];
					sprintf(operand,"E,#$%02hX%02hX%02hX%02hX",(unsigned short) rom[pc+4],(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=5;
					break;
				case 0x4:
				case 0x5:
					if (m8) break;
					operation=op3[oph-4];
					sprintf(operand,"DPR%d+$%02hX,$%02hX%02hX,X",DPR((unsigned short) rom[pc+3]),(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x6:
					break;
				case 0x7:
					break;
				case 0x8:
				case 0xe:
					if (m8) break;
					operation=op4[oph-8];
					sprintf(operand,"E,$%02hX%02hX%02hX,X",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0x9:
					if (m8) break;
					operation="JSR";
					sprintf(operand,"$%02hX%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0xa:
					if (m8) break;
					operation="JSRL";
					sprintf(operand,"$00%02hX%02hX%02hX",(unsigned short) rom[pc+3],(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=4;
					break;
				case 0xb:
					if (m8) break;
					operation="JSR";
					sprintf(operand,"($%02hX%02hX,X)",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				}
			}
			break;
		case 0xe:
			{
			char *op1[14]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","??","??","??","??","STAB","STA"};
			char *op2[7]={"LDAD","ADDD","SUBD","CMPD","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,$%02hX%02hX",M8,(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0x8:
				case 0x9:
				case 0xa:
				case 0xb:
				case 0xe:
					if (m8) break;
					operation=op2[oph-8];
					sprintf(operand,"E,$%02hX%02hX",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				}
			}
			break;
		case 0xf:
			{
			char *op1[14]={"LDAB","LDA","ADD","SUB","CMP","ORA","AND","EOR","??","??","??","??","STAB","STA"};
			char *op2[7]={"LDAD","ADDD","SUBD","CMPD","??","??","STAD"};

			switch(oph)
				{
				case 0x0:
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
				case 0xc:
				case 0xd:
					operation=op1[oph];
					sprintf(operand,"%s,$%02hX%02hX,X",M8,(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				case 0x8:
				case 0x9:
				case 0xa:
				case 0xb:
				case 0xe:
					if (m8) break;
					operation=op2[oph-8];
					sprintf(operand,"E,$%02hX%02hX,X",(unsigned short) rom[pc+2],(unsigned short) rom[pc+1]);
					pc+=3;
					break;
				}
			}
			break;
		}
	}
if ( pc==prefixpc )
	{	// 0x81 prefix, but prefixing no valid instruction
	pc = oldpc;
	}
if (pc==oldpc)
	{
	operation="DC.B";
	rupt=0;
	sprintf(operand,"$%02hX",(unsigned short) rom[pc]);
	pc++;
	}
}

void main(void)
{
FILE *fin,*fout;
char fnam[256];
unsigned long size;
char cdump[256];
char cbyte[16];
int ptr;
char line[256];
unsigned long l,i,n;


printf("Binary file to disassemble : "); gets(fnam);

fin = fopen(fnam,"rb");
if (fin == NULL)
	{
	fprintf(stderr,"Cannot open input file.\n");
	return;
	}

size = fread(rom,1,sizeof(rom)/sizeof(rom[0]),fin);

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL)
	{
	fprintf(stderr,"Cannot open output file.\n");
	return;
	}

printf("Offset: "); scanf("%lx",&OFFSET);
printf("Enable DPR1-3 (0/1): "); scanf("%hd",&MULTIDPR);

pc = 0x0000000;
while (pc < size)
	{
//printf("%08lX\r",pc); //temp debug
	dis();
	strcpy(cdump,"");
	for (ptr=oldpc; ptr<pc; ptr++)
		{
		sprintf(cbyte,"%02hX",(short) rom[ptr]);
		strcat(cdump,cbyte);
		}

	sprintf(line,"%08lX %-20.20s\t%s\t%s",oldpc+OFFSET,cdump,operation,operand);
	fprintf(fout,"%s\n",line);
	// preceding two lines dumped max 10 bytes of hexa. Let's do the remaining bytes...
	l = ((pc-oldpc)>10) ? pc-oldpc-10 : 0;	// remaining bytes to dump
	ptr = oldpc+10;
	while (l)
		{
		n = (l>10) ? 10 : l;
		strcpy(cdump,"");
		for (i=0; i<n; i++)
			{
			sprintf(cbyte,"%02hX",(short) rom[ptr++]);
			strcat(cdump,cbyte);
			}
		sprintf(line,"         %-20.20s",cdump);
		fprintf(fout,"%s\n",line);
		l -= n;
		}
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"-----------------------------------\n");
			fprintf(fout,"\n");
			m = DEFAULTm;
			x = DEFAULTx;
			break;
		}
	}

fprintf(stderr,"Done.\n");
}
