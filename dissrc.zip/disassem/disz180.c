/*

Program originally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

History:

16-JUN-2001	First version. Not extensively tested yet.
17-JUN-2001	Corrected DEC ss and LD (IX+d),r decoding.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// #define RAW			// define RAW to disassemble the raw data. Undef to disassemble a toshiba firmware

#define HI(x) (((x) >> 4) & 0xF)
#define LO(x) ((x) & 0xF)
#define rel(x,n)	(pc+n+ROMOFFSET+(signed char)(x))
#define SIGN(x) ( ((x)&0x80) ? '-' : '+')
#define ABS(x) ( ((x)&0x80) ? ((~(x)+1) & 0xFF) : (x))

unsigned long ROMOFFSET;	// PC of first byte of rom
char operb[256];
char argsb[256];
char *oper;
char *args;
char line[256];
char rupt;
char *IX;
char *prefix;

char *cc[8]={"NZ","Z","NC","C",
              "NV","V","P","M"};
char *r8[8]={"B","C","D","E",
              "H","L","(HL)","A"};
char *r16af[4]={"BC","DE","HL","AF"};
char *r16sp[4]={"BC","DE","HL","SP"};
char *ops[8]={"ADD","ADC","SUB","SBC","AND","XOR","OR","CP"};


unsigned char data[512*1024];
unsigned long pc;
unsigned char *rom;
unsigned char b1,b2,b3,b4;


void tableCB(void)
{
char *op1[3] = {"BIT","RES","SET"};
char *op2[8] = {"RLC","RRC","RL","RR","SLA","SRA","???","SRL"};

if (b2 < 0x40)
	{
	if ( (b2 >= 0x30) && (b2 < 0x38) ) return;
	oper = op2[(b2 >> 3) & 7];
	args = r8[b2 & 7];
	pc += 2;
	}
	else
	{
	oper = op1[ (b2 - 0x40) / 0x40];
	sprintf(args,"%d,%s",(b2 >> 3) & 7,r8[b2 & 7]);
	pc += 2;
	}
}




void tableED(void)
{
switch (b2)
	{
case 0x00: case 0x10: case 0x20:
case 0x08: case 0x18: case 0x28: case 0x38:
			oper = "IN0"; sprintf(args,"%s,($%02hX)",r8[(b2 >> 3) & 7],b3); pc += 3; return;
case 0x30:	oper = "IN0"; sprintf(args,"($%02hX)",b3); pc += 3; return;
case 0x01: case 0x11: case 0x21:
case 0x09: case 0x19: case 0x29: case 0x39:
			oper = "OUT0"; sprintf(args,"($%02hX),%s",b3,r8[(b2 >> 3) & 7]); pc += 3; return;
case 0x04: case 0x14: case 0x24: case 0x34:
case 0x0c: case 0x1c: case 0x2c: case 0x3c:
			oper = "TST"; sprintf(args,"A,%s",r8[(b2 >> 3) & 7]); pc += 2; return;
case 0x40: case 0x50: case 0x60:
case 0x48: case 0x58: case 0x68: case 0x78:
			oper = "IN"; sprintf(args,"%s,(C)",r8[(b2 >> 3) & 7]); pc += 2; return;
case 0x41: case 0x51: case 0x61:
case 0x49: case 0x59: case 0x69: case 0x79:
			oper = "OUT"; sprintf(args,"(C),%s",r8[(b2 >> 3) & 7]); pc += 2; return;
case 0x42: case 0x52: case 0x62: case 0x72:
			oper = "SBC"; sprintf(args,"HL,%s",r16sp[(b2 >> 4) & 3]); pc += 2; return;
case 0x4a: case 0x5a: case 0x6a: case 0x7a:
			oper = "ADC"; sprintf(args,"HL,%s",r16sp[(b2 >> 4) & 3]); pc += 2; return;
case 0x43: case 0x53: case 0x63: case 0x73:
			oper = "LD"; sprintf(args,"($%02hX%02hX),%s",b4,b3,r16sp[(b2 >> 4) & 3]); pc += 4; return;
case 0x4b: case 0x5b: case 0x6b: case 0x7b:
			oper = "LD"; sprintf(args,"%s,($%02hX%02hX)",r16sp[(b2 >> 4) & 3],b4,b3); pc += 4; return;
case 0x44:	oper ="NEG"; args = "A"; pc += 2; return;
case 0x45:	oper ="RETN"; rupt=2; pc += 2; return;
case 0x4d:	oper ="RETI"; rupt=2; pc += 2; return;
case 0x46:	oper ="IM"; args = "0"; pc += 2; return;
case 0x56:	oper ="IM"; args = "1"; pc += 2; return;
case 0x5e:	oper ="IM"; args = "2"; pc += 2; return;
case 0x47:	oper ="LD"; args = "I,A"; pc += 2; return;
case 0x4f:	oper ="LD"; args = "R,A"; pc += 2; return;
case 0x57:	oper ="LD"; args = "A,I"; pc += 2; return;
case 0x5f:	oper ="LD"; args = "A,R"; pc += 2; return;
case 0x4c: case 0x5c: case 0x6c: case 0x7c:
			oper ="MLT"; args = r16sp[(b2>>4) & 3]; pc += 2; return;
case 0x67:	oper ="RRD"; pc += 2; return;
case 0x6f:	oper ="RLD"; pc += 2; return;
case 0x76:	oper ="SLP"; pc += 2; return;
case 0x64:	oper = "TST"; sprintf(args,"A,$%02hX",b3); pc += 3; return;
case 0x74:	oper = "TSTIO"; sprintf(args,"($%02hX)",b3); pc += 3; return;
case 0x83:	oper = "OTIM"; pc += 2; return;
case 0x8b:	oper = "OTDM"; pc += 2; return;
case 0x93:	oper = "OTIMR"; pc += 2; return;
case 0x9b:	oper = "OTDMR"; pc += 2; return;
case 0xa0:	oper = "LDI"; pc += 2; return;
case 0xb0:	oper = "LDIR"; pc += 2; return;
case 0xa1:	oper = "CPI"; pc += 2; return;
case 0xb1:	oper = "CPIR"; pc += 2; return;
case 0xa2:	oper = "INI"; pc += 2; return;
case 0xb2:	oper = "INIR"; pc += 2; return;
case 0xa3:	oper = "OUTI"; pc += 2; return;
case 0xb3:	oper = "OTIR"; pc += 2; return;
case 0xa8:	oper = "LDD"; pc += 2; return;
case 0xb8:	oper = "LDDR"; pc += 2; return;
case 0xa9:	oper = "CPD"; pc += 2; return;
case 0xb9:	oper = "CPDR"; pc += 2; return;
case 0xaa:	oper = "IND"; pc += 2; return;
case 0xba:	oper = "INDR"; pc += 2; return;
case 0xab:	oper = "OUTD"; pc += 2; return;
case 0xbc:	oper = "OTDR"; pc += 2; return;
	}
}




void tableDDCB(void)
{
char *op1[3] = {"BIT","RES","SET"};

switch (b4)
	{
case 0x06:	oper = "RLC"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x0e:	oper = "RRC"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x16:	oper = "RL"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x1e:	oper = "RR"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x26:	oper = "SLA"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x2e:	oper = "SRA"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;
case 0x3e:	oper = "SRL"; sprintf(args,"(%s%c%s)",IX,SIGN(b3),ABS(b3)); pc += 4; return;

case 0x46: case 0x4e: case 0x56: case 0x5e:
case 0x66: case 0x6e: case 0x76: case 0x7e:
case 0x86: case 0x8e: case 0x96: case 0x9e:
case 0xa6: case 0xae: case 0xb6: case 0xbe:
case 0xc6: case 0xce: case 0xd6: case 0xde:
case 0xe6: case 0xee: case 0xf6: case 0xfe:
	oper = op1[ (b4 - 0x40) / 0x40];
	sprintf(args,"%d,%s%c%s",(b2 >> 3) & 7,IX,SIGN(b3),ABS(b3));
	pc += 4;
	return;
	}
}




void tableDD(void)
{
switch (b1)
	{
case 0xDD: IX="IX"; break;
case 0xFD: IX="IY"; break;
default: IX = "???"; break;
	}

switch (b2)
	{
case 0x09:	oper = "ADD"; sprintf(args,"%s,BC",IX); pc += 2; return;
case 0x19:	oper = "ADD"; sprintf(args,"%s,DE",IX); pc += 2; return;
case 0x29:	oper = "ADD"; sprintf(args,"%s,%s",IX,IX); pc += 2; return;
case 0x39:	oper = "ADD"; sprintf(args,"%s,SP",IX); pc += 2; return;
case 0x21:	oper = "LD"; sprintf(args,"%s,$%02hX%02hX",IX,b4,b3); pc += 4; return;
case 0x22:	oper = "LD"; sprintf(args,"($%02hX%02hX),%s",b4,b3,IX); pc += 4; return;
case 0x2a:	oper = "LD"; sprintf(args,"%s,($%02hX%02hX)",IX,b4,b3); pc += 4; return;
case 0x23:	oper = "INC"; sprintf(args,"%s",IX); pc += 2; return;
case 0x2b:	oper = "DEC"; sprintf(args,"%s",IX); pc += 2; return;
case 0x34:	oper = "INC"; sprintf(args,"(%s%c$%02hX)",IX,SIGN(b3),ABS(b3)); pc += 3; return;
case 0x35:	oper = "DEC"; sprintf(args,"(%s%c$%02hX)",IX,SIGN(b3),ABS(b3)); pc += 3; return;
case 0x36:	oper = "LD"; sprintf(args,"(%s%c$%02hX),$%02hX",IX,SIGN(b3),ABS(b3),b4); pc += 4; return;
case 0x46: case 0x56: case 0x66:
case 0x4e: case 0x5e: case 0x6e: case 0x7e:
			oper = "LD"; sprintf(args,"%s,(%s%c$%02hX)",r8[(b2 >> 3) & 7],IX,SIGN(b3),ABS(b3)); pc += 3; return;
case 0x70: case 0x71:  case 0x72:  case 0x73:
case 0x74: case 0x75:  case 0x77:
			oper = "LD"; sprintf(args,"(%s%c$%02hX),%s",IX,SIGN(b3),ABS(b3),r8[b3 & 7]); pc += 3; return;
case 0x86: case 0x96: case 0xa6: case 0xb6:
case 0x8e: case 0x9e: case 0xae: case 0xbe:
			oper = ops[(b2 >> 3) & 7]; sprintf(args,"A,(%s%c$%02hX)",IX,SIGN(b3),ABS(b3)); pc += 3; return;

case 0xe1:	oper = "POP"; sprintf(args,"%s",IX); pc += 2; return;
case 0xe3:	oper = "EX"; sprintf(args,"(SP),%s",IX); pc += 2; return;
case 0xe5:	oper = "PUSH"; sprintf(args,"%s",IX); pc += 2; return;
case 0xe9:	oper = "JP"; sprintf(args,"(%s)",IX); pc += 2; rupt = 1; return;
case 0xf9:	oper = "LD"; sprintf(args,"SP,%s",IX); pc += 2; return;
case 0xcb:	tableDDCB(); return;
	}
}




void dodis(void)
{
// do the real disassembly.
// if rom[pc] is not an instruction, do nothing, do NOT increment pc.
// if pc is incremented, oper and args are the instruction description

rupt = 0;
b1 = rom[pc];
b2 = rom[pc+1];
b3 = rom[pc+2];
b4 = rom[pc+3];

switch(b1)
	{
case 0x00:	oper = "NOP"; pc++; return;
case 0x10:	oper = "DJNZ"; sprintf(args,"$%04hX",rel(b2,2)); pc+=2; return;
case 0x20:	oper = "JR"; sprintf(args,"NZ,$%04hX",rel(b2,2)); pc+=2; return;
case 0x30:	oper = "JR"; sprintf(args,"NC,$%04hX",rel(b2,2)); pc+=2; return;

case 0x01: case 0x11: case 0x21: case 0x31:
			oper = "LD"; sprintf(args,"%s,$%02X%02X",r16sp[(b1>>4) & 3],b3,b2); pc+=3; return;

case 0x02:	oper = "LD"; args="(BC),A"; pc++; return;
case 0x12:	oper = "LD"; args="(DE),A"; pc++; return;
case 0x22:	oper = "LD"; sprintf(args,"($%02X%02X),HL",b3,b2); pc+=3; return;
case 0x32:	oper = "LD"; sprintf(args,"($%02X%02X),A",b3,b2); pc+=3; return;

case 0x03: case 0x13: case 0x23: case 0x33:
			oper = "INC"; args=r16sp[(b1>>4) & 3]; pc++; return;

case 0x04: case 0x14: case 0x24: case 0x34:
case 0x0c: case 0x1c: case 0x2c: case 0x3c:
			oper = "INC"; args = r8[(b1>>3) & 7]; pc++; return;

case 0x05: case 0x15: case 0x25: case 0x35:
case 0x0d: case 0x1d: case 0x2d: case 0x3d:
			oper = "DEC"; args = r8[(b1>>3) & 7]; pc++; return;

case 0x06: case 0x16: case 0x26: case 0x36:
case 0x0e: case 0x1e: case 0x2e: case 0x3e:
			oper = "LD"; sprintf(args,"%s,$%02hX",r8[(b1>>3) & 7],b2); pc+=2; return;

case 0x07:	oper = "RLCA"; pc++; return;
case 0x17:	oper = "RLA"; pc++; return;
case 0x27:	oper = "DAA"; pc++; return;
case 0x37:	oper = "SCF"; pc++; return;

case 0x08:	oper = "EX"; args = "AF,AF'"; pc++; return;
case 0x18:	oper = "JR"; sprintf(args,"$%04hX",rel(b2,2)); pc+=2; rupt = 1; return;
case 0x28:	oper = "JR"; sprintf(args,"Z,$%04hX",rel(b2,2)); pc+=2; return;
case 0x38:	oper = "JR"; sprintf(args,"C,$%04hX",rel(b2,2)); pc+=2; return;

case 0x09: case 0x19: case 0x29: case 0x39:
			oper = "ADD"; sprintf(args,"HL,%s",r16sp[(b1>>4) & 3]); pc++; return;

case 0x0a:	oper = "LD"; args="A,(BC)"; pc++; return;
case 0x1a:	oper = "LD"; args="A,(DE)"; pc++; return;
case 0x2a:	oper = "LD"; sprintf(args,"HL,($%02X%02X)",b3,b2); pc+=3; return;
case 0x3a:	oper = "LD"; sprintf(args,"A,($%02X%02X)",b3,b2); pc+=3; return;

case 0x0B: case 0x1B: case 0x2B: case 0x3B:
			oper = "DEC"; args=r16sp[(b1>>4) & 3]; pc++; return;

case 0x0f:	oper = "RRCA"; pc++; return;
case 0x1f:	oper = "RRA"; pc++; return;
case 0x2f:	oper = "CPL"; args = "A"; pc++; return;
case 0x3f:	oper = "CCF"; pc++; return;

case 0x76:	oper = "HALT"; pc++; return;

case 0xc0: case 0xd0: case 0xe0: case 0xf0:
case 0xc8: case 0xd8: case 0xe8: case 0xf8:
			oper = "RET"; args = cc[(b1>>3) & 7]; pc++; return;

case 0xc1: case 0xd1: case 0xe1: case 0xf1:
			oper = "POP"; args = r16af[(b1>>4) & 3]; pc++; return;

case 0xc2: case 0xd2: case 0xe2: case 0xf2:
case 0xca: case 0xda: case 0xea: case 0xfa:
			oper = "JP"; sprintf(args,"%s,$%02hX%02hX",cc[(b1>>3) & 7],b3,b2); pc+=3; return;

case 0xc3:	oper = "JP"; sprintf(args,"$%02hX%02hX",b3,b2); pc+=3; rupt = 1; return;
case 0xd3:	oper = "OUT"; sprintf(args,"($%02hX),A)",b2); pc+=2; return;
case 0xe3:	oper = "EX"; args = "(SP),HL"; pc++; return;
case 0xf3:	oper = "DI"; pc++; return;

case 0xc4: case 0xd4: case 0xe4: case 0xf4:
case 0xcc: case 0xdc: case 0xec: case 0xfc:
			oper = "CALL"; sprintf(args,"%s,$%02hX%02hX",cc[(b1>>3) & 7],b3,b2); pc+=3; return;

case 0xc5: case 0xd5: case 0xe5: case 0xf5:
			oper = "PUSH"; args = r16af[(b1>>4) & 3]; pc++; return;

case 0xc6: case 0xd6: case 0xe6: case 0xf6:
case 0xce: case 0xde: case 0xee: case 0xfe:
			oper = ops[(b1>>3) & 7]; sprintf(args,"A,$%02hX",b2); pc += 2; return;

case 0xc7: case 0xd7: case 0xe7: case 0xf7:
case 0xcf: case 0xdf: case 0xef: case 0xff:
			oper = "RST"; sprintf(args,"$00%02hX",b1 & 0x38); pc++; return;

case 0xc9:	oper = "RET"; pc++; rupt = 2; return;
case 0xd9:	oper = "EXX"; pc++; return;
case 0xe9:	oper = "JP"; args="(HL)"; pc++; rupt = 1; return;
case 0xf9:	oper = "LD"; args="SP,HL"; pc++; return;


case 0xcb:	tableCB(); return;
case 0xdb:	oper = "IN"; sprintf(args,"A,($%02hX))",b2); pc+=2; return;
case 0xeb:	oper = "EX"; args = "DE,HL"; pc++; return;
case 0xfb:	oper = "EI"; pc++; return;

case 0xcd:	oper = "CALL"; sprintf(args,"$%02hX%02hX",b3,b2); pc+=3; return;
case 0xdd:	tableDD(); return;
case 0xed:	tableED(); return;
case 0xfd:	tableDD(); return;
default: break;
	}
if (b1 >= 0x40 && b1 < 0x80)
	{
	oper = "LD";
	sprintf(args,"%s,%s",r8[(b1 >> 3) & 7],r8[b1 & 7]);
	pc++;
	return;
	}
if (b1 >= 0x80 && b1 < 0xC0)
	{
	oper = ops[(b1 >> 3) & 7];
	sprintf(args,"A,%s",r8[b1 & 7]);
	pc++;
	return;
	}
}

void dis(void)
{
unsigned long oldpc;
char cdump[256];
char cbyte[16];
int ptr;

strcpy(operb,"");
strcpy(argsb,"");
oper = operb;
args = argsb;

oldpc = pc;

dodis();

if (pc == oldpc)
	{
	oper = "DB";
	sprintf(args,"$%02hX",(short) rom[pc++]);
	}
strcpy(cdump,"");
for (ptr=oldpc; ptr<pc; ptr++)
	{
	sprintf(cbyte,"%02hX",(short) rom[ptr]);
	strcat(cdump,cbyte);
	}

sprintf(line,"%s%04lX %-8.8s\t%s\t%s",prefix,oldpc+ROMOFFSET,cdump,oper,args);
}


void main(void)
{
unsigned long len,l;
char fnam[256];
FILE *fin,*fout;
unsigned long bank,max;


printf("File name : "); gets(fnam);
fin = fopen(fnam,"rb");
if (fin == NULL) return;

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL) return;

len = sizeof(data)/sizeof(data[0]);

l = fread(data,1,len,fin);

len = l;

#ifdef RAW
printf("Address of first byte of file : ");
scanf("%x",&ROMOFFSET);
prefix="";

for (pc=0; pc < len; )
	{
	rom = data;
	dis();
	fprintf(fout,"%s\n",line);
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"-------------------\n");
			fprintf(fout,"\n");
			break;
		}
	}
#else

max = len;
if (max > 0x8000) max = 0x8000;

fprintf(fout,"; ======== Fixed ========\n\n\n");
prefix="   ";
rom = data;
ROMOFFSET = 0x0;
for (pc=0; pc < max; )
	{
	dis();
	fprintf(fout,"%s\n",line);
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"-------------------\n");
			fprintf(fout,"\n");
			break;
		}
	}

max = len-0x8000;
max = (max+0x3fff) / 0x4000;
for (bank = 0; bank < max ; bank++)
	{
	fprintf(fout,"\n\n; ======== Bank %lX ========\n\n\n",bank);
	sprintf(prefix,"%02lX ",bank);
	rom = data+0x8000+bank*0x4000;
	ROMOFFSET = 0x8000;
	for (pc=0; pc < 0x4000; )
		{
		if ( (0x8000+bank*0x4000 + pc) >= len) break;
		dis();
		fprintf(fout,"%s\n",line);
		switch(rupt)
			{
			case 1:
				fprintf(fout,"\n");
				break;
			case 2:
				fprintf(fout,"-------------------\n");
				fprintf(fout,"\n");
				break;
			}
		}
	}
#endif
printf("Done.\n");
}
