/*

Program orignally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

*/

// This disassembler was not checked. I'm pretty sure it will output some badly
// disassembled instructions. Trust me! Extensive debugging is needed.

// SH3 instructions are handled, without DSP nor FPU
// 20-JUN-2001	Corrected @(disp,Rn)
#include <stdlib.h>
#include <stdio.h>
#include <string.h>



#define OMITPCRELATIVE 2	// 0: @($xxx,pc)=#yyy // 1: #yyyy // 2: #yyyy,Rn ; @($xxx,pc)
#define SHOWCONSTANT 0		// 0: disassamble constants // 1: list as constant values

#define PCRELATIVEOFFSET 4


unsigned char rom[1024*1024];
unsigned char tag[1024*1024];
unsigned long OFFSET;		// real-life address of rom[0]

unsigned long pc,oldpc;
unsigned short op,MSB,LSB,Rm,Rn,MD,MD0,Fx;
char operationb[256];
char operandb[1024];
char *operation;
char *operand;
char rupt,rupt1;

char *SRGBR[8]=  {"SR","GBR","VBR","SSR","SPC","MOD","RS","RE"};
char *OREGS[16]= {"MACH","MACL","PR","?","FPUL","FPSCR","DSR","A0","X0","X1","Y0","Y1","?","?","?","?"};
char invalid[16]={ 0    , 0    , 0  , 1 , 0    , 0     , 0   , 0  , 0  , 0  , 0  , 0  , 1 , 1 , 1 , 1 };
char *size[4]={"B","W","L","?"};
unsigned long mult[3]={1,2,4};

unsigned long sext8(unsigned char x8)
{
return (signed char) x8;
}


unsigned long sext12(unsigned short x12)
{
if (x12 & 0x0800)
	{
	x12 |= 0xF000;
	} else
	{
	x12 &= ~0xF000;
	}

return (signed short) x12;
}


unsigned long sext16(unsigned short x16)
{
return (signed short) x16;
}


void mark(unsigned long off, char sz)
{
char i;

for (i=0; i< sz; i++)
	{
	if ( (off+i) < (sizeof(tag) / sizeof(tag[0])))
		{
		tag[off+i] = sz;
		}
	}
}


void unmark(unsigned long off, char sz)
{
char i;

for (i=0; i< sz; i++)
	{
	if ( (off+i) < (sizeof(tag) / sizeof(tag[0])))
		{
		tag[off] = 0;
		}
	}
}


void MSB0(void)
{
switch (LSB)
	{
	case 0x0:
	case 0x1:
		break;
	case 0x2:
		if (Rm < 8)
			{
			if ( (Rm & 7) >= 5) return;
			operation = "STC";
			sprintf(operand,"%s,R%hd",SRGBR[Rm & 7],Rn);
			pc += 2;
			} else
			{
			operation = "STC";
			sprintf(operand,"R%hd_BANK,R%hd",Rm & 7,Rn);
			pc += 2;
			}
		break;
	case 0x3:
		switch (Fx)
			{
			case 0x0:
				operation = "BSRF";
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			case 0x2:
				operation = "BRAF";
				sprintf(operand,"R%hd",Rn);
				rupt = 1;
				pc += 2;
				break;
			case 0x8:
				operation = "PREF";
				sprintf(operand,"@R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		switch (MD0)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				sprintf(operation,"MOV.%s",size[MD0]);
				sprintf(operand,"R%hd,@(R0,R%hd)",Rm,Rn);
				pc += 2;
				break;
			case 0x3:
				operation = "MUL.L";
				sprintf(operand,"R%hd,R%hd",Rm,Rn);
				pc += 2;
				break;
			}
		break;
	case 0x8:
		if (Rn != 0) return;
		switch (Fx)
			{
			case 0x0:
				operation = "CLRT";
				pc += 2;
				break;
			case 0x1:
				operation = "SETT";
				pc += 2;
				break;
			case 0x2:
				operation = "CLRMAC";
				pc += 2;
				break;
			case 0x3:
				operation = "LDTLB";
				pc += 2;
				break;
			case 0x4:
				operation = "CLRS";
				pc += 2;
				break;
			case 0x5:
				operation = "SETS";
				pc += 2;
				break;
			}
		break;
	case 0x9:
		switch (Fx)
			{
			case 0x0:
				if (Rn != 0) return;
				operation = "NOP";
				pc += 2;
				break;
			case 0x1:
				if (Rn != 0) return;
				operation = "DIV0U";
				pc += 2;
				break;
			case 0x2:
				operation = "MOVT";
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0xA:
		if (invalid[Fx]) break;
		operation = "STS";
		sprintf(operand,"%s,R%hd",OREGS[Rm],Rn);
		pc += 2;
		break;
	case 0xB:
		if (Rn != 0) return;
		switch (Fx)
			{
			case 0x0:
				operation = "RTS";
				rupt = 2;
				pc += 2;
				break;
			case 0x1:
				operation = "SLEEP";
				pc += 2;
				break;
			case 0x2:
				operation = "RTE      ";
				rupt = 2;
				pc += 2;
				break;
			}
		break;
	case 0xC:
	case 0xD:
	case 0xE:
	case 0xF:
		switch (MD0)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				sprintf(operation,"MOV.%s",size[MD0]);
				sprintf(operand,"@(R0,R%hd),R%hd",Rm,Rn);
				pc += 2;
				break;
			case 0x3:
				operation = "MAC.L";
				sprintf(operand,"@R%hd+,@R%hd+",Rm,Rn);
				pc += 2;
				break;
			}
		break;
	}
}



void MSB1(void)
{
operation = "MOV.L";
sprintf(operand,"R%hd,@($%02lX,R%hd)",Rm,LSB*4L,Rn);
pc += 2;
}



void MSB2(void)
{
char *op1[8]={"TST","AND","XOR","OR","CMP/STR","XTRCT","MULU.W","MULS.W"};
switch (LSB)
	{
	case 0x0:
	case 0x1:
	case 0x2:
		sprintf(operation,"MOV.%s",size[MD0]);
		sprintf(operand,"R%hd,@R%hd",Rm,Rn);
		pc += 2;
		break;
	case 0x4:
	case 0x5:
	case 0x6:
		sprintf(operation,"MOV.%s",size[MD0]);
		sprintf(operand,"R%hd,@-R%hd",Rm,Rn);
		pc += 2;
		break;
	case 0x7:
		operation = "DIV0S";
		sprintf(operand,"R%hd,R%hd",Rm,Rn);
		pc += 2;
		break;
	case 0x8:
	case 0x9:
	case 0xA:
	case 0xB:
	case 0xC:
	case 0xD:
	case 0xE:
	case 0xF:
		operation = op1[LSB & 0x7];
		sprintf(operand,"R%hd,R%hd",Rm,Rn);
		pc += 2;
		break;
	}
}



void MSB3(void)
{
char *op1[16]={"CMP/EQ","?","CMP/HS","CMP/GE","DIV1","DMULU.L","CMP/HI","CMP/GT",
			   "SUB","?","SUBC","SUBV","ADD","DMULS.L","ADDC","ADDC"};

if ( (LSB == 0x1) || (LSB == 0x9) ) return;
operation = op1[LSB];
sprintf(operand,"R%hd,R%hd",Rm,Rn);
pc += 2;
}



void MSB4(void)
{
char *op1[4]={"SHLL","DT","SHAL","?"};
char *op2[4]={"SHLR","CMP/PZ","SHAR","?"};
char *op4[4]={"ROTL","SETRC","ROTCL","?"};
char *op5[4]={"ROTR","CMP/PL","ROTCR","?"};
char *op6[4]={"2","8","16","?"};

switch(LSB)
	{
	case 0x0:
		switch (Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				operation = op1[Fx & 3];
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0x1:
		switch (Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				operation = op2[Fx & 3];
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0x2:
		if (invalid[Fx]) break;
		operation = "STS.L";
		sprintf(operand,"%s,@-R%hd",OREGS[Fx],Rn);
		pc += 2;
		break;
	case 0x3:
		switch (Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
			case 0x3:
			case 0x4:
				if ( (Fx) >= 5) return;
				operation = "STC.L";
				sprintf(operand,"%s,@-R%hd",SRGBR[Fx],Rn);
				pc += 2;
				break;
			case 0x8:
			case 0x9:
			case 0xa:
			case 0xb:
			case 0xc:
			case 0xd:
			case 0xe:
			case 0xf:
				operation = "STC.L";
				sprintf(operand,"R%hd_BANK,@-R%hd",Fx & 7,Rn);
				pc += 2;
				break;
			}
		break;
	case 0x4:
		switch(Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				operation = op4[Fx & 3];
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0x5:
		switch(Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
				operation = op5[Fx & 3];
				sprintf(operand,"R%hd",Rn);
				pc += 2;
				break;
			}
		break;
	case 0x6:
		if (invalid[Fx]) break;
		operation = "LDS.L";
		sprintf(operand,"@R%hd+,%s",Rn,OREGS[Fx]);
		pc += 2;
		break;
	case 0x7:
		switch(Fx)
			{
			case 0x0:
			case 0x1:
			case 0x2:
			case 0x3:
			case 0x4:
				if ( (Fx & 7) >= 5) return;
				operation = "LDC.L";
				sprintf(operand,"@R%hd+,%s",Rn,SRGBR[Fx & 7]);
				pc += 2;
				break;
			case 0x8:
			case 0x9:
			case 0xa:
			case 0xb:
			case 0xc:
			case 0xd:
			case 0xe:
			case 0xf:
				operation = "LDC.L";
				sprintf(operand,"@R%hd+,R%hd_BANK",Rn,Fx & 7);
				pc += 2;
				break;
			}
		break;
	case 0x8:
	case 0x9:
		if (Fx >= 3) return;
		sprintf(operation,(LSB==8) ? "SHLL%s" : "SHLR%s" ,op6[Fx & 3]);
		sprintf(operand,"R%hd",Rn);
		pc += 2;
		break;
	case 0xA:
		if (invalid[Fx]) break;
		operation = "LDS";
		sprintf(operand,"R%hd,%s",Rn,OREGS[Fx & 3]);
		pc += 2;
		break;
	case 0xB:
		switch (Fx)
			{
			case 0x0:
				operation = "JSR";
				sprintf(operand,"@R%hd",Rn);
				pc += 2;
				break;
			case 0x1:
				operation = "TAS.B";
				sprintf(operand,"@R%hd",Rn);
				pc += 2;
				break;
			case 0x2:
				operation = "JMP";
				sprintf(operand,"@R%hd",Rn);
				pc += 2;
				rupt = 1;
				break;
			}
		break;
	case 0xC:
	case 0xD:
		operation = (LSB == 0xC) ? "SHAD" : "SHLD";
		sprintf(operand,"R%hd,R%hd",Rn,Rm);
		pc += 2;
		break;
	case 0xE:
		if (Fx < 8)
			{
			if ( (Fx & 7) >= 5) return;
			operation = "LDC";
			sprintf(operand,"R%hd,%s",Rn,SRGBR[Fx & 7]);
			pc += 2;
			} else
			{
			operation = "LDC";
			sprintf(operand,"R%hd,R%hd_BANK",Rn,Fx & 7);
			pc += 2;
			}
		break;
	case 0xF:
		operation = "MAC.W";
		sprintf(operand,"@R%hd+,@R%hd+",Rm,Rn);
		pc += 2;
		break;
	}
}



void MSB5(void)
{
operation = "MOV.L";
sprintf(operand,"@($%02lX,R%hd),R%hd",LSB*4L,Rm,Rn);
pc += 2;
}



void MSB6(void)
{
char *op1[8]={"SWAP.B","SWAP.W","NEGC","NEG","EXTU.B","EXTU.W","EXTS.B","EXTS.W"};

switch(LSB)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
		operation = "MOV.B";
		sprintf(operand,"@R%hd,R%hd",Rm,Rn);
		pc += 2;
		break;
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		operation = "MOV.B";
		sprintf(operand,"@R%hd+,R%hd",Rm,Rn);
		pc += 2;
		break;
	case 0x8:
	case 0x9:
	case 0xa:
	case 0xb:
	case 0xc:
	case 0xd:
	case 0xe:
	case 0xf:
		operation = op1[LSB & 7];
		sprintf(operand,"R%hd,R%hd",Rm,Rn);
		pc += 2;
		break;
	}
}



void MSB7(void)
{
operation = "ADD";
sprintf(operand,"#$%02hX,R%hd",op & 0xFF,Rn);
pc += 2;
}



void MSB8(void)
{
switch(Rn)
	{
	case 0x0:
	case 0x1:
		sprintf(operation,"MOV.%s",size[Rn & 1]);
		sprintf(operand,"R0,@($%02lX,R%hd)",LSB*4L,Rm);
		pc += 2;
		break;
/*	case 0x2:
		operation = "SETRC";
		sprintf(operand,"#$%02hX",op & 0xFF);
		pc += 2;
		break;
*/	case 0x4:
	case 0x5:
		sprintf(operation,"MOV.%s",size[Rn & 1]);
		sprintf(operand,"@($%02lX,R%hd),R0",LSB*4L,Rm);
		pc += 2;
		break;
	case 0x8:
		operation = "CMP/EQ";
		sprintf(operand,"$%02hX,R0",op & 0xFF);
		pc += 2;
		break;
	case 0x9:
		operation = "BT";
		sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext8(op & 0xFF));
		pc += 2;
		break;
	case 0xB:
		operation = "BF";
		sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext8(op & 0xFF));
		pc += 2;
		break;
	case 0xC:
		operation = "LDRS";
#if OMITPCRELATIVE == 1
	sprintf(operand,"#$%02hX%02hX%02hX%02hX",rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3]);
#elif OMITPCRELATIVE == 2
	sprintf(operand,"#$%02hX%02hX%02hX%02hX    \t ; @($%08lX,PC)",rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3],OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF));
#else
	sprintf(operand,"@($%08lX,PC)=#$%02hX%02hX%02hX%02hX",OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF),rom[pc+4+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3]);
#endif
	mark(pc+PCRELATIVEOFFSET+2*(op & 0xFF),2);
	pc += 2;
		break;
	case 0xD:
		operation = "BT/S";
		sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext8(op & 0xFF));
		pc += 2;
		break;
	case 0xE:
		operation = "LDRE";
#if OMITPCRELATIVE == 1
	sprintf(operand,"#$%02hX%02hX%02hX%02hX",rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3]);
#elif OMITPCRELATIVE == 2
	sprintf(operand,"#$%02hX%02hX%02hX%02hX    \t ; @($%08lX,PC)",rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3],OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF));
#else
	sprintf(operand,"@($%08lX,PC)=#$%02hX%02hX%02hX%02hX",OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF),rom[pc+4+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+2],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+3]);
#endif
	mark(pc+PCRELATIVEOFFSET+2*(op & 0xFF),2);
	pc += 2;
		break;
	case 0xF:
		operation = "BF/S";
		sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext8(op & 0xFF));
		pc += 2;
		break;
	}
}



void MSB9(void)
{
operation = "MOV.W";
#if OMITPCRELATIVE == 1
sprintf(operand,"#$%02hX%02hX,R%hd",rom[pc+4+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],Rn);
#elif OMITPCRELATIVE == 2
sprintf(operand,"#$%02hX%02hX,R%hd    \t ; @($%08lX,PC)",rom[pc+4+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],Rn,OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF));
#else
sprintf(operand,"@($%08lX,PC)=#$%02hX%02hX,R%hd",OFFSET+pc+PCRELATIVEOFFSET+2*(op & 0xFF),rom[pc+4+2*(op & 0xFF)],rom[pc+PCRELATIVEOFFSET+2*(op & 0xFF)+1],Rn);
#endif
mark(pc+PCRELATIVEOFFSET+2*(op & 0xFF),2);
pc += 2;
}



void MSBA(void)
{
operation = "BRA";
sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext12(op));
rupt=1;
pc += 2;
}



void MSBB(void)
{
operation = "BSR";
sprintf(operand,"$%08lX",OFFSET+PCRELATIVEOFFSET+pc+2*sext12(op));
pc += 2;
}



void MSBC(void)
{
char *op1[4]={"TST","AND","XOR","OR"};

switch ( (Rn>>2) & 3)
	{
	case 0x0:
			if ((Rn & 3) < 3)
				{
				sprintf(operation,"MOV.%s",size[Rn & 3]);
				sprintf(operand,"R0,@($%03hX,GBR)",(op & 0xFF) * mult[Rn & 3]);
				pc += 2;
				} else
				{
				operation = "TRAPA";
				sprintf(operand,"$%03hX",(op & 0xFF) * 4);
				pc += 2;
				}
			break;
	case 0x1:
			if ((Rn & 3) < 3)
				{
				sprintf(operation,"MOV.%s",size[Rn & 3]);
				sprintf(operand,"@($%03hX,GBR),R0",(op & 0xFF) * mult[Rn & 3]);
				pc += 2;
				} else
				{
				operation = "MOVA";
#if OMITPCRELATIVE == 1
				sprintf(operand,"#$%02hX%02hX%02hX%02hX,R0",
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3]
							);
#elif OMITPCRELATIVE == 2
				sprintf(operand,"#$%02hX%02hX%02hX%02hX,R0\t ;@($%08hX,PC)",
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3],
							OFFSET+(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)
							);
#else
				sprintf(operand,"@($%08hX,PC)=#$%02hX%02hX%02hX%02hX,R0",OFFSET+(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF),
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3]
							);
#endif
				mark((pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF),4);
				pc += 2;
				}
			break;
	case 0x2:
			operation = op1[Rn & 3];
			sprintf(operand,"#$%02hX,R0",op & 0xFF);
			pc += 2;
			break;
	case 0x3:
			sprintf(operation,"%s.B",op1[Rn & 3]);
			sprintf(operand,"#$%02hX,@(R0,GBR)",op & 0xFF);
			pc += 2;
			break;
	}
}



void MSBD(void)
{
operation = "MOV.L";
#if OMITPCRELATIVE ==1 
sprintf(operand,"#$%02hX%02hX%02hX%02hX,R%hd",
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3]
							,Rn);
#elif OMITPCRELATIVE == 2
sprintf(operand,"#$%02hX%02hX%02hX%02hX,R%hd\t ; @($%08lX,PC)",
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3],
							Rn,
							OFFSET+(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)
							);
#else
sprintf(operand,"@($%08lX,PC)=#$%02hX%02hX%02hX%02hX,R%hd",OFFSET+(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF),
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+1],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+2],
							rom[(pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF)+3]
							,Rn);
#endif
mark((pc & 0xFFFFFFFC)+PCRELATIVEOFFSET+4*(op & 0xFF),4);
pc += 2;
}



void MSBE(void)
{
operation = "MOV";
sprintf(operand,"#$%02hX,R%hd",op & 0xFF,Rn);
pc += 2;
}



void MSBF(void)
{
}






void dis(void)
{

oldpc = pc;
rupt=0;

op = rom[pc]*256 + rom[pc+1];
MSB = (op >> 12) & 0xF;
Rn = (op >> 8) & 0xF;
Rm = (op >> 4) & 0xF;
LSB = op & 0xF;
Fx = Rm;
MD = Fx & 0x3;
MD0 = LSB & 0x3;

operationb[0]=0;
operation=operationb;
operandb[0]=0;
operand=operandb;
if ((!SHOWCONSTANT) || tag[pc] == 0)
	{
	switch (MSB)
		{
		case 0x0:
			MSB0();
			break;
		case 0x1:
			MSB1();
			break;
		case 0x2:
			MSB2();
			break;
		case 0x3:
			MSB3();
			break;
		case 0x4:
			MSB4();
			break;
		case 0x5:
			MSB5();
			break;
		case 0x6:
			MSB6();
			break;
		case 0x7:
			MSB7();
			break;
		case 0x8:
			MSB8();
			break;
		case 0x9:
			MSB9();
			break;
		case 0xA:
			MSBA();
			break;
		case 0xB:
			MSBB();
			break;
		case 0xC:
			MSBC();
			break;
		case 0xD:
			MSBD();
			break;
		case 0xE:
			MSBE();
			break;
		case 0xF:
			MSBF();
			break;
		}
	}

if (pc==oldpc )
	{
	if (SHOWCONSTANT)
		{
        switch(tag[pc])
			{
			case 1:
				operation=".DATA.B";
				sprintf(operand,"$%02hX,%02hX   \t ; Immediate constant",(unsigned short) rom[pc],(unsigned short) rom[pc+1]);
				unmark(pc,2);
				pc += 2;
				if (!tag[pc])
					rupt1=1;
					else
					rupt=0;
				break;
			case 2:
			default:
				operation=".DATA.W";
				sprintf(operand,"$%02hX%02hX    \t ; Immediate constant",(unsigned short) rom[pc],(unsigned short) rom[pc+1]);
				unmark(pc,2);
				pc += 2;
				if (!tag[pc])
					rupt1=1;
					else
					rupt=0;
				break;
			case 4:
				operation=".DATA.L";
				sprintf(operand,"$%02hX%02hX%02hX%02hX\t ; Immediate constant",
						(unsigned short) rom[pc],
						(unsigned short) rom[pc+1],
						(unsigned short) rom[pc+2],
						(unsigned short) rom[pc+3]
					);
				unmark(pc,4);
				pc += 4;
				if (!tag[pc])
					rupt1=2;
					else
					rupt=0;
				break;
			}
		} else
		{
		operation=".DATA.W";
		sprintf(operand,"$%02hX%02hX",(unsigned short) rom[pc],(unsigned short) rom[pc+1]);
		pc += 2;
		}
	}
}

void main(void)
{
FILE *fin,*fout;
char fnam[256];
unsigned long size;
char cdump[256];
char cbyte[16];
int ptr;
char line[256];
unsigned long l,i,n,endian,a,b;


printf("Binary file to disassemble : "); gets(fnam);
printf("Offset : "); gets(line); sscanf(line,"%lX",&OFFSET);
printf("Big(0) or Little(1) Endian : "); gets(line); sscanf(line,"%lX",&endian);

fin = fopen(fnam,"rb");
if (fin == NULL)
	{
	fprintf(stderr,"Cannot open input file.\n");
	return;
	}

size = fread(rom,1,sizeof(rom)/sizeof(rom[0]),fin);

if (endian)	// swap
	{
	for (i=0; i < size; i+=2)
		{
		a = rom[i];
		b = rom[i+1];
		rom[i] = b;
		rom[i+1] = a;
		}
	}

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL)
	{
	fprintf(stderr,"Cannot open output file.\n");
	return;
	}

rupt1=0;
memset(tag, 0, sizeof(tag));
pc = 0x0000000;
while (pc < size)
	{
	dis();
	strcpy(cdump,"");
	for (ptr=oldpc; ptr<pc; ptr++)
		{
		sprintf(cbyte,"%02hX",(short) rom[ptr]);
		strcat(cdump,cbyte);
		}

	sprintf(line,"%08lX %-20.20s\t%s\t%s",oldpc+OFFSET,cdump,operation,operand);
	fprintf(fout,"%s\n",line);
	// preceding two lines dumped max 10 bytes of hexa. Let's do the remaining bytes...
	l = ((pc-oldpc)>10) ? pc-oldpc-10 : 0;	// remaining bytes to dump
	ptr = oldpc+10;
	while (l)
		{
		n = (l>10) ? 10 : l;
		strcpy(cdump,"");
		for (i=0; i<n; i++)
			{
			sprintf(cbyte,"%02hX",(short) rom[ptr++]);
			strcat(cdump,cbyte);
			}
		sprintf(line,"         %-20.20s",cdump);
		fprintf(fout,"%s\n",line);
		l -= n;
		}
	switch(rupt1)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"-----------------------------------\n");
			fprintf(fout,"\n");
			break;
		}
        rupt1=rupt;
	}

fprintf(stderr,"Done.\n");
}

