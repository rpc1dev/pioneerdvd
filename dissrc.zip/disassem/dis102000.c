/*

Program originally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

History:

18-NOV-2000	Corrected BSET/BCLR ($xxxx)y disassembly.
25-MAY-2001	Added ascii dump (chris).

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define HEADER 0 // 0- no header, 1- 8184 header, 2- PD-2 LF-Dxxx header & D3xx, 3- PD-2 LF-D2xx header
				 //	4- 8186 header

#if HEADER==0
unsigned long ROMOFFSET;
#elif HEADER==1
unsigned long ROMOFFSET=0x81800;
#elif HEADER==2
unsigned long ROMOFFSET=0x84000;
#elif HEADER==3
unsigned long ROMOFFSET=0x88000;
#elif HEADER==4
unsigned long ROMOFFSET=0x80c00;
#endif

char *ra[4]={"A0","A1","A2","A3"};
char *rd[4]={"D0","D1","D2","D3"};
char operb[256];
char argsb[256];
char *oper;
char *args;
char line[256];
char rupt;

unsigned char n1,n2;
unsigned char b1;

unsigned char rom[512*1024];
unsigned long pc;


#define m (b1 & 3)
#define n ((b1>>2) & 3)
#define i ((b1>>4) & 3)
#define Am (ra[m])
#define Dm (rd[m])
#define An (ra[n])
#define Dn (rd[n])
#define Ai (ra[i])
#define Di (rd[i])

void exth(void)
{
b1 = rom[pc+2];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0xc:
		oper = (n2 < 8) ? "TBZ" : "TBNZ";
		sprintf(args,"($%02hX%02hX%02hX)%hd,$%08lX",(short) rom [pc+5],(short) rom [pc+4],(short) rom [pc+3],n2&7,pc+ROMOFFSET+7+(signed char) rom[pc+6]);
		pc = pc+7;
		break;
	case 0xd:
		oper = (n2 < 8) ? "BSET" : "BCLR";
		sprintf(args,"($%02hX%02hX%02hX)%hd",(short) rom [pc+5],(short) rom [pc+4],(short) rom [pc+3],n2&7);
		pc = pc+6;
		break;
	}
}

void exti(void)
{
b1 = rom[pc+2];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x8:
		oper = "TBZ";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom [pc+3],ra[(n&8)?3:2],n2&7,pc+ROMOFFSET+5+(signed char) rom [pc+4]);
		pc += 5;
		break;
	case 0x9:
		oper = "BSET";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom [pc+3],ra[(n&8)?3:2],n2&7);
		pc += 4;
		break;
	case 0xa:
		oper = "TBNZ";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom [pc+3],ra[(n&8)?3:2],n2&7,pc+ROMOFFSET+5+(signed char) rom [pc+4]);
		pc += 5;
		break;
	case 0xb:
		oper = "BLCR";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom [pc+3],ra[(n&8)?3:2],n2&7);
		pc += 4;
		break;
	}
}

void extj(void)
{
b1 = rom[pc+2];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

if (b1 > 1) return;
oper = (b1==0)?"MULQL":"MULQH";
b1 = rom[pc+1];
sprintf(args,"%s,%s",Dn,Dm);
pc += 3;
}

void extk(void)
{
b1 = rom[pc+2];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

if (b1 != 0x10) return;
oper = "MULQ";
b1 = rom[pc+1];
sprintf(args,"%s,%s",Dn,Dm);
pc += 3;
}

void extl(void)
{
b1 = rom[pc+2];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch(b1)
	{
	case 0x04:
		oper = "MULQL";
		b1 = rom[pc+1];
		sprintf(args,"$%02hX,%s",(short) rom[pc+3],Dm);
		pc += 4;
		break;
	case 0x05:
		oper = "MULQH";
		b1 = rom[pc+1];
		sprintf(args,"$%02hX,%s",(short) rom[pc+3],Dm);
		pc += 4;
		break;
	case 0x08:
		oper = "MULQL";
		b1 = rom[pc+1];
		sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],Dm);
		pc += 5;
		break;
	case 0x09:
		oper = "MULQH";
		b1 = rom[pc+1];
		sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],Dm);
		pc += 5;
		break;
	}
}

void exta(void)
{
b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
		if (n2 & 2) return;
		if (n2 & 1)
			{
			oper = "JSR";
			} else
			{
			oper = "JMP";
			rupt = 1;
			}
		sprintf(args,"(%s)",An);
		pc += 2;
		break;
	case 0x2:
		oper = "BSET";
		sprintf(args,"%s,(%s)",Dm,An);
		pc += 2;		
		break;
	case 0x3:
		oper = "BCLR";
		sprintf(args,"%s,(%s)",Dm,An);
		pc += 2;		
		break;
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		oper = "MOVB";
		sprintf(args,"(%s,%s),%s",Di,An,Dm);
		pc += 2;
		break;
	case 0x8:
	case 0x9:
	case 0xa:
	case 0xb:
		oper = "MOVBU";
		sprintf(args,"(%s,%s),%s",Di,An,Dm);
		pc += 2;
		break;
	case 0xc:
	case 0xd:
	case 0xe:
	case 0xf:
		oper = "MOVB";
		sprintf(args,"%s,(%s,%s)",Dm,Di,An);
		pc += 2;
		break;
	}
}

void extb(void)
{
b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
		oper = "MOV";
		sprintf(args,"(%s,%s),%s",Di,An,Am);
		pc += 2;
		break;
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		oper = "MOV";
		sprintf(args,"(%s,%s),%s",Di,An,Dm);
		pc += 2;
		break;
	case 0x8:
	case 0x9:
	case 0xa:
	case 0xb:
		oper = "MOV";
		sprintf(args,"%s,(%s,%s)",Am,Di,An);
		pc += 2;
		break;
	case 0xc:
	case 0xd:
	case 0xe:
	case 0xf:
		oper = "MOV";
		sprintf(args,"%s,(%s,%s)",Dm,Di,An);
		pc += 2;
		break;
	}
}

void extc(void)
{
char *op1[16] = {"ADD","SUB","CMP","MOV","ADD","SUB","CMP","MOV","ADDC","SUBC","","","ADD","SUB","CMP","MOV"};

b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

if ( (n1 == 0xa) || (n1 == 0xb) ) return;
oper = op1[n1];

switch (n1)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
		sprintf(args,"%s,%s",Dn,Am);
		break;
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x7:
		sprintf(args,"%s,%s",An,Am);
		break;
	case 0x8:
	case 0x9:
		sprintf(args,"%s,%s",Dn,Dm);
		break;
	case 0xc:
	case 0xd:
	case 0xe:
	case 0xf:
		sprintf(args,"%s,%s",An,Dm);
		break;
	}
pc += 2;
}

void extd(void)
{
char *op1[10]={"AND","OR","XOR","","MUL","MULU","DIVU","","","CMP"};
char *op2[4]={"ROL","ROR","ASR","LSR"};

b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x4:
	case 0x5:
	case 0x6:
	case 0x9:
		oper = op1[n1];
		sprintf(args,"%s,%s",Dn,Dm);
		pc += 2;
		break;
	case 0x3:
		oper = op2[n];
		sprintf(args,"%s",Dm);
		pc += 2;
		break;
	case 0xc:
		switch(m)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"%s,MDR",Dn);
				pc += 2;
				break;
			case 1:
				oper = "EXT";
				sprintf(args,"%s",Dn);
				pc += 2;
				break;
			case 2:
			case 3:
				return;
			}
		break;
	case 0xd:
		switch(m)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"%s,PSW",Dn);
				pc += 2;
				break;
			default:
				return;
			}
		break;
	case 0xe:
		switch(n)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"MDR,%s",Dm);
				pc += 2;
				break;
			case 1:
				oper = "NOT";
				sprintf(args,"%s",Dm);
				pc += 2;
				break;
			}
		break;
	case 0xf:
		switch(n)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"PSW,%s",Dm);
				pc += 2;
				break;
			case 3:
				switch(m)
					{
					case 0:
						oper = "PXST";
						pc += 2;
						break;
					case 2:
						exth();
						break;
					case 3:
						exti();
						break;
					}
				break;
			}
		break;
	}
}

void exte(void)
{
long d24;
b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX%02hX,%s)",Dm,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 5;
		break;
	case 0x1:
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX%02hX,%s)",Am,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 5;
		break;
	case 0x2:
		oper = "MOVB";
		sprintf(args,"%s,($%02hX%02hX%02hX,%s)",Dm,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 5;
		break;
	case 0x3:
		oper = "MOVX";
		sprintf(args,"%s,($%02hX%02hX%02hX,%s)",Dm,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 5;
		break;
	case 0x4:
		switch(n)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"%s,($%02hX%02hX%02hX)",Dm,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
				pc += 5;
				break;
			case 1:
				oper = "MOVB";
				sprintf(args,"%s,($%02hX%02hX%02hX)",Dm,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
				pc += 5;
				break;
			case 2:
				if (m != 3) return;
				oper = "BSET";
				sprintf(args,"$%02hX,($%02hX%02hX%02hX)",(short) rom[pc+5],(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
				pc += 6;
				break;
			case 3:
				if (m != 3) return;
				oper = "BCLR";
				sprintf(args,"$%02hX,($%02hX%02hX%02hX)",(short) rom[pc+5],(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
				pc += 6;
				break;
			}
		break;
	case 0x5:
		if (n != 0) return;
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX%02hX)",Am,(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
		pc += 5;
		break;
	case 0x6:
		switch(n)
			{
			case 0:
				oper = "ADD";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 1:
				oper = "ADD";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			case 2:
				oper = "SUB";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 3:
				oper = "SUB";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			}
		break;
	case 0x7:
		switch(n)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 1:
				oper = "MOV";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			case 2:
				oper = "CMP";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 3:
				oper = "CMP";
				sprintf(args,"$%02hX%02hX%02hX,%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			}
		break;
	case 0x8:
		oper = "MOV";
		sprintf(args,"($%02hX%02hX%02hX,%s),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 5;
		break;
	case 0x9:
		oper = "MOVBU";
		sprintf(args,"($%02hX%02hX%02hX,%s),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 5;
		break;
	case 0xa:
		oper = "MOVB";
		sprintf(args,"($%02hX%02hX%02hX,%s),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 5;
		break;
	case 0xb:
		oper = "MOVX";
		sprintf(args,"($%02hX%02hX%02hX,%s),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 5;
		break;
	case 0xc:
		switch(n)
			{
			case 0:
				oper = "MOV";
				sprintf(args,"($%02hX%02hX%02hX),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 1:
				oper = "MOVB";
				sprintf(args,"($%02hX%02hX%02hX),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			case 2:
				oper = "MOVBU";
				sprintf(args,"($%02hX%02hX%02hX),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 5;
				break;
			}
		break;
	case 0xd:
		if (n != 0) return;
		oper = "MOV";
		sprintf(args,"($%02hX%02hX%02hX),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],Am);
		pc += 5;
		break;
	case 0xe:
		switch(n)
			{
			case 0:
				switch(m)
					{
					case 0:
						oper = "JMP";
						rupt = 1;
						d24 = ((unsigned long) rom[pc+4]) * 0x10000 + ((unsigned long) rom[pc+3]) * 0x100 + ((unsigned long) rom[pc+2]);
						sprintf(args,"$%08lX",(pc+ROMOFFSET+5+d24) & 0xffffff);
						pc += 5;
						break;
					case 1:
						oper = "JSR";
						d24 = ((unsigned long) rom[pc+4]) * 0x10000 + ((unsigned long) rom[pc+3]) * 0x100 + ((unsigned long) rom[pc+2]);
						sprintf(args,"$%08lX",(pc+ROMOFFSET+5+d24) & 0xffffff);
						pc += 5;
						break;
					case 3:
						oper = "BSET";
						sprintf(args,"$%02hX,($%02hX%02hX)",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
						pc += 5;
						break;
					}
				break;
			case 1:
				if (m != 3) return;
				oper = "BCLR";
				sprintf(args,"$%02hX,($%02hX%02hX)",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2]);
				pc += 5;
				break;
			case 2:
				oper = "BSET";
				sprintf(args,"$%02hX,($%02hX,%s)",(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			case 3:
				oper = "BCLR";
				sprintf(args,"$%02hX,($%02hX,%s)",(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 5;
				break;
			}
		break;
	case 0xf:
		oper = "MOV";
		sprintf(args,"($%02hX%02hX%02hX,%s),%s",(short) rom[pc+4],(short) rom[pc+3],(short) rom[pc+2],An,Am);
		pc += 5;
		break;
	}
}

void extf(void)
{
char *op1[16] = {"BLTX","BGTX","BGEX","BLEX","BCSX","BHIX","BCCX","BLSX","BEQX","BNEX","","","BVCX","BVSX","BNCX","BNSX"};
char *op2[4] =  {"BVC","BVS","BNC","BNS"};
b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
		switch(n)
			{
			case 0:
				oper = "AND";
				sprintf(args,"$%02hX,%s",(short) rom[pc+2],Dm);
				pc += 3;
				break;
			case 1:
				oper = "BTST";
				sprintf(args,"$%02hX,%s",(short) rom[pc+2],Dm);
				pc += 3;
				break;
			case 2:
				oper = "OR";
				sprintf(args,"$%02hX,%s",(short) rom[pc+2],Dm);
				pc += 3;
				break;
			case 3:
				oper = "ADDNF";
				sprintf(args,"$%02hX,%s",(short) rom[pc+2],Am);
				pc += 3;
				break;
			}
		break;
	case 0x1:
		oper = "MOVB";
		sprintf(args,"%s,($%02hX,%s)",Dm,(short) rom[pc+2],An);
		pc += 3;
		break;
	case 0x2:
		oper = "MOVB";
		sprintf(args,"($%02hX,%s),%s",(short) rom[pc+2],An,Dm);
		pc += 3;
		break;
	case 0x3:
		oper = "MOVBU";
		sprintf(args,"($%02hX,%s),%s",(short) rom[pc+2],An,Dm);
		pc += 3;
		break;
	case 0x4:
		extj();
		break;
	case 0x5:
		oper = "MOVX";
		sprintf(args,"%s,($%02hX,%s)",Dm,(short) rom[pc+2],An);
		pc += 3;
		break;
	case 0x6:
		extk();
		break;
	case 0x7:
		oper = "MOVX";
		sprintf(args,"($%02hX,%s),%s",(short) rom[pc+2],An,Dm);
		pc += 3;
		break;
	case 0x8:
		oper = "TBZ";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom[pc+2],ra[(n2 & 8) ? 1 : 0],n2 & 7,pc+ROMOFFSET+4+(signed char) rom[pc+3]);
		pc += 4;
		break;
	case 0x9:
		oper = "BSET";
		sprintf(args,"($%02hX,%s)%hd",(short) rom[pc+2],ra[(n2 & 8) ? 1 : 0],n2 & 7);
		pc += 3;
		break;
	case 0xa:
		oper = "TBNZ";
		sprintf(args,"($%02hX,%s)%hd,$%08lX",(short) rom[pc+2],ra[(n2 & 8) ? 1 : 0],n2 & 7,pc+ROMOFFSET+4+(signed char) rom[pc+3]);
		pc += 4;
		break;
	case 0xb:
		oper = "BCLR";
		sprintf(args,"($%02hX,%s)%hd",(short) rom[pc+2],ra[(n2 & 8) ? 1 : 0],n2 & 7);
		pc += 3;
		break;
	case 0xc:
		switch(n)
			{
			case 0:
			case 1:
				oper = "TBZ";
				sprintf(args,"($%02hX%02hX)%hd,$%08lX",(short) rom[pc+3],(short) rom[pc+2],n2 & 7,pc+ROMOFFSET+5+(signed char) rom[pc+4]);
				pc += 5;
				break;
			case 2:
			case 3:
				oper = "TBNZ";
				sprintf(args,"($%02hX%02hX)%hd,$%08lX",(short) rom[pc+3],(short) rom[pc+2],n2 & 7,pc+ROMOFFSET+5+(signed char) rom[pc+4]);
				pc += 5;
				break;
			}
		break;
	case 0xd:
		switch(n)
			{
			case 0:
			case 1:
				oper = "BSET";
				sprintf(args,"($%02hX%02hX)%hd",(short) rom[pc+3],(short) rom[pc+2],n2 & 7);
				pc += 4;
				break;
			case 2:
			case 3:
				oper = "BCLR";
				sprintf(args,"($%02hX%02hX)%hd",(short) rom[pc+3],(short) rom[pc+2],n2 & 7);
				pc += 4;
				break;
			}
		break;
	case 0xe:
		if ( (n2 == 0xa) || (n2 == 0xb) ) return;
		oper = op1[n2];
		sprintf(args,"$%08lX",pc+ROMOFFSET+3+(signed char) rom[pc+2]);
		pc += 3;
		break;
	case 0xf:
		if (n2 < 8)
			{
			extl();
			return;
			}
		if (n2 < 12) return;
		oper = op2[n2-12];
		sprintf(args,"$%08lX",pc+ROMOFFSET+3+(signed char) rom[pc+2]);
		pc += 3;
		break;
	}
}

void extg(void)
{
b1 = rom[pc+1];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch (n1)
	{
	case 0x0:
		switch(n)
			{
			case 0:
				oper = "AND";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			case 1:
				oper = "BTST";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			case 2:
				oper = "ADD";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 4;
				break;
			case 3:
				oper = "SUB";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Am);
				pc += 4;
				break;
			}
		break;
	case 0x1:
		switch(n)
			{
			case 0:
				if (m != 0) return;
				oper = "AND";
				sprintf(args,"$%02hX%02hX,PSW",(short) rom[pc+3],(short) rom[pc+2]);
				pc += 4;
				break;
			case 1:
				if (m != 0) return;
				oper = "OR";
				sprintf(args,"$%02hX%02hX,PSW",(short) rom[pc+3],(short) rom[pc+2]);
				pc += 4;
				break;
			case 2:
				oper = "ADD";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			case 3:
				oper = "SUB";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			}
		break;
	case 0x2:
		if (n != 0) return;
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX)",Am,(short) rom[pc+3],(short) rom[pc+2]);
		pc += 4;
		break;
	case 0x3:
		if (n != 0) return;
		oper = "MOV";
		sprintf(args,"($%02hX%02hX),%s",(short) rom[pc+3],(short) rom[pc+2],Am);
		pc += 4;
		break;
	case 0x4:
		switch(n)
			{
			case 0:
				oper = "OR";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			case 2:
				oper = "CMP";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			case 3:
				oper = "XOR";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+3],(short) rom[pc+2],Dm);
				pc += 4;
				break;
			}
		break;
	case 0x5:
		oper = "MOVBU";
		sprintf(args,"($%02hX%02hX,%s),%s",(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 4;
		break;
	case 0x6:
		oper = "MOVX";
		sprintf(args,"%s,($%02hX%02hX,%s)",Dm,(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 4;
		break;
	case 0x7:
		oper = "MOVX";
		sprintf(args,"($%02hX%02hX,%s),%s",(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 4;
		break;
	case 0x8:
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX,%s)",Dm,(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 4;
		break;
	case 0x9:
		oper = "MOVB";
		sprintf(args,"%s,($%02hX%02hX,%s)",Dm,(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 4;
		break;
	case 0xa:
		oper = "MOV";
		sprintf(args,"%s,($%02hX%02hX,%s)",Am,(short) rom[pc+3],(short) rom[pc+2],An);
		pc += 4;
		break;
	case 0xb:
		oper = "MOV";
		sprintf(args,"($%02hX%02hX,%s),%s",(short) rom[pc+3],(short) rom[pc+2],An,Am);
		pc += 4;
		break;
	case 0xc:
		oper = "MOV";
		sprintf(args,"($%02hX%02hX,%s),%s",(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 4;
		break;
	case 0xd:
		oper = "MOVB";
		sprintf(args,"($%02hX%02hX,%s),%s",(short) rom[pc+3],(short) rom[pc+2],An,Dm);
		pc += 4;
		break;
	}
}

void dodis(void)
{
// do the real disassembly.
// if rom[pc] is not an instruction, do nothing, do NOT increment pc.
// if pc is incremented, oper and args are the instruction description

char *op1[4]={"EXTX","EXTXU","EXTXB","EXTXBU"};
char *op2[4]={"MOV","MOVB","MOV","MOVBU"};
char *op3[4]={"ADD","ADD","CMP","MOV"};
char *op4[16]={"BLT","BGT","BGE","BLE","BCS","BHI","BCC","BLS","BEQ","BNE","BRA","RTI","CMP","CMP","CMP","CMP"};


rupt = 0;

b1 = rom[pc];
n1 = (b1 >> 4) & 0xF;
n2 = (b1) & 0xF;

switch(n1)
	{
	case 0x0:
		oper = "MOV";
		sprintf(args,"%s,(%s)",Dm,An);
		pc++;
		break;
	case 0x1:
		oper = "MOVB";
		sprintf(args,"%s,(%s)",Dm,An);
		pc++;
		break;
	case 0x2:
		oper = "MOV";
		sprintf(args,"(%s),%s",An,Dm);
		pc++;
		break;
	case 0x3:
		oper = "MOVBU";
		sprintf(args,"(%s),%s",An,Dm);
		pc++;
		break;
	case 0x4:
		oper = "MOV";
		sprintf(args,"%s,($%02hX,%s)",Dm,(short) rom[pc+1],An);
		pc+=2;
		break;
	case 0x5:
		oper = "MOV";
		if (rom[pc+1] == 0)
			sprintf(args,"%s,(%s)",Am,An);
			else
			sprintf(args,"%s,($%02hX,%s)",Am,(short) rom[pc+1],An);
		pc+=2;
		break;
	case 0x6:
		oper = "MOV";
		sprintf(args,"($%02hX,%s),%s",(short) rom[pc+1],An,Dm);
		pc+=2;
		break;
	case 0x7:
		oper = "MOV";
		if (rom[pc+1] == 0)
			sprintf(args,"(%s),%s",An,Am);
			else
			sprintf(args,"($%02hX,%s),%s",(short) rom[pc+1],An,Am);
		pc+=2;
		break;
	case 0x8:
		if ( m == n )
			{
			oper = "MOV";
			sprintf(args,"$%02hX,%s\t\t\t;'%c'",(short) rom[pc+1],Dm, isprint(rom[pc+1])?(rom[pc+1]):'?');
			pc += 2;
			}
			else
			{
			oper = "MOV";
			sprintf(args,"%s,%s",Dn,Dm);
			pc++;
			}
		break;
	case 0x9:
		oper = "ADD";
		sprintf(args,"%s,%s",Dn,Dm);
		pc++;
		break;
	case 0xa:
		oper = "SUB";
		sprintf(args,"%s,%s",Dn,Dm);
		pc++;
		break;
	case 0xb:
		oper = op1[n];
		sprintf(args,"%s",Dm);
		pc++;
		break;
	case 0xc:
		oper = op2[n];
		if (n < 2)
			sprintf(args,"%s,($%02hX%02hX)",Dm,(short) rom[pc+2],(short) rom[pc+1]);
			else
			sprintf(args,"($%02hX%02hX),%s",(short) rom[pc+2],(short) rom[pc+1],Dm);
		pc += 3;
		break;
	case 0xd:
		oper = op3[n];
		switch(n)
			{
			case 0:
				sprintf(args,"$%02hX,%s",(short) rom[pc+1],Am);
				pc += 2;
				break;
			case 1:
			case 2:
				sprintf(args,"$%02hX,%s\t\t\t;'%c'",(short) rom[pc+1],Dm,isprint(rom[pc+1])?(rom[pc+1]):('?'));
				pc += 2;
				break;
			case 3:
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+2],(short) rom[pc+1],Am);
				pc += 3;
				break;
			}
		break;
	case 0xe:
		oper = op4[n2];
		if (n2 == 0xa) rupt = 1;
		if (n2 == 0xb) rupt = 2;
		switch(n2)
			{
			case 0xb:
				pc++;
				break;
			case 0xc:
			case 0xd:
			case 0xe:
			case 0xf:
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+2],(short) rom[pc+1],Am);
				pc += 3;
				break;
			default:
				sprintf(args,"$%08lX",pc+ROMOFFSET+2+(signed char) (rom[pc+1]) );
				pc += 2;
				break;
			}
		break;
	case 0xf:
		switch(n2)
			{
			case 0x0:
				exta();
				break;
			case 0x1:
				extb();
				break;
			case 0x2:
				extc();
				break;
			case 0x3:
				extd();
				break;
			case 0x4:
				exte();
				break;
			case 0x5:
				extf();
				break;
			case 0x6:
				oper = "NOP";
				pc++;
				break;
			case 0x7:
				extg();
				break;
			case 0x8:
			case 0x9:
			case 0xa:
			case 0xb:
				oper = "MOV";
				sprintf(args,"$%02hX%02hX,%s",(short) rom[pc+2],(short) rom[pc+1],Dm);
				pc += 3;
				break;
			case 0xc:
				oper = "JMP";
				rupt = 1;
				sprintf(args,"$%08lX",pc+ROMOFFSET+3+((short) (rom[pc+2]*256+rom[pc+1])));
				pc += 3;
				break;
			case 0xd:
				oper = "JSR";
				sprintf(args,"$%08lX",pc+ROMOFFSET+3+((short) (rom[pc+2]*256+rom[pc+1])));
				pc += 3;
				break;
			case 0xe:
				oper = "RTS";
				rupt = 2;
				pc++;
				break;
			}
		break;
	}
}

void dis(void)
{
unsigned long oldpc;
char cdump[256];
char ddump[256];
char cbyte[16];
int ptr;

strcpy(operb,"");
strcpy(argsb,"");
oper = operb;
args = argsb;

oldpc = pc;

dodis();

if (pc == oldpc)
	{
	oper = "DC.B";
	sprintf(args,"$%02hX",(short) rom[pc++]);
	}
strcpy(cdump,"");
for (ptr=oldpc; ptr<pc; ptr++)
	{
	sprintf(cbyte,"%02hX",(short) rom[ptr]);
	strcat(cdump,cbyte);
	}


// now add the dump of the characters :-)
strcpy(ddump,"");
for (ptr=oldpc; ptr<pc; ptr++)
	{
	sprintf(cbyte,"%c",isprint(rom[ptr])?(rom[ptr]):('?'));
	strcat(ddump,cbyte);
	}

sprintf(line,"%08lX %-12.12s\t%-12.12s\t%s\t%s",oldpc+ROMOFFSET,cdump,ddump,oper,args);
}


void main(void)
{
unsigned long len,l;
char fnam[256];
FILE *fin,*fout;


printf("File name : "); gets(fnam);
fin = fopen(fnam,"rb");
if (fin == NULL) return;

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL) return;

#if (HEADER==2) || (HEADER==3)
fread(rom,0x30,1,fin);
if (memcmp(rom,"MATSHITA",8))
	{
	fprintf(stderr,"Error: invalid file.\n");
	return;
	}
len = rom[0x24]*0x1000000 + rom[0x25]*0x10000 + rom[0x26]*0x100 + rom[0x27];

#elif HEADER==1
fread(rom,0x20,1,fin);
if (memcmp(rom,"MATSHITA SR8184 DOWNLOAD",24))
	{
	fprintf(stderr,"Error: invalid file.\n");
	return;
	}
len = rom[0x1c]*0x1000000 + rom[0x1d]*0x10000 + rom[0x1e]*0x100 + rom[0x1f];
#elif HEADER==4
fread(rom,0x20,1,fin);
if (memcmp(rom,"MATSHITA DV",11))
	{
	fprintf(stderr,"Error: invalid file.\n");
	return;
	}
len = rom[0x1c]*0x1000000 + rom[0x1d]*0x10000 + rom[0x1e]*0x100 + rom[0x1f];
#elif HEADER==0
len = sizeof(rom)/sizeof(rom[0]);
#endif
l = fread(rom,1,len,fin);
#if HEADER==0
len = l;
printf("Address of first byte of file (hex, e.g 80000, 81800 or 80c00): ");
scanf("%x",&ROMOFFSET);
#endif

for (pc=0; pc < len; )
	{
	dis();
	fprintf(fout,"%s\n",line);
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"---------------------------\n");
			fprintf(fout,"\n");
			break;
		}
	}
printf("Done.\n");
}
