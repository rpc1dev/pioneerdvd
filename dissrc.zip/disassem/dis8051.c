/*

Program originally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

History:

03-MAY-2001	First version. Not extensively tested yet.
16-JUL-2001 Corrected Jcc SFRxx.b,dest

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned long ROMOFFSET;
unsigned char b1,b2,b3;
unsigned char H,L;
#define Rn (L & 7)
#define ARn (L & 1)

char operb[256];
char argsb[256];
char *oper;
char *args;
char line[256];
char rupt;

char *opreg[16]={"INC","DEC","ADD","ADDC",
              "ORL","ANL","XRL","MOV",
              "MOV","SUBB","MOV","CJNE",
              "XCH","DJNZ","MOV","MOV"};
char *bitadd[32]={"SFR00","SFR08","SFR10","SFR18",
                  "SFR20","SFR28","SFR30","SFR38",
                  "SFR40","SFR48","SFR50","SFR58",
                  "SFR60","SFR68","SFR70","SFR78",
                  "P0","TCON","P1","SCON",
                  "P2","IE","P3","IP",
                  "SFRC0","T2CON","PSW","SFRD8",
                  "ACC","SFRE8","B","SFRF8",
                 };



unsigned char rom[512*1024];
unsigned long pc;




void Ajmp(void)
{
unsigned short Add;


Add = (b1 & 0xE0) << 3 | b2;
if (H & 1)
	{
	oper = "ACALL";
	} else
	{
	oper = "AJMP";
	rupt = 1;
	}
sprintf(args,"$%04hX",Add);
pc += 2;
}



void OpRn(void)
{
char *ar[16]={"R%hd","R%hd","A,R%hd","A,R%hd",
              "A,R%hd","A,R%hd","A,R%hd","R%hd,#$%02hX",
              "$%02hX,R%hd","A,R%hd","R%hd,$%02hX","R%hd,#$%02hX,$%04hX",
              "A,R%hd","R%hd,$%04hX","A,R%hd","R%hd,A"};

oper = opreg[H];
switch(H)
	{
case 0x0:
case 0x1:
case 0x2:
case 0x3:
case 0x4:
case 0x5:
case 0x6:
case 0x9:
case 0xC:
case 0xE:
case 0xF:
	sprintf(args,ar[H],Rn);
	pc++;
	break;
case 0x7:
case 0xA:
	sprintf(args,ar[H],Rn,b2);
	pc += 2;
	break;
case 0x8:
	sprintf(args,ar[H],b2,Rn);
	pc += 2;
	break;
case 0xB:
	sprintf(args,ar[H],Rn,b2,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0xD:
	sprintf(args,ar[H],Rn,pc+2+(signed char) b2);
	pc += 2;
	break;
	}
}


void OpARn(void)
{
char *ar[16]={"@R%hd","@R%hd","A,@R%hd","A,@R%hd",
              "A,@R%hd","A,@R%hd","A,@R%hd","@R%hd,#$%02hX",
              "$%02hX,@R%hd","A,@R%hd","@R%hd,$%02hX","@R%hd,#$%02hX,$%04hX",
              "A,@R%hd","@R%hd,$%04hX","A,@R%hd","@R%hd,A"};

oper = opreg[H];
switch(H)
	{
case 0x0:
case 0x1:
case 0x2:
case 0x3:
case 0x4:
case 0x5:
case 0x6:
case 0x9:
case 0xC:
case 0xE:
case 0xF:
	sprintf(args,ar[H],ARn);
	pc++;
	break;
case 0x7:
case 0xA:
	sprintf(args,ar[H],ARn,b2);
	pc += 2;
	break;
case 0x8:
	sprintf(args,ar[H],b2,ARn);
	pc += 2;
	break;
case 0xB:
	sprintf(args,ar[H],ARn,b2,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0xD:
	sprintf(args,ar[H],ARn,pc+2+(signed char) b2);
	pc += 2;
	break;
	}

}

void L0(void)
{
char *op1[3]={"JBC","JB","JNB"};
char *op2[5]={"JC","JNC","JZ","JNZ","SJMP"};
char *op3[2]={"ORL","ANL"};
char *op4[2]={"PUSH","POP"};

switch (H)
	{
case 0x0:
	oper = "NOP";
	pc++;
	break;
case 0x1:
case 0x2:
case 0x3:
	oper = op1[H-0x1];
	sprintf(args,"%s.%hd,$%04hX",bitadd[(b2 & ~7)>>3],b2 & 7,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0x4:
case 0x5:
case 0x6:
case 0x7:
case 0x8:
	oper = op2[H-0x4];
	sprintf(args,"$%04hX",pc+2+(signed char) b2);
	pc += 2;
	break;
case 0x9:
	oper = "MOV";
	sprintf(args,"DPTR,#$%02hX%02hX",b2,b3);
	pc += 3;
	break;
case 0xa:
case 0xb:
	oper = op3[H-0xa];
	sprintf(args,"C,/%s.%hd",bitadd[(b2 >> 3) & 0x1F ],b2 & 7);
	pc += 2;
	break;
case 0xc:
case 0xd:
	oper = op4[H-0xc];
	sprintf(args,"$%02hX",b2);
	pc += 2;
	break;
case 0xe:
	oper = "MOVX";
	args = "A,@DPTR";
	pc++;
	break;
case 0xf:
	oper = "MOVX";
	args = "@DPTR,A";
	pc++;
	break;
	}
}



void L2(void)
{
switch(H)
	{
case 0x0:
	oper = "LJMP";
	sprintf(args,"$%04hX",pc+3+(signed short) (b2*256+b3));
	pc += 3;
	break;
case 0x1:
	oper = "LCALL";
	sprintf(args,"$%04hX",pc+3+(signed short) (b2*256+b3));
	pc += 3;
	break;
case 0x2:
	oper = "RET";
	rupt = 2;
	pc++;
	break;
case 0x3:
	oper = "RETI";
	rupt = 2;
	pc++;
	break;
case 0x4:
	oper = "ORL";
	sprintf(args,"$%02hX,A",b2);
	pc += 2;
	break;
case 0x5:
	oper = "ANL";
	sprintf(args,"$%02hX,A",b2);
	pc += 2;
	break;
case 0x6:
	oper = "XRL";
	sprintf(args,"$%02hX,A",b2);
	pc += 2;
	break;
case 0x7:
	oper = "ORL";
	sprintf(args,"C,%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0x8:
	oper = "ANL";
	sprintf(args,"C,%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0x9:
	oper = "MOV";
	sprintf(args,"%s.%hd,C",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0xa:
	oper = "MOV";
	sprintf(args,"C,%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0xb:
	oper = "CPL";
	sprintf(args,"%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0xc:
	oper = "CLR";
	sprintf(args,"%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0xd:
	oper = "SETB";
	sprintf(args,"%s.%hd",bitadd[(b2 & ~7)>>3],b2 & 7);
	pc += 2;
	break;
case 0xe:
	oper = "MOVX";
	args=  "A,@R0";
	pc++;
	break;
case 0xf:
	oper = "MOVX";
	args=  "@R0,A";
	pc++;
	break;
	}
}


void L3(void)
{
switch(H)
	{
case 0x0:
	oper = "RR";
	args = "A";
	pc++;
	break;
case 0x1:
	oper = "RRC";
	args = "A";
	pc++;
	break;
case 0x2:
	oper = "RL";
	args = "A";
	pc++;
	break;
case 0x3:
	oper = "RLC";
	args = "A";
	pc++;
	break;
case 0x4:
	oper = "ORL";
	sprintf(args,"$%02hX,#%02hX",b2,b3);
	pc += 3;
	break;
case 0x5:
	oper = "ANL";
	sprintf(args,"$%02hX,#%02hX",b2,b3);
	pc += 3;
	break;
case 0x6:
	oper = "XRL";
	sprintf(args,"$%02hX,#%02hX",b2,b3);
	pc += 3;
	break;
case 0x7:
	oper = "JMP";
	args = "@A+DPTR";
	pc++;
	break;
case 0x8:
	oper = "MOVC";
	args = "@A+PC";
	pc++;
	break;
case 0x9:
	oper = "MOVC";
	args = "@A+DPTR";
	pc++;
	break;
case 0xa:
	oper = "INC";
	args = "DPTR";
	pc++;
	break;
case 0xb:
	oper = "CPL";
	args = "C";
	pc++;
	break;
case 0xc:
	oper = "CLR";
	args = "C";
	pc++;
	break;
case 0xd:
	oper = "SETB";
	args = "C";
	pc++;
	break;
case 0xe:
	oper = "MOVX";
	args=  "A,@R1";
	pc++;
	break;
case 0xf:
	oper = "MOVX";
	args=  "@R1,A";
	pc++;
	break;
	}
}



void L4(void)
{
switch(H)
	{
case 0x0:
	oper = "INC";
	args = "A";
	pc++;
	break;
case 0x1:
	oper = "DEC";
	args = "A";
	pc++;
	break;
case 0x2:
	oper = "ADD";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x3:
	oper = "ADDC";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x4:
	oper = "ORL";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x5:
	oper = "ANL";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x6:
	oper = "XRL";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x7:
	oper = "MOV";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0x8:
	oper = "DIV";
	args = "AB";
	pc++;
	break;
case 0x9:
	oper = "SUBB";
	sprintf(args,"A,#%02hX",b2);
	pc += 2;
	break;
case 0xa:
	oper = "MUL";
	args = "AB";
	pc++;
	break;
case 0xb:
	oper = "CJNE";
	sprintf(args,"A,#%02hX,$%04hX",b2,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0xc:
	oper = "SWAP";
	args = "A";
	pc++;
	break;
case 0xd:
	oper = "DA";
	args = "A";
	pc++;
	break;
case 0xe:
	oper = "CLR";
	args = "A";
	pc++;
	break;
case 0xf:
	oper = "CPL";
	args = "A";
	pc++;
	break;
	}
}



void L5(void)
{
switch(H)
	{
case 0X0:
	oper = "INC";
	sprintf(args,"$%02hX",b2);
	pc += 2;
	break;
case 0X1:
	oper = "DEC";
	sprintf(args,"$%02hX",b2);
	pc += 2;
	break;
case 0X2:
	oper = "ADD";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0X3:
	oper = "ADDC";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0X4:
	oper = "ORL";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0X5:
	oper = "ANL";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0X6:
	oper = "XRL";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0X7:
	oper = "MOV";
	sprintf(args,"$%02hX,#$%02hX",b2,b3);
	pc += 3;
	break;
case 0X8:
	oper = "MOV";
	sprintf(args,"$%02hX,$%02hX",b3,b2);
	pc += 3;
	break;
case 0X9:
	oper = "SUBB";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0Xa:
	break;
case 0Xb:
	oper = "CJNE";
	sprintf(args,"A,$%02hX,$%04hX",b2,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0Xc:
	oper = "XCH";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0Xd:
	oper = "DJNZ";
	sprintf(args,"$%02hX,$%04hX",b2,pc+3+(signed char) b3);
	pc += 3;
	break;
case 0Xe:
	oper = "MOV";
	sprintf(args,"A,$%02hX",b2);
	pc += 2;
	break;
case 0Xf:
	oper = "MOV";
	sprintf(args,"$%02hX,A",b2);
	pc += 2;
	break;
	}
}



void dodis(void)
{
// do the real disassembly.
// if rom[pc] is not an instruction, do nothing, do NOT increment pc.
// if pc is incremented, oper and args are the instruction description

rupt = 0;

b1 = rom[pc];
b2 = rom[pc+1];
b3 = rom[pc+2];

H = ( b1 >> 4 ) & 0xF;
L = b1 & 0xF;


switch(L)
	{
case 0x0:
	L0();
	break;
case 0x1:
	Ajmp();
	break;
case 0x2:
	L2();
	break;
case 0x3:
	L3();
	break;
case 0x4:
	L4();
	break;
case 0x5:
	L5();
	break;
case 0x6:
case 0x7:
	OpARn();
	break;
case 0x8:
case 0x9:
case 0xA:
case 0xB:
case 0xC:
case 0xD:
case 0xE:
case 0xF:
	OpRn();
	break;
	}
}

void dis(void)
{
unsigned long oldpc;
char cdump[256];
char cbyte[16];
int ptr;

strcpy(operb,"");
strcpy(argsb,"");
oper = operb;
args = argsb;

oldpc = pc;

dodis();

if (pc == oldpc)
	{
	oper = "DC.B";
	sprintf(args,"$%02hX",(short) rom[pc++]);
	}
strcpy(cdump,"");
for (ptr=oldpc; ptr<pc; ptr++)
	{
	sprintf(cbyte,"%02hX",(short) rom[ptr]);
	strcat(cdump,cbyte);
	}

sprintf(line,"%08lX %-8.8s\t%s\t%s",oldpc+ROMOFFSET,cdump,oper,args);
}


void main(void)
{
unsigned long len,l;
char fnam[256];
FILE *fin,*fout;


printf("File name : "); gets(fnam);
fin = fopen(fnam,"rb");
if (fin == NULL) return;

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL) return;

len = sizeof(rom)/sizeof(rom[0]);

l = fread(rom,1,len,fin);

len = l;
printf("Address of first byte of file : ");
scanf("%x",&ROMOFFSET);

for (pc=0; pc < len; )
	{
	dis();
	fprintf(fout,"%s\n",line);
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"---------------------------\n");
			fprintf(fout,"\n");
			break;
		}
	}
printf("Done.\n");
}
