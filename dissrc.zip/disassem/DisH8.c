/*
This program was originally written by xvi.
It was written with compatibility in mind, so it should compile and
run on most platform, little or big endian, Mac, PC, Linux, Unix, etc.
I have tested it on Mac and Digital Unix.

You may do what you want with it, all I ask is that you send me the modified
source if you make corrections or enhancements.

Thanks!

xvi91@hotmail.com


*/

// kindly enhanced by mjx
// 07-OCT-2001	Corrected LDM/STM disassembly (ouch).

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned long OFFSET; // real-world address of rom[0]

char *rd8[16]={"R0H","R1H","R2H","R3H","R4H","R5H","R6H","R7H",
			   "R0L","R1L","R2L","R3L","R4L","R5L","R6L","R7L"};
char *rd16[16]={"R0","R1","R2","R3","R4","R5","R6","R7",
				"E0","E1","E2","E3","E4","E5","E6","E7"};
char *rd32[8]={"ER0","ER1","ER2","ER3","ER4","ER5","ER6","ER7"};
char *cond[17]={"RA","RN","HI","LS","CC","CS","NE","EQ",
				"VC","VS","PL","MI","GE","LT","GT","LE","SR"};
char *flag[8]={"I","UI","H","U","N","Z","V","C"};

unsigned char ah,al,bh,bl,ch,cl,dh,dl,eh,el,fh,fl,gh,gl,hh,hl,ih,il,jh,jl;
unsigned char ahal,bhbl,chcl,dhdl,ehel,fhfl,ghgl,hhhl;
unsigned char rom[512*1024 + 64];
unsigned long pc;
unsigned long oldpc;
FILE *fout;
unsigned long vectormin,vectormax;



void imm32rd32(char *op)
{
if (bl & 8) return;
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.L\t#$%02hX%02hX%02hX%02hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		(short) rom[pc+4],
		(short) rom[pc+5],
		op,
		(short) rom[pc+2],
		(short) rom[pc+3],
		(short) rom[pc+4],
		(short) rom[pc+5],
		rd32[bl]);
pc += 6;
}

void imm16rd16(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t#$%04hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		(short) chcl*256+dhdl,
		rd16[bl]);
pc += 4;
}

void bset(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s\t#$%hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		(short) bh,
		rd8[bl]);
pc += 2;
}

void jmpern(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s\t@%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bh]);
pc += 2;
}

void jmpa24(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s\t@#$%08lX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		(unsigned long) bhbl*65536+chcl*256+dhdl);
pc += 4;
}

void jmpaa8(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s\t@@$%02hX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		(short) bhbl);
pc += 2;
}

void orc(char *op,char *reg,unsigned char imm, char flags)
{
char fstr[256];
int i;
unsigned char v;

strcpy(fstr,"");
if (flags > 0) v=imm; else v=~imm;
for (i=7; i>=0; i--)
	{
	if (v & (1<<i))
		{
		strcat(fstr,flag[7-i]);
		if (v & ((1<<i)-1))
			{
			strcat(fstr,",");
			}
		}
	}

fprintf(fout,"%08lX %02hX%02hX                 %s.B\t#$%02hX,%s\t; %s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		(short) imm,
		reg,
		fstr);
pc += 2;
}

void stc(char *op,char *reg)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		reg,
		rd8[bl]);
pc += 2;
}

void stmac(char *op,char *reg)
{
if (bl & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		reg,rd32[bl]);
pc += 2;
}

void ldc(char *op,char *reg)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd8[bl],
		reg);
pc += 2;
}

void ldmac(char *op,char *reg)
{
if (bl & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bl],reg);
pc += 2;
}

void bcc8(char c)
{
fprintf(fout,"%08lX %02hX%02hX                 B%s.B\t$%08lX\n%s",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		cond[c],
		pc+OFFSET+2+(signed char) bhbl,
		(c==0)?"\n":"");
pc += 2;
}

void bcc16(char c)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%s.W\t$%08lX\n%s",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		cond[c],
		pc+OFFSET+4+(signed short) (chcl*256+dhdl),
		(c==0)?"\n":"");
pc += 4;
}

void rs16rd32(char *op)
{
if (bl & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd16[bh],rd32[bl]);
pc += 2;
}

void ars32rd8(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t@%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bh],
		rd8[bl]);
pc += 2;
}

void rs8ard32(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,@%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd8[bl],
		rd32[bh]);
pc += 2;
}

void ars32rd16(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t@%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bh],
		rd16[bl]);
pc += 2;
}

void rs16ard32(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s,@%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd16[bl],
		rd32[bh]);
pc += 2;
}

void aimm16rd16(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t@$%04hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,(short) chcl*256+dhdl,
		rd16[bl]);
pc += 4;
}

void aimm32rd16(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.W\t@$%08lX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		(short) rom[pc+4],
		(short) rom[pc+5],
		op,
		(unsigned long) chcl*0x1000000+dhdl*0x10000+ehel*256+fhfl,
		rd16[bl]);
pc += 6;
}

void rd16aimm16(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t%s,@$%04hX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		rd16[bl],
		(short) chcl*256+dhdl);
pc += 4;
}

void rd16aimm32(char *op)
{
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.W\t%s,@$%08lX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		(short) rom[pc+4],
		(short) rom[pc+5],
		op,
		rd16[bl],
		(unsigned long) chcl*0x1000000+dhdl*0x10000+ehel*256+fhfl);
pc += 6;
}

void ard32prd8(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t@%s+,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bh],rd8[bl]);
pc += 2;
}

void rs8ard32m(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,@-%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd8[bl],
		rd32[bh]);
pc += 2;
}

void ard32prd16(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t@%s+,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd32[bh],
		rd16[bl]);
pc += 2;
}

void rs16ard32m(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s,@-%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd16[bl],
		rd32[bh]);
pc += 2;
}

void ard32disp16rd8(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t@($%04hX,%s),%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		(short) chcl*256+dhdl,
		rd32[bh],rd8[bl]);
pc += 4;
}

void rd16ard32disp8(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t%s,@($%04hX,%s)\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		rd8[bl],
		(short) chcl*256+dhdl,
		rd32[bh]);
pc += 4;
}

void ard32disp16rd16(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t@($%04hX,%s),%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		(short) chcl*256+dhdl,
		rd32[bh],rd16[bl]);
pc += 4;
}

void rd16ard32disp16(char *op)
{
if (bh & 8) return;
fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t%s,@($%04hX,%s)\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		op,
		rd16[bl],
		(short) chcl*256+dhdl,rd32[bh]);
pc += 4;
}

void rsrd8(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd8[bh],
		rd8[bl]);
pc += 2;
}

void rsrd16(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd16[bh],
		rd16[bl]);
pc += 2;
}

void tbl1(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t#$%02hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		(short) bhbl,
		rd8[al]);
pc += 2;
}

void tbl1at(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t@$%02hX,%s\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		(short) bhbl,
		rd8[al]);
pc += 2;
}

void tbl1atr(char *op)
{
fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s,@$%02hX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		op,
		rd8[al],
		(short) bhbl);
pc += 2;
}






void tbl4()
{
char *op1[4]={"BSET","BNOT","BCLR","BTST"};
char *op2[5]={"OR","XOR","AND","LD","ST"};
char op;
unsigned long bhblehel;

if (ahal != 0x6a) return;
if ( (bhbl != 0x10) && (bhbl != 0x18) && (bhbl != 0x30) && (bhbl != 0x38) ) return;
if ( ( (bhbl == 0x10) || (bhbl == 0x18) ) && ( (eh != 6) && (eh != 7) ) ) return;
if ( ( (bhbl == 0x30) || (bhbl == 0x38) ) && ( (gh != 6) && (gh != 7) ) ) return;

bhblehel = bhbl*0x100 + eh*0x10 + el;
if (bh == 3) bhblehel = bhbl*0x100 + gh*0x10 + gl;

switch (bhblehel)
	{
	case 0x1860:
	case 0x1861:
	case 0x1862:
	case 0x1063:
		if (fl != 0) return;
		op = el;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.B\t%s,@$%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			op1[op],
			rd8[fh],
			(short) rom[pc+2],
			(short) rom[pc+3]);
		pc += 6;
		break;
	case 0x1870:
	case 0x1871:
	case 0x1872:
	case 0x1073:
		if (fl != 0) return;
		if (fh & 8) return;
		op = el;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.B\t#$%hd,@$%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			op1[op],
			(short) fh,
			(short) rom[pc+2],
			(short) rom[pc+3]);
		pc += 6;
		break;
	case 0x3860:
	case 0x3861:
	case 0x3862:
	case 0x3063:
		if (hl != 0) return;
		op = gl;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     %s.B\t%s,@$%02hX%02hX%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			(short) rom[pc+6],
			(short) rom[pc+7],
			op1[op],
			rd8[hh],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5]);
		pc += 8;
		break;
	case 0x3870:
	case 0x3871:
	case 0x3872:
	case 0x3073:
		if (hl != 0) return;
		if (hh & 8) return;
		op = gl;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     %s.B\t#$%hd,@$%02hX%02hX%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			(short) rom[pc+6],
			(short) rom[pc+7],
			op1[op],
			(short) hh,
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5]);
		pc += 8;
		break;
	case 0x1074:
	case 0x1075:
	case 0x1076:
	case 0x1077:
	case 0x1867:
		if (fl != 0) return;
		op = el-4; if (bl==8) op=4;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         B%s%s.B\t#$%hd,@$%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			(fh & 8) ? "I":"",
			op2[op],
			(short) fh & 7,
			(short) rom[pc+2],
			(short) rom[pc+3]);
		pc += 6;
		break;
	case 0x3074:
	case 0x3075:
	case 0x3076:
	case 0x3077:
	case 0x3867:
		if (hl != 0) return;
		op = gl-4; if (bl==8) op=4;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     B%s%s.B\t#$%hd,@$%02hX%02hX%02hX%02hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			(short) rom[pc+6],
			(short) rom[pc+7],
			(hh & 8) ? "I":"",
			op2[op],(short) hh & 7,
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5]);
		pc += 8;
		break;
	}
}






void tbl3()
{
char *op1x[3]={"OR","XOR","AND"};
char *op2x[3]={"BSET","BNOT","BCLR"};
char op;

switch(ahal)
	{
	case 0x01:
		switch (bhbl)
			{
			case 0xc0:
				switch (chcl)
					{
					case 0x50:
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MULXS.B\t%s,%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							rd8[dh],
							rd16[dl]);
						pc += 4;
						break;
					case 0x52:
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MULXS.W\t%s,%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							rd8[dh],
							rd32[dl]);
						pc += 4;
						break;
					}
				break;
			case 0xd0:
				switch (chcl)
					{
					case 0x51:
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             DIVXS.B\t%s,%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							rd8[dh],
							rd16[dl]);
						pc += 4;
						break;
					case 0x53:
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             DIVXS.W\t%s,%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							rd8[dh],rd32[dl]);
						pc += 4;
						break;
					}
				break;
			case 0xf0:
				if (ch != 6) return;
				if (dh & 8) return;
				if (dl & 8) return;
				if (cl<4) return;
				if (cl>6) return;
				op = cl - 4;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.L\t%s,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op1x[op],
					rd32[dh],
					rd32[dl]);
				pc += 4;
				break;
			}
		break;
	case 0x7c:
		if (bl != 0) return;
		if (bh & 8) return;
		switch (ch)
			{
			case 6:
				if (cl != 3) return;
				if (dl) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             BTST.B\t%s,@%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[dh],
					rd32[bh]);
				pc += 4;
				break;
			case 7:
				switch (cl)
					{
					case 3:
						if (dl) return;
						if (dh & 8) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             BTST.B\t#%hd,@%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(short) dh,
							rd32[bh]);
						pc += 4;
						break;
					case 4:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sOR.B\t#%hd,@%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							rd32[bh]);
						pc += 4;
						break;
					case 5:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sXOR.B\t#%hd,@%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							rd32[bh]);
						pc += 4;
						break;
					case 6:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sAND.B\t#%hd,@%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",(short) dh & 7,rd32[bh]);
						pc += 4;
						break;
					case 7:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sLD.B\t#%hd,@%s\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",(short) dh & 7,rd32[bh]);
						pc += 4;
						break;
					}
				break;
			}
		break;
	case 0x7d:
		switch(chcl)
			{
			case 0x60:
			case 0x61:
			case 0x62:
				if (bh & 8) return;
				if (bl) return;
				if (dl) return;
				op = cl;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t%s,@%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op2x[op],rd8[dh],rd32[bh]);
				pc += 4;
				break;
			case 0x67:
				if (dl) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sST.B\t#%hd,@%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(dh&8)?"I":"",
					(short) dh & 7,
					rd32[bh]);
				pc += 4;
				break;
			case 0x70:
			case 0x71:
			case 0x72:
				if (bh & 8) return;
				if (bl) return;
				if (dl) return;
				op = cl;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t#%hd,@%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op2x[op],
					dh,
					rd32[bh]);
				pc += 4;
				break;
			}
		break;
	case 0x7e:
		switch (ch)
			{
			case 6:
				if (cl != 3) return;
				if (dl) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             BTST.B\t%s,@$%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[dh],
					(short) bhbl);
				pc += 4;
				break;
			case 7:
				switch (cl)
					{
					case 3:
						if (dl) return;
						if (dh & 8) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             BTST.B\t#%hd,@$%02hX\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(short) dh,
							(short) bhbl);
						pc += 4;
						break;
					case 4:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sOR.B\t#%hd,@$%02hX\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							(short) bhbl);
						pc += 4;
						break;
					case 5:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sXOR.B\t#%hd,@$%02hX\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							(short) bhbl);
						pc += 4;
						break;
					case 6:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sAND.B\t#%hd,@$%02hX\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							(short) bhbl);
						pc += 4;
						break;
					case 7:
						if (dl) return;
						fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sLD.B\t#%hd,@$%02hX\n",
							pc+OFFSET,
							(short) rom[pc+0],
							(short) rom[pc+1],
							(short) rom[pc+2],
							(short) rom[pc+3],
							(dh&8)?"I":"",
							(short) dh & 7,
							(short) bhbl);
						pc += 4;
						break;
					}
				break;
			}
		break;
	case 0x7f:
		switch(chcl)
			{
			case 0x60:
			case 0x61:
			case 0x62:
				if (dl) return;
				op = cl;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t%s,@$%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op2x[op],
					rd8[dh],
					(short) bhbl);
				pc += 4;
				break;
			case 0x67:
				if (dl) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             B%sST.B\t#%hd,@$%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(dh&8)?"I":"",
					(short) dh & 7,
					(short) bhbl);
				pc += 4;
				break;
			case 0x70:
			case 0x71:
			case 0x72:
				if (dl) return;
				op = cl;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.B\t#%hd,@$%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op2x[op],
					(short) dh,
					(short) bhbl);
				pc += 4;
				break;
			}
		break;
	}	
}






void mov0100()
{
if (ahal != 0x01) return;
if (bhbl != 0x00) return;

switch (chcl)
	{
	case 0x69:
		if (dl & 8) return;
		if ( !(dh & 8) )
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.L\t@%s,%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				rd32[dh],
				rd32[dl]);
			} else
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.L\t%s,@%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				rd32[dl],
				rd32[dh & 7]);
			}
		pc += 4;
		break;
	case 0x6b:
		if (dl & 8) return;
		switch(dh)
			{
			case 0:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.L\t@$%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+4],
					(short) rom[pc+5],
					rd32[dl]);
				pc += 6;
				break;
			case 8:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.L\t%s,@$%02hX%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					rd32[dl],(short) rom[pc+4],(short) rom[pc+5]);
				pc += 6;
				break;
			case 2:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.L\t@$%02hX%02hX%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7]
					,rd32[dl]);
				pc += 8;
				break;
			case 0xa:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.L\t%s,@$%02hX%02hX%02hX%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7],
					rd32[dl],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7]);
				pc += 8;
				break;
			default: return;
			}
		break;
	case 0x6d:
		if (dl & 8) return;
		if ( !(dh & 8) )
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.L\t@%s+,%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				rd32[dh],
				rd32[dl]);
			} else
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.L\t%s,@-%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				rd32[dl],
				rd32[dh & 7]);
			}
		pc += 4;
		break;
	case 0x6f:
		if (dl & 8) return;
		if ( !(dh & 8) )
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.L\t@($%02hX%02hX,%s),%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				(short) rom[pc+4],
				(short) rom[pc+5],
				(short) rom[pc+4],
				(short) rom[pc+5],
				rd32[dh],
				rd32[dl]);
			} else
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.L\t%s,@($%02hX%02hX,%s)\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				(short) rom[pc+4],
				(short) rom[pc+5],
				rd32[dl],
				(short) rom[pc+4],
				(short) rom[pc+5],
				rd32[dh & 7]);
			}
		pc += 6;
		break;
	case 0x78:
		if (dl) return;
		if (ehel != 0x6b) return;
		if ( (fh!=2) && (fh!=0xa) ) return;
		if ( (fh == 0xa) && (dh < 8) ) return;
		if (fl & 8) return;
		if (fh == 2)
			{
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX MOV.L\t@($%02hX%02hX%02hX%02hX,%s),%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				(short) rom[pc+4],
				(short) rom[pc+5],
				(short) rom[pc+6],
				(short) rom[pc+7],
				(short) rom[pc+8],
				(short) rom[pc+9],
				(short) rom[pc+6],
				(short) rom[pc+7],
				(short) rom[pc+8],
				(short) rom[pc+9],
				rd32[dh & 7],
				rd32[fl]);
			} else
			fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX MOV.L\t%s,@($%02hX%02hX%02hX%02hX,%s)\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				(short) rom[pc+2],
				(short) rom[pc+3],
				(short) rom[pc+4],
				(short) rom[pc+5],
				(short) rom[pc+6],
				(short) rom[pc+7],
				(short) rom[pc+8],
				(short) rom[pc+9],
				rd32[fl],
				(short) rom[pc+6],
				(short) rom[pc+7],
				(short) rom[pc+8],
				(short) rom[pc+9],
				rd32[dh & 7]);
			{
			}
		pc += 10;
		break;
	default: return;
	}
}






void ldm0100()
{
char *op1x[2] = {"LDC","STC"};
char *op2x[2] = {"CCR","EXR"};
char op,reg;

if (ahal != 0x01) return;
if ( (bhbl & 0xfe) != 0x40) return;
if ( dl != 0x0) return;

if (bl & 1) reg=1; else reg=0;
if (chcl != 0x78)
	{
	if (dh & 8) op=1; else op=0;
	} else
	{
	if (fh & 8) op=1; else op=0;
	}

switch (chcl)
	{
	case 0x69:
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t@%s,%s\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			op1x[op],
			rd32[dh & 7],
			op2x[reg]);
		pc += 4;
		break;
	case 0x6b:
		switch(dh & 7)
			{
			case 0:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX           %s.W\t@$%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					op1x[op],
					(short) rom[pc+4],
					(short) rom[pc+5],
					op2x[reg]);
				pc += 6;
				break;
			case 2:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     %s.W\t@$%02hX%02hX%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7],
					op1x[op],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+6],
					(short) rom[pc+7],
					op2x[reg]);
				pc += 8;
				break;
			default: return;
			}
		break;
	case 0x6d:
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.W\t@%s+,%s\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			op1x[op],
			rd32[dh & 7],
			op2x[reg]);
		pc += 4;
		break;
	case 0x6f:
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         %s.W\t@(%02hX%02hX,%s),%s\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			op1x[op],
			(short) rom[pc+4],
			(short) rom[pc+5],
			rd32[dh & 7],
			op2x[reg]);
		pc += 6;
		break;
	case 0x78:
		if (ehel != 0x6b) return;
		if ( (fhfl & 0x7f) != 0x20) return;
		fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX %s.W\t@(%02hX%02hX%02hX%02hX,%s),%s\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc+2],
			(short) rom[pc+3],
			(short) rom[pc+4],
			(short) rom[pc+5],
			(short) rom[pc+6],
			(short) rom[pc+7],
			(short) rom[pc+8],
			(short) rom[pc+9],
			op1x[op],
			(short) rom[pc+6],
			(short) rom[pc+7],
			(short) rom[pc+8],
			(short) rom[pc+9],
			rd32[dh & 7],
			op2x[reg]);
		pc += 10;
		break;
	default: return;
	}
}






void tbl2()
{
char *op1x[8]={"SHLL","SHAL","SHLR","SHAR","ROTXL","ROTL","ROTXR","ROTR"};
char *op2x[4]={"NOT","EXTU","NEG","EXTS"};
char *op3x[4]={"ADDS","INC","SUBS","DEC"};
char *op4x[8]={"INC","ADD","DAA","MOV","DEC","SUB","DAS","CMP"};
char *op5x[8]={"LDM","STM"};
int op1,mod;
char *cnt;
short a,b;
char *p1,*p2;

switch (ahal)
	{
	case 0x01:
		switch(bh)
			{
			case 0x0:
				mov0100();
				break;
			case 0x1:
			case 0x2:
			case 0x3:
				if (dl & 8) return;
				if (bl) return;
				if (chcl != 0x6d) return;
				if ((dh & 7) != 7) return;
				op1 = (dh & 8) ? 1 : 0;
				a = dl & 7;
				switch(op1)
					{
				case 0:	/* LDM */
					a -= bh;
					b = a + bh;
					p1 = "@SP+,";
					p2 = "";
					break;
				case 1: /* STM */
					b = a + bh;
					p1 = "";
					p2 = ",@-SP";
					break;
					}
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %s.L\t%s(ER%hd-ER%hd)%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					op5x[op1],
					p1,
					a,
					b,
					p2);
				pc += 4;
				break;
			case 0x4:
				ldm0100();
				break;
			case 0x6:
				if (bhbl != 0x60) return;
				if (chcl != 0x6d) return;
				if (dh & 8) return;
				if (dl & 8) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             %MAC\t@%s+,@%s+\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd32[dh],
					rd32[dl]);
				pc += 4;
				break;
			case 0xc:
				tbl3();
				break;
			case 0xd:
				tbl3();
				break;
			case 0xe:
				if (bl) return;
				if (chcl != 0x7b) return;
				if ( (dhdl & 0x8f) != 0x0c ) return;
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             TAS.B\t%@%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd32[dh]);
				pc += 4;
				break;
			case 0xf:
				tbl3();
				break;
			}
		break;
	case 0x0a:
	case 0x0f:
	case 0x1a:
	case 0x1f:
		op1 = ((ah & 1)?4:0) + ((al & 1)?2:0) + ((bh & 8)?1:0);
		switch(bh)
			{
			case 0x0: mod=0; break;
			case 0x1: return;
			case 0x2: return;
			case 0x3: return;
			case 0x4: return;
			case 0x5: return;
			case 0x6: return;
			case 0x7: return;
			case 0x8: 
			case 0x9: 
			case 0xa: 
			case 0xb: 
			case 0xc: 
			case 0xd: 
			case 0xe: 
			case 0xf: mod=2; break;
			}
		if ( (mod==2) && (bl & 8) ) return;
		if (mod == 0) fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op4x[op1],
				rd8[bl]);
		if (mod == 2) fprintf(fout,"%08lX %02hX%02hX                 %s.L\t%s,%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op4x[op1],
				rd32[bh&7],
				rd32[bl]);
		pc += 2;
		break;
	case 0x0b:
	case 0x1b:
		op1 = ((ah & 1)?2:0) + ((bh & 4)?1:0);
		switch(bh)
			{
			case 0x1:
			case 0x2:
			case 0x3:
			case 0x4:
			case 0x6:
			case 0xa:
			case 0xb:
			case 0xc:
			case 0xe: return;
			case 0x0: mod=2; cnt="#1,"; break;
			case 0x5: mod=1; cnt=""   ; break;
			case 0x7: mod=2; cnt=""   ; break;
			case 0x8: mod=2; cnt="#2,"; break;
			case 0x9: mod=2; cnt="#4,"; break;
			case 0xd: mod=1; cnt="#1,"; break;
			case 0xf: mod=2; cnt="#2,"; break;
			}
		if ( (mod==2) && (bl & 8) ) return;
		if (mod == 0)
			fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op3x[op1],
				cnt,
				rd8[bl]);
		if (mod == 1)
			fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op3x[op1],
				cnt,
				rd16[bl]);
		if (mod == 2)
			fprintf(fout,"%08lX %02hX%02hX                 %s.L\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op3x[op1],
				cnt,
				rd32[bl]);
		pc += 2;
		break;
	case 0x10:
	case 0x11:
	case 0x12:
	case 0x13:
		op1 = al*2+((bh<8)?0:1);
		switch(bh & 7)
			{
			case 0: cnt=""; mod=0; break;
			case 1: cnt=""; mod=1; break;
			case 2: return;
			case 3: cnt=""; mod=2; break;
			case 4: cnt="#2,"; mod=0; break;
			case 5: cnt="#2,"; mod=1; break;
			case 6: return;
			case 7: cnt="#2,"; mod=2; break;
			}
		if ( (mod==2) && (bl & 8) ) return;
		if (mod == 0)
			fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op1x[op1],
				cnt,
				rd8[bl]);
		if (mod == 1)
			fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op1x[op1],
				cnt,
				rd16[bl]);
		if (mod == 2)
			fprintf(fout,"%08lX %02hX%02hX                 %s.L\t%s%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op1x[op1],
				cnt,
				rd32[bl]);
		pc += 2;
		break;
	case 0x17:
		op1 = (bh&0xc)>>2;
		switch(bh & 3)
			{
			case 0: mod=0; break;
			case 1: mod=1; break;
			case 2: return;
			case 3: mod=2; break;
			}
		if ( (mod==2) && (bl & 8) ) return;
		if (mod == 0)
			fprintf(fout,"%08lX %02hX%02hX                 %s.B\t%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op2x[op1],
				rd8[bl]);
		if (mod == 1)
			fprintf(fout,"%08lX %02hX%02hX                 %s.W\t%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op2x[op1],
				rd16[bl]);
		if (mod == 2)
			fprintf(fout,"%08lX %02hX%02hX                 %s.L\t%s\n",
				pc+OFFSET,
				(short) rom[pc+0],
				(short) rom[pc+1],
				op2x[op1],
				rd32[bl]);
		pc += 2;
		break;
	case 0x6a:
		switch(bh)
			{
			case 0:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.B\t@$%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[bl]);
				pc += 4;
				break;
			case 2:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.B\t@$%02hX%02hX%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					rd8[bl]);
				pc += 6;
				break;
			case 4:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOVFPE.B\t@$%02hX%02hX,%s\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[bl]);
				pc += 4;
				break;
			case 0x8:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOV.B\t%s,@$%02hX%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[bl],
					(short) rom[pc+2],
					(short) rom[pc+3]);
				pc += 4;
				break;
			case 0xa:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX         MOV.B\t%s,@$%02hX%02hX%02hX%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5],
					rd8[bl],
					(short) rom[pc+2],
					(short) rom[pc+3],
					(short) rom[pc+4],
					(short) rom[pc+5]);
				pc += 6;
				break;
			case 0xc:
				fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             MOVTPE.B\t%s,@$%02hX%02hX\n",
					pc+OFFSET,
					(short) rom[pc+0],
					(short) rom[pc+1],
					(short) rom[pc+2],
					(short) rom[pc+3],
					rd8[bl],
					(short) rom[pc+2],
					(short) rom[pc+3]);
				pc += 4;
				break;

			case 1:
			case 3:
				tbl4();
				break;
			default: return;
			}
		break;
	case 0x79:
		switch(bh)
			{
			case 0:
				imm16rd16("MOV");
				break;
			case 1:
				imm16rd16("ADD");
				break;
			case 2:
				imm16rd16("CMP");
				break;
			case 3:
				imm16rd16("SUB");
				break;
			case 4:
				imm16rd16("OR");
				break;
			case 5:
				imm16rd16("XOR");
				break;
			case 6:
				imm16rd16("AND");
				break;
			}
		break;
	case 0x7a:
		switch(bh)
			{
			case 0:
				imm32rd32("MOV");
				break;
			case 1:
				imm32rd32("ADD");
				break;
			case 2:
				imm32rd32("CMP");
				break;
			case 3:
				imm32rd32("SUB");
				break;
			case 4:
				imm32rd32("OR");
				break;
			case 5:
				imm32rd32("XOR");
				break;
			case 6:
				imm32rd32("AND");
				break;
			}
		break;
	}
}






void dish8()
{
char fix[256];
unsigned long fixl;

if ( ((pc+OFFSET) >= vectormin) &&	// handle vectors
     ((pc+OFFSET) < vectormax) )
	{
	fprintf(fout,"%08lX %02hX%02hX%02hX%02hX             DC.L\t$%02hX%02hX%02hX%02hX\n",
		pc+OFFSET,
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3],
		(short) rom[pc+0],
		(short) rom[pc+1],
		(short) rom[pc+2],
		(short) rom[pc+3]);
	pc += 4;
	return;
	}
ah = (rom[pc] >> 4) & 0xF;
al = (rom[pc]) & 0xF;
bh = (rom[pc+1] >> 4) & 0xF;
bl = (rom[pc+1]) & 0xF;
ch = (rom[pc+2] >> 4) & 0xF;
cl = (rom[pc+2]) & 0xF;
dh = (rom[pc+3] >> 4) & 0xF;
dl = (rom[pc+3]) & 0xF;
eh = (rom[pc+4] >> 4) & 0xF;
el = (rom[pc+4]) & 0xF;
fh = (rom[pc+5] >> 4) & 0xF;
fl = (rom[pc+5]) & 0xF;
gh = (rom[pc+6] >> 4) & 0xF;
gl = (rom[pc+6]) & 0xF;
hh = (rom[pc+7] >> 4) & 0xF;
hl = (rom[pc+7]) & 0xF;
ih = (rom[pc+8] >> 4) & 0xF;
il = (rom[pc+8]) & 0xF;
jh = (rom[pc+9] >> 4) & 0xF;
jl = (rom[pc+9]) & 0xF;
ahal = rom[pc];
bhbl = rom[pc+1];
chcl = rom[pc+2];
dhdl = rom[pc+3];
ehel = rom[pc+4];
fhfl = rom[pc+5];
ghgl = rom[pc+6];
hhhl = rom[pc+7];

fixl = 0;
switch (ahal*256+bhbl)
	{
	case 0x0000: fixl = 2; sprintf(fix,"%04hX                 NOP\n",0x0000); break;
	case 0x0180: fixl = 2; sprintf(fix,"%04hX                 SLEEP\n",0x0180); break;
	case 0x01A0: fixl = 2; sprintf(fix,"%04hX                 CLRMAC\n",0x01A0); break;
	case 0x5470: fixl = 2; sprintf(fix,"%04hX                 RTS\n---------------------------------\n\n",0x5470); break;
	case 0x5670: fixl = 2; sprintf(fix,"%04hX                 RTE\n---------------------------------\n\n",0x5670); break;
	case 0x5700: fixl = 2; sprintf(fix,"%04hX                 TRAPA\t#$0\n",0x5700); break;
	case 0x5710: fixl = 2; sprintf(fix,"%04hX                 TRAPA\t#$1\n",0x5710); break;
	case 0x5720: fixl = 2; sprintf(fix,"%04hX                 TRAPA\t#$2\n",0x5720); break;
	case 0x5730: fixl = 2; sprintf(fix,"%04hX                 TRAPA\t#$3\n",0x5730); break;
	case 0x7B5C:
		if (chcl*256+dhdl == 0x598f) { fixl = 4; sprintf(fix,"%04hX%04hX             EEPMOV.B\n",0x7B5C,0x598f); }
		break;
	case 0x7BD4:
		if (chcl*256+dhdl == 0x598f) { fixl = 4; sprintf(fix,"%04hX%04hX             EEPMOV.W\n",0x7BD4,0x598f); }
		break;
	}

if (fixl)
	{
	fprintf(fout,"%08lX %s",pc+OFFSET,fix);
	pc += fixl;
	return;
	}

switch (ah)
	{
	case 0x0:
		switch(al)
			{
			case 0x0:
				//NOP
				break;
			case 0x1:
				tbl2();
				break;
			case 0x2:
				switch (bh)
					{
					case 0: stc("STC","CCR"); break;
					case 1: stc("STC","EXR"); break;
					case 2: stmac("STMAC","MACH"); break;
					case 3: stmac("STMAC","MACL"); break;
					}
				break;
			case 0x3:
				switch (bh)
					{
					case 0: ldc("LDC","CCR"); break;
					case 1: ldc("LDC","EXR"); break;
					case 2: ldmac("LDMAC","MACH"); break;
					case 3: ldmac("LDMAC","MACL"); break;
					}
				break;
			case 0x4:
				orc("ORC","CCR",bhbl,1);
				break;
			case 0x5:
				orc("XORC","CCR",bhbl,1);
				break;
			case 0x6:
				orc("ANDC","CCR",bhbl,-1);
				break;
			case 0x7:
				orc("LDC","CCR",bhbl,1);
				break;
			case 0x8:
				rsrd8("ADD");
				break;
			case 0x9:
				rsrd16("ADD");
				break;
			case 0xa:
				tbl2();
				break;
			case 0xb:
				tbl2();
				break;
			case 0xc:
				rsrd8("MOV");
				break;
			case 0xd:
				rsrd16("MOV");
				break;
			case 0xe:
				rsrd8("ADDX");
				break;
			case 0xf:
				tbl2();
				break;
			}
		break;
	case 0x1:
		switch(al)
			{
			case 0x0:
			case 0x1:
			case 0x2:
			case 0x3:
				tbl2();
				break;
			case 0x4:
				rsrd8("OR");
				break;
			case 0x5:
				rsrd8("XOR");
				break;
			case 0x6:
				rsrd8("AND");
				break;
			case 0x7:
				tbl2();
				break;
			case 0x8:
				rsrd8("SUB");
				break;
			case 0x9:
				rsrd16("SUB");
				break;
			case 0xa:
			case 0xb:
				tbl2();
				break;
			case 0xc:
				rsrd8("CMP");
				break;
			case 0xd:
				rsrd16("CMP");
				break;
			case 0xe:
				rsrd8("SUBX");
				break;
			case 0xf:
				tbl2();
				break;
			}
		break;
	case 0x2:
		tbl1at("MOV");
		break;
	case 0x3:
		tbl1atr("MOV");
		break;
	case 0x4:
		bcc8(al);
		break;
	case 0x5:
		switch(al)
			{
			case 0x0:
				rsrd8("MULXU");
				break;
			case 0x1:
				rsrd8("DIVXU");
				break;
			case 0x2:
				rs16rd32("MULXU");
				break;
			case 0x3:
				rs16rd32("DIVXU");
				break;
			case 0x4:
				//RTS
				break;
			case 0x5:
				bcc8(16);
				break;
			case 0x6:
				//RTE
				break;
			case 0x7:
				//TRAPA
				break;
			case 0x8:
				if (bl == 0) bcc16(bh);
				break;
			case 0x9:
				jmpern("JMP");
				if (pc != oldpc) fprintf(fout,"\n");
				break;
			case 0xa:
				jmpa24("JMP");
				if (pc != oldpc) fprintf(fout,"\n");
				break;
			case 0xb:
				jmpaa8("JMP");
				if (pc != oldpc) fprintf(fout,"\n");
				break;
			case 0xc:
				if (bhbl == 0) bcc16(16);
				break;
			case 0xd:
				jmpern("JSR");
				break;
			case 0xe:
				jmpa24("JSR");
				break;
			case 0xf:
				jmpaa8("JSR");
				break;
			}
		break;
	case 0x6:
		switch(al)
			{
			case 0x0:
				rsrd8("BSET");
				break;
			case 0x1:
				rsrd8("BNOT");
				break;
			case 0x2:
				rsrd8("BCLR");
				break;
			case 0x3:
				rsrd8("BTST");
				break;
			case 0x4:
				rsrd16("OR");
				break;
			case 0x5:
				rsrd16("XOR");
				break;
			case 0x6:
				rsrd16("AND");
				break;
			case 0x7:
				if ( !(bh & 8) )
					{
					bset("BST");
					} else
					{
					bh ^= 8; bset("BIST"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x8:
				if ( !(bh & 8) )
					{
					ars32rd8("MOV");
					} else
					{
					bh ^= 8; rs8ard32("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x9:
				if ( !(bh & 8) )
					{
					ars32rd16("MOV");
					} else
					{
					bh ^= 8; rs16ard32("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			case 0xa:
				tbl2();
				break;
			case 0xb:
				switch(bh)
					{
						case 0x0:
							aimm16rd16("MOV");
							break;
						case 0x2:
							aimm32rd16("MOV");
							break;
						case 0x8:
							rd16aimm16("MOV");
							break;
						case 0xa:
							rd16aimm32("MOV");
							break;
					}
				break;
			case 0xc:
				if ( !(bh & 8) )
					{
					ard32prd8("MOV");
					} else
					{
					bh ^= 8; rs8ard32m("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			case 0xd:
				if ( !(bh & 8) )
					{
					ard32prd16("MOV");
					} else
					{
					bh ^= 8; rs16ard32m("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			case 0xe:
				if ( !(bh & 8) )
					{
					ard32disp16rd8("MOV");
					} else
					{
					bh ^= 8; rd16ard32disp8("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			case 0xf:
				if ( !(bh & 8) )
					{
					ard32disp16rd16("MOV");
					} else
					{
					bh ^= 8; rd16ard32disp16("MOV"); bh ^= 8; // quick & dirty
					}
				break;
			}
		break;
	case 0x7:
		switch(al)
			{
			case 0x0:
				bset("BSET");
				break;
			case 0x1:
				bset("BNOT");
				break;
			case 0x2:
				bset("BCLR");
				break;
			case 0x3:
				bset("BTST");
				break;
			case 0x4:
				if ( !(bh & 8) )
					{
					bset("BOR");
					} else
					{
					bh ^= 8; bset("BIOR"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x5:
				if ( !(bh & 8) )
					{
					bset("BXOR");
					} else
					{
					bh ^= 8; bset("BIXOR"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x6:
				if ( !(bh & 8) )
					{
					bset("BAND");
					} else
					{
					bh ^= 8; bset("BIAND"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x7:
				if ( !(bh & 8) )
					{
					bset("BLD");
					} else
					{
					bh ^= 8; bset("BILD"); bh ^= 8; // quick & dirty
					}
				break;
			case 0x8:
				if ( ((bhbl & 0x8F) == 0) && (chcl==0x6a) && (dh==0x2))
					{
					fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.B\t@($%08lX,%s),%s\n",
						pc+OFFSET,
						(short) rom[pc+0],
						(short) rom[pc+1],
						(short) rom[pc+2],
						(short) rom[pc+3],
						(short) rom[pc+4],
						(short) rom[pc+5],
						(short) rom[pc+6],
						(short) rom[pc+7],
						(unsigned long) ehel*0x1000000+fhfl*0x10000+ghgl*256+hhhl,rd32[bh],rd8[dl]);
					pc += 8;
					}
				if ( ((bhbl & 0x8F) == 0) && (chcl==0x6a) && (dh==0xa))
					{
					fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.B\t%s,@($%08lX,%s)\n",
						pc+OFFSET,
						(short) rom[pc+0],
						(short) rom[pc+1],
						(short) rom[pc+2],
						(short) rom[pc+3],
						(short) rom[pc+4],
						(short) rom[pc+5],
						(short) rom[pc+6],
						(short) rom[pc+7],
						rd8[dl],(unsigned long) ehel*0x1000000+fhfl*0x10000+ghgl*256+hhhl,rd32[bh]);
					pc += 8;
					}
				if ( ((bhbl & 0x8F) == 0) && (chcl==0x6b) && (dh==0x2))
					{
					fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.W\t@($%08lX,%s),%s\n",
						pc+OFFSET,
						(short) rom[pc+0],
						(short) rom[pc+1],
						(short) rom[pc+2],
						(short) rom[pc+3],
						(short) rom[pc+4],
						(short) rom[pc+5],
						(short) rom[pc+6],
						(short) rom[pc+7],
						(unsigned long) ehel*0x1000000+fhfl*0x10000+ghgl*256+hhhl,rd32[bh],rd16[dl]);
					pc += 8;
					}
				if ( ((bhbl & 0x8F) == 0) && (chcl==0x6b) && (dh==0xa))
					{
					fprintf(fout,"%08lX %02hX%02hX%02hX%02hX%02hX%02hX%02hX%02hX     MOV.W\t%s,@($%08lX,%s)\n",
						pc+OFFSET,
						(short) rom[pc+0],
						(short) rom[pc+1],
						(short) rom[pc+2],
						(short) rom[pc+3],
						(short) rom[pc+4],
						(short) rom[pc+5],
						(short) rom[pc+6],
						(short) rom[pc+7],
						rd16[dl],
						(unsigned long) ehel*0x1000000+fhfl*0x10000+ghgl*256+hhhl,rd32[bh]);
					pc += 8;
					}
				break;
			case 0x9:
			case 0xa:
				tbl2();
				break;
			case 0xb:
				//EEPMOV
				break;
			case 0xc:
			case 0xd:
			case 0xe:
			case 0xf:
				tbl3();
				break;
			}
		break;
	case 0x8:
		tbl1("ADD");
		break;
	case 0x9:
		tbl1("ADDX");
		break;
	case 0xa:
		tbl1("CMP");
		break;
	case 0xB:
		tbl1("SUBX");
		break;
	case 0xC:
		tbl1("OR");
		break;
	case 0xD:
		tbl1("XOR");
		break;
	case 0xE:
		tbl1("AND");
		break;
	case 0xF:
		tbl1("MOV");
		break;
	}
}



int main(int argc, char *argv[])
{
FILE *fin;
char fnam[256];
unsigned long size;
char tmp[256];

if (argc < 2)
	{
	printf("Binary file to disassemble : "); gets(fnam);
	} else
	{
	strcpy(fnam,argv[1]);
	}

if (argc < 3)
	{
	printf("Offset : "); gets(tmp);
	} else
	{
	strcpy(tmp,argv[2]);
	}
sscanf(tmp,"%lX",&OFFSET);

if (argc < 4)
	{
	printf("Vector address range min-max (e.g. 0-100) : "); gets(tmp);
	} else
	{
	strcpy(tmp,argv[3]);
	}
sscanf(tmp,"%lX-%lX",&vectormin, &vectormax);

fin = fopen(fnam,"rb");
if (fin == NULL) return 1;

size = fread(rom,1,512*1024,fin);

strcat(fnam,".txt"); fout = fopen(fnam,"w");
if (fout == NULL) return 1;

pc = 0;
while (pc < size)
	{
	oldpc = pc;
	dish8(&pc);
	if (pc == oldpc)
		{
		fprintf(fout,"%08lX %02hX%02hX                 DC.W\t$%04hX\n",
			pc+OFFSET,
			(short) rom[pc+0],
			(short) rom[pc+1],
			(short) rom[pc]*256+rom[pc+1]);
		pc = pc + 2;
		}
	}

fprintf(stderr,"Done.\n");
return 0;
}

