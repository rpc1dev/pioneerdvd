These disassemblers have been quickly coded, with poor algorithms. Development time was a
challenge, not tidiness. At least they should run fine on little and big endian
processor.
They assume that char = 8 bits, short = 16 bits, long = 32 bits.
They have been written with firmware disassembly (and patching)
in mind. They are not intended to output recompilable source. Exact syntax
was not respected. Reverse engineering was the goal.
I sometimes have slightly modified the "official" processor syntax to a more
descriptive one (at least to me), although this was limited to very few cases,
and only to arguments, not opcodes name.
