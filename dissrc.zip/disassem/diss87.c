/*

Program originally written by xvi (xvi91@hotmail.com)
You can use this program freely, I don't hold any copyright on it!
This program was written with compatibility in mind, it should compile and run
on most platforms, Mac, PC, Unix. I did test it on Mac and Digital Unix.
All I ask is that you mail me the modifications if you make some correction. 

History:

08-JUL-2001	First version. Full of bugs, probably.

*/

#define FORCERP		// define to output "(RPx+n)" as "$xx" (hardcoded RPx value)
					// This is OK for Samsung 612F, probably not for others
// If the preceding is defined, please define the two following
#define RP0 0xC0
#define RP1 0xC8
//#define BASEDREG	// define to output "Rn" as "(RPx+n)"
//#define HEXREGS		// R00-R0F or R0-R15
//#define ALLOWREGNAMES // define to allow the mapping of addresses to register name

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HI(x) (((x) >> 4) & 0xF)
#define LO(x) ((x) & 0xF)
#define B(x) (((x) >> 1) & 0x7)

unsigned long ROMOFFSET;	// PC of first byte of rom
char operb[256];
char argsb[256];
char *oper;
char *args;
char line[256];
char rupt;


char *ccadd[16]={
	"F,","LT,","LE,","ULE,","OV,","MI,","Z,","C,",
	"","GE,","GT,","UGT,","NOV,","PL,","NZ,","NC,",
	};

char *ccsub[16]={
	"F,","LT,","LE,","ULE,","OV,","MI,","EQ,","ULT,",
	"","GE,","GT,","UGT,","NOV,","PL,","NE,","UGE,",
	};

char *ccbit[16]={
	"F,","LT,","LE,","ULE,","OV,","MI,","Z,","C,",
	"","GE,","GT,","UGT,","NOV,","PL,","NZ,","NC,",
	};

char **cc;

unsigned char data[512*1024];
unsigned long pc;
unsigned char *rom;
unsigned char b1,b2,b3,b4;


typedef struct {
	unsigned char address;
	char *name;
	} REG;

REG REGS[]=	// may be customized for specific processor
	{
	{0xD5,"FLAGS"},
	{0xD6,"RP0"},
	{0xD7,"RP1"},
	{0xD8,"SPH"},
	{0xD9,"SPL"},
	{0xDA,"IPH"},
	{0xDB,"IPL"},
	{0xDC,"IRQ"},
	{0xDD,"IMR"},
	{0xDE,"SYM"},
	{0xDF,"PP"}
	};
	
REG REGSW[]=	// may be customized for specific processor
	{
	{0xD8,"SP"},
	{0xDA,"IP"},
	};
	


char *R(unsigned char x)
{
static char Rc[16];


#ifdef ALLOWREGNAMES
int i,f=0;
for (i=0; i < sizeof(REGS)/sizeof(REGS[0]); i++)
	{
	if (REGS[i].address == x) { f = 1; break;}
	}
if (f)
	sprintf(Rc,REGS[i].name);
	else
#endif
	sprintf(Rc,"$%02X",x);
return Rc;
}




void Rint(unsigned char x, char *Rc)
{
#ifdef ALLOWREGNAMES
int i,f=0;
for (i=0; i < sizeof(REGS)/sizeof(REGS[0]); i++)
	{
	if (REGS[i].address == x) { f = 1; break;}
	}
if (f)
	sprintf(Rc,REGS[i].name);
	else
#endif
	sprintf(Rc,"$%02X",x);
}




char *R2(unsigned char x)
{
static char Rc[16];


#ifdef ALLOWREGNAMES
int i,f=0;
for (i=0; i < sizeof(REGS)/sizeof(REGS[0]); i++)
	{
	if (REGS[i].address == x) { f = 1; break;}
	}
if (f)
	sprintf(Rc,REGS[i].name);
	else
#endif
	sprintf(Rc,"$%02X",x);
return Rc;
}




char *RHI(unsigned char x)
{
static char Rc[16];

x = HI(x);

#ifdef FORCERP
Rint(((x & 0x8) ? RP1 : RP0) + (x & 0x7),Rc);
#else
#ifdef BASEDREG
sprintf(Rc,"(RP%d+%d)",(x & 0x8) ? 1 : 0, x & 0x7);
#else
#ifdef HEXREGS
sprintf(Rc,"R%02X",x);
#else
sprintf(Rc,"R%d",x);
#endif
#endif
#endif
return Rc;
}




char *RLO(unsigned char x)
{
static char Rc[16];

x = LO(x);

#ifdef FORCERP
Rint(((x & 0x8) ? RP1 : RP0) + (x & 0x7),Rc);
#else
#ifdef BASEDREG
sprintf(Rc,"(RP%d+%d)",(x & 0x8) ? 1 : 0, x & 0x7);
#else
#ifdef HEXREGS
sprintf(Rc,"R%02X",x);
#else
sprintf(Rc,"R%d",x);
#endif
#endif
#endif
return Rc;
}




char *RR(unsigned char x)
{
static char Rc[16];

#ifdef ALLOWREGNAMES
int i,f=0;
for (i=0; i < sizeof(REGS)/sizeof(REGS[0]); i++)
	{
	if (REGS[i].address == x) { f = 1; break;}
	}
if (f)
	sprintf(Rc,REGS[i].name);
	else
#endif
	sprintf(Rc,"$%02X",x);

return Rc;
}




void RRint(unsigned char x,char * Rc)
{
#ifdef ALLOWREGNAMES
int i,f=0;
for (i=0; i < sizeof(REGS)/sizeof(REGS[0]); i++)
	{
	if (REGS[i].address == x) { f = 1; break;}
	}
if (f)
	sprintf(Rc,REGS[i].name);
	else
#endif
	sprintf(Rc,"$%02X",x);
}




char *RRHI(unsigned char x)
{
static char Rc[16];

x = HI(x);

#ifdef FORCERP
RRint(((x & 0x8) ? RP1 : RP0) + (x & 0x7),Rc);
#else
#ifdef BASEDREG
sprintf(Rc,"(RP%d+%d)",(x & 0x8) ? 1 : 0, x & 0x7);
#else
#ifdef HEXREGS
sprintf(Rc,"RR%02X",x);
#else
sprintf(Rc,"RR%d",x);
#endif
#endif
#endif
return Rc;
}




char *RRLO(unsigned char x)
{
static char Rc[16];

x = LO(x);

#ifdef FORCERP
RRint(((x & 0x8) ? RP1 : RP0) + (x & 0x7),Rc);
#else
#ifdef BASEDREG
sprintf(Rc,"(RP%d+%d)",(x & 0x8) ? 1 : 0, x & 0x7);
#else
#ifdef HEXREGS
sprintf(Rc,"RR%02X",x);
#else
sprintf(Rc,"RR%d",x);
#endif
#endif
#endif
return Rc;
}




void dodis(void)
{
// do the real disassembly.
// if rom[pc] is not an instruction, do NOT increment pc.
// if pc is incremented, oper and args are the instruction description
char *op1[8] = {"ADD","ADC","SUB","SBC","OR","AND","TCM","TM"};
char *op2[2] = {"CP","XOR"};
void *cc1[8] = {ccadd,ccadd,ccsub,ccsub,ccbit,ccbit,ccbit,ccbit};
void *cc2[2] = {ccsub,ccbit};

rupt = 0;
b1 = rom[pc];
b2 = rom[pc+1];
b3 = rom[pc+2];
b4 = rom[pc+3];

if ( (pc < 0x100) && !(pc & 1) ) // vectors
	{
	oper = "DW";
	sprintf(args,"$%02X%02X",b1,b2);
	pc += 2;
	return;
	}

switch(b1)
	{
case 0x00:
	oper = "DEC";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x10:
	oper = "RLC";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x20:
	oper = "INC";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x30:
	oper = "JP";
	sprintf(args,"@%s",RR(b2));
	pc += 2;
	rupt = 1;
	break;
case 0x40:
	oper = "DA";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x50:
	oper = "POP";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x60:
	oper = "COM";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x70:
	oper = "PUSH";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x80:
	if (b2 & 1) return;
	oper = "DECW";
	sprintf(args,"%s",RR(b2));
	pc += 2;
	break;
case 0x90:
	oper = "RL";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0xA0:
	if (b2 & 1) return;
	oper = "INCW";
	sprintf(args,"%s",RR(b2));
	pc += 2;
	break;
case 0xB0:
	oper = "CLR";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0xC0:
	oper = "RRC";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0xD0:
	oper = "SRA";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0xE0:
	oper = "RR";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0xF0:
	oper = "SWAP";
	sprintf(args,"%s",R(b2));
	pc += 2;
	break;
case 0x01:
	oper = "DEC";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x11:
	oper = "RLC";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x21:
	oper = "INC";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x31:
	switch(b2 & 3)
		{
	case 0:
		oper = "SRP";
		break;
	case 1:
		oper = "SRP1";
		break;
	case 2:
		oper = "SRP0";
		break;
	case 3:
		return;
		break;
		}
	sprintf(args,"#$%02X",b2 & ((b2 & 3) ? 0xF8 : 0xF0));
	pc += 2;
	break;
case 0x41:
	oper = "DA";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x51:
	oper = "POP";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x61:
	oper = "COM";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x71:
	oper = "PUSH";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x81:
	oper = "DECW";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x91:
	oper = "RL";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xA1:
	oper = "INCW";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xB1:
	oper = "CLR";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xC1:
	oper = "RRC";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xD1:
	oper = "SRA";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xE1:
	oper = "RR";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0xF1:
	oper = "SWAP";
	sprintf(args,"@%s",R(b2));
	pc += 2;
	break;
case 0x02: case 0x03: case 0x04: case 0x05: case 0x06:
case 0x12: case 0x13: case 0x14: case 0x15: case 0x16:
case 0x22: case 0x23: case 0x24: case 0x25: case 0x26:
case 0x32: case 0x33: case 0x34: case 0x35: case 0x36:
case 0x42: case 0x43: case 0x44: case 0x45: case 0x46:
case 0x52: case 0x53: case 0x54: case 0x55: case 0x56:
case 0x62: case 0x63: case 0x64: case 0x65: case 0x66:
case 0x72: case 0x73: case 0x74: case 0x75: case 0x76:
	oper = op1[HI(b1)];
	switch (LO(b1))
		{
	case 2:
		sprintf(args,"%s,%s",RHI(b2),RLO(b2));
		pc += 2;
		break;
	case 3:
		sprintf(args,"%s,@%s",RHI(b2),RLO(b2));
		pc += 2;
		break;
	case 4:
		sprintf(args,"%s,%s",R(b3),R2(b2));
		pc += 3;
		break;
	case 5:
		sprintf(args,"%s,@%s",R(b3),R2(b2));
		pc += 3;
		break;
	case 6:
		sprintf(args,"%s,#$%02X",R(b2),b3);
		pc += 3;
		break;
		}
	if (cc1[HI(b1)] != NULL) cc = cc1[HI(b1)];
	break;
case 0xA2: case 0xA3: case 0xA4: case 0xA5: case 0xA6:
case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6:
	oper = op2[HI(b1) - 0xA];
	switch (LO(b1))
		{
	case 2:
		sprintf(args,"%s,%s",RHI(b2),RLO(b2));
		pc += 2;
		break;
	case 3:
		sprintf(args,"%s,@%s",RHI(b2),RLO(b2));
		pc += 2;
		break;
	case 4:
		sprintf(args,"%s,%s",R(b3),R2(b2));
		pc += 3;
		break;
	case 5:
		sprintf(args,"%s,@%s",R(b3),R2(b2));
		pc += 3;
		break;
	case 6:
		sprintf(args,"%s,#$%02X",R(b2),b3);
		pc += 3;
		break;
		}
	if (cc2[HI(b1) - 0xA] != NULL) cc = cc2[HI(b1) - 0xA];
	break;
case 0x82: case 0x83: case 0x92: case 0x93:
	sprintf(oper,"%s%s",(b1 > 0x90) ? "POPU" : "PUSHU", (b1 & 1) ? "I" : "D");
	switch (HI(b1))
		{
	case 0x8:
		sprintf(args,"@%s,%s",R(b2),R(b3));
		pc += 3;
		break;
	case 0x9:
		sprintf(args,"%s,@%s",R(b3),R2(b2));
		pc += 3;
		break;
		}
	break;
case 0x84: case 0x85: case 0x86:
case 0x94: case 0x95: case 0x96:
	oper = (HI(b1) == 0x8) ? "MULT" : "DIV";
	switch (LO(b1))
		{
	case 4:
		sprintf(args,"%s,%s",RR(b3),R(b2));
		pc += 3;
		break;
	case 5:
		sprintf(args,"%s,@%s",RR(b3),R(b2));
		pc += 3;
		break;
	case 6:
		sprintf(args,"%s,#$%02X",RR(b3),b2);
		pc += 3;
		break;
		}
	break;
case 0xC2: case 0xD2:
	oper = (b1 == 0xC2) ? "CPIJE" : "CPIJNE";
	sprintf(args,"@%s,%s,%04lX",RLO(b2),RHI(b2),pc + 3 + (signed char) b3);
	pc += 3;
	break;
case 0xE2:
	oper = (LO(b2) & 1) ? "LDED" : "LDCD";
	sprintf(args,"%s,@%s",RHI(b2),RRLO(b2 & ~1));
	pc += 2;
	break;
case 0xF2:
	oper = (LO(b2) & 1) ? "LDEPD" : "LDCPD";
	sprintf(args,"@%s,%s",RRLO(b2),RHI(b2));
	pc += 2;
	break;
case 0xC3:
	oper = (LO(b2) & 1) ? "LDE" : "LDC";
	sprintf(args,"%s,@%s",RHI(b2),RRLO(b2 & ~1));
	pc += 2;
	break;
case 0xD3:
	oper = (LO(b2) & 1) ? "LDE" : "LDC";
	sprintf(args,"@%s,%s",RRLO(b2),RHI(b2));
	pc += 2;
	break;
case 0xE3:
	oper = (LO(b2) & 1) ? "LDEI" : "LDCI";
	sprintf(args,"%s,@%s",RHI(b2),RRLO(b2 & ~1));
	pc += 2;
	break;
case 0xF3:
	oper = (LO(b2) & 1) ? "LDEPI" : "LDCPI";
	sprintf(args,"@%s,%s",RRLO(b2),RHI(b2));
	pc += 2;
	break;
case 0xC4:
	oper = "LDW";
	sprintf(args,"%s,%s",RRLO(b2),RRHI(b2));
	pc += 2;
	break;
case 0xD4:
	if (b2 & 1) return;
	oper = "CALL";
	sprintf(args,"#$%02X",b2);
	pc += 2;
	break;
case 0xE4:
	oper = "LD";
	sprintf(args,"%s,%s",R(b3),R2(b2));
	pc += 3;
	break;
case 0xF4:
	oper = "CALL";
	sprintf(args,"@%s",RR(b2));
	pc += 2;
	break;
case 0xC5:
	oper = "LDW";
	sprintf(args,"%s,@%s",RRLO(b2),RRHI(b2));
	pc += 2;
	break;
case 0xD5:
	return;
case 0xE5:
	oper = "LD";
	sprintf(args,"%s,@%s",R(b3),R2(b2));
	pc += 3;
	break;
case 0xF5:
	oper = "LD";
	sprintf(args,"@%s,%s",R(b3),R2(b2));
	pc += 3;
	break;
case 0xC6:
	oper = "LDW";
	sprintf(args,"%s,#%02X%02X",RR(b2),b3,b4);
	pc += 4;
	break;
case 0xD6:
	oper = "LD";
	sprintf(args,"@%s,#%02X",R(b2),b3);
	pc += 3;
	break;
case 0xE6:
	oper = "LD";
	sprintf(args,"%s,#%02X",R(b2),b3);
	pc += 3;
	break;
case 0xF6:
	oper = "CALL";
	sprintf(args,"$%02X%02X",b2,b3);
	pc += 3;
	break;
case 0x07:
	oper = "BOR";
	switch(b2 & 1)
		{
	case 0:
		sprintf(args,"%s.0,%s.%d",RHI(b2),R(b3),B(b2));
		break;
	case 1:
		sprintf(args,"%s.%d,%s.0",R(b3),B(b2),RHI(b2));
		break;
		}
	pc += 3;
	cc = ccbit;
	break;
case 0x17:
	if (b2 & 1) return;
	oper = "BCP";
	sprintf(args,"%s.0,%s.%d",RHI(b2),R(b3),B(b2));
	pc += 3;
	cc = ccbit;
	break;
case 0x27:
	oper = "BXOR";
	switch(b2 & 1)
		{
	case 0:
		sprintf(args,"%s.0,%s.%d",RHI(b2),R(b3),B(b2));
		break;
	case 1:
		sprintf(args,"%s.%d,%s.0",R(b3),B(b2),RHI(b2));
		break;
		}
	pc += 3;
	cc = ccbit;
	break;
case 0x37:
	sprintf(oper,"BTJR%s",(b2 & 1) ? "T" : "F");
	sprintf(args,"$%04lX,%s.%d",pc + 3 + (signed char) b3,RHI(b2),B(b2));
	pc += 3;
	break;
case 0x47:
	oper = "LDB";
	switch(b2 & 1)
		{
	case 0:
		sprintf(args,"%s.0,%s.%d",RHI(b2),R(b3),B(b2));
		break;
	case 1:
		sprintf(args,"%s.%d,%s.0",R(b3),B(b2),RHI(b2));
		break;
		}
	pc += 3;
	cc = ccbit;
	break;
case 0x57:
	if (b2 & 1) return;
	oper = "BITC";
	sprintf(args,"%s.%d",RHI(b2),B(b2));
	pc += 2;
	cc = ccbit;
	break;
case 0x67:
	oper = "BXOR";
	switch(b2 & 1)
		{
	case 0:
		sprintf(args,"%s.0,%s.%d",RHI(b2),R(b3),B(b2));
		break;
	case 1:
		sprintf(args,"%s.%d,%s.0",R(b3),B(b2),RHI(b2));
		break;
		}
	pc += 3;
	cc = ccbit;
	break;
case 0x77:
	sprintf(oper,"BIT%s",(b2 & 1) ? "S" : "R");
	sprintf(args,"%s.%d",RHI(b2),B(b2));
	pc += 2;
	break;
case 0x87:
	oper = "LD";
	sprintf(args,"%s,%s[%s]", RHI(b2), R(b3), RLO(b2));
	pc += 3;
	break;
case 0x97:
	oper = "LD";
	sprintf(args,"%s[%s],%s",R(b3), RLO(b2), RHI(b2));
	pc += 3;
	break;
case 0xA7:
	sprintf(oper,"LD%s",(LO(b2) & 1) ? "C" : "E");
	switch(LO(b2) & ~1)
		{
	case 0x0:
		sprintf(args,"%s,$%02X%02X",RHI(b2),b3,b4);
		break;
	default:
		sprintf(args,"%s,$%02X%02X[%s]",RHI(b2),b3,b4,RRLO(b2 & ~1));
		break;
		}
	pc += 4;
	break;
case 0xB7:
	sprintf(oper,"LD%s",(LO(b2) & 1) ? "C" : "E");
	switch(LO(b2) & ~1)
		{
	case 0x0:
		sprintf(args,"$%02X%02X,%s",b3,b4,RHI(b2));
		break;
	default:
		sprintf(args,"$%02X%02X[%s],%s",b3,b4,RRLO(b2 & ~1),RHI(b2));
		break;
		}
	pc += 4;
	break;
case 0xC7:
	oper = "LD";
	sprintf(args,"%s,@%s",RHI(b2),RLO(b2));
	pc += 2;
	break;
case 0xD7:
	oper = "LD";
	sprintf(args,"@%s,%s",RHI(b2),RLO(b2));
	pc += 2;
	break;
case 0xE7:
	sprintf(oper,"LD%s",(LO(b2) & 1) ? "C" : "E");
	sprintf(args,"%s,%s[%s]",RHI(b2),R(b3),RLO(b2));
	pc += 3;
	break;
case 0xF7:
	sprintf(oper,"LD%s",(LO(b2) & 1) ? "C" : "E");
	sprintf(args,"%s[%s],%s",R(b3),RLO(b2),RHI(b2));
	pc += 3;
	break;
case 0x08: case 0x18: case 0x28: case 0x38: case 0x48: case 0x58: case 0x68: case 0x78:
case 0x88: case 0x98: case 0xA8: case 0xB8: case 0xC8: case 0xD8: case 0xE8: case 0xF8:
	oper = "LD";
	sprintf(args,"%s,%s", RHI(b1), R(b2));
	pc += 2;
	break;
case 0x09: case 0x19: case 0x29: case 0x39: case 0x49: case 0x59: case 0x69: case 0x79:
case 0x89: case 0x99: case 0xA9: case 0xB9: case 0xC9: case 0xD9: case 0xE9: case 0xF9:
	oper = "LD";
	sprintf(args,"%s,%s", R(b2), RHI(b1));
	pc += 2;
	break;
case 0x0A: case 0x1A: case 0x2A: case 0x3A: case 0x4A: case 0x5A: case 0x6A: case 0x7A:
case 0x8A: case 0x9A: case 0xAA: case 0xBA: case 0xCA: case 0xDA: case 0xEA: case 0xFA:
	oper = "DJNZ";
	sprintf(args,"%s,$%04lX",RHI(b1), pc + 2 + (signed char) b2);
	cc = ccadd;
	pc += 2;
	break;
case 0x0B: case 0x1B: case 0x2B: case 0x3B: case 0x4B: case 0x5B: case 0x6B: case 0x7B:
case 0x8B: case 0x9B: case 0xAB: case 0xBB: case 0xCB: case 0xDB: case 0xEB: case 0xFB:
	oper = "JR";
	sprintf(args,"%s$%04lX",cc[HI(b1)], pc + 2 + (signed char) b2);
	cc = ccadd;
	pc += 2;
	if ( HI(b1) == 8) rupt = 1;
	break;
case 0x0C: case 0x1C: case 0x2C: case 0x3C: case 0x4C: case 0x5C: case 0x6C: case 0x7C:
case 0x8C: case 0x9C: case 0xAC: case 0xBC: case 0xCC: case 0xDC: case 0xEC: case 0xFC:
	oper = "LD";
	sprintf(args,"%s,#$%02X", RHI(b1),b2);
	pc += 2;
	break;
case 0x0D: case 0x1D: case 0x2D: case 0x3D: case 0x4D: case 0x5D: case 0x6D: case 0x7D:
case 0x8D: case 0x9D: case 0xAD: case 0xBD: case 0xCD: case 0xDD: case 0xED: case 0xFD:
	oper = "JP";
	sprintf(args,"%s$%02X%02X",cc[HI(b1)], b2, b3);
	cc = ccadd;
	pc += 3;
	if ( HI(b1) == 8 ) rupt = 1;
	break;
case 0x0E: case 0x1E: case 0x2E: case 0x3E: case 0x4E: case 0x5E: case 0x6E: case 0x7E:
case 0x8E: case 0x9E: case 0xAE: case 0xBE: case 0xCE: case 0xDE: case 0xEE: case 0xFE:
	oper = "INC";
	sprintf(args,"%s", RHI(b1));
	pc++;
	break;
case 0x0F:
	oper = "NEXT"; pc++; break;
case 0x1F:
	oper = "ENTER"; pc++; break;
case 0x2F:
	oper = "EXIT"; pc++; break;
case 0x3F:
	oper = "WFI"; pc++; break;
case 0x4F:
	oper = "SB0"; pc++; break;
case 0x5F:
	oper = "SB1"; pc++; break;
case 0x6F:
	oper = "IDLE"; pc++; break;
case 0x7F:
	oper = "STOP"; pc++; break;
case 0x8F:
	oper = "DI"; pc++; break;
case 0x9F:
	oper = "EI"; pc++; break;
case 0xAF:
	oper = "RET"; pc++; rupt = 2; break;
case 0xBF:
	oper = "IRET"; pc++; rupt = 2; break;
case 0xCF:
	oper = "RCF"; pc++; break;
case 0xDF:
	oper = "SCF"; pc++; break;
case 0xEF:
	oper = "CCF"; pc++; break;
case 0xFF:
	oper = "NOP"; pc++; break;
	}
}

void dis(void)
{
unsigned long oldpc;
char cdump[256];
char cbyte[16];
int ptr;

strcpy(operb,"");
strcpy(argsb,"");
oper = operb;
args = argsb;

oldpc = pc;

dodis();

if (pc == oldpc)
	{
	oper = "DB";
	sprintf(args,"$%02hX",(short) rom[pc++]);
	}
strcpy(cdump,"");
for (ptr=oldpc; ptr<pc; ptr++)
	{
	sprintf(cbyte,"%02hX",(short) rom[ptr]);
	strcat(cdump,cbyte);
	}

sprintf(line,"%04lX %-8.8s\t%s\t%s",oldpc+ROMOFFSET,cdump,oper,args);
}


void main(void)
{
unsigned long len,l;
char fnam[256];
FILE *fin,*fout;


printf("File name : "); gets(fnam);
fin = fopen(fnam,"rb");
if (fin == NULL) return;

strcat(fnam,".txt");
fout = fopen(fnam,"w");
if (fout == NULL) return;

len = sizeof(data)/sizeof(data[0]);

l = fread(data,1,len,fin);

len = l;

printf("Address of first byte of file : ");
scanf("%x",&ROMOFFSET);

cc = ccadd;
for (pc=0; pc < len; )
	{
	rom = data;
	dis();
	fprintf(fout,"%s\n",line);
	switch(rupt)
		{
		case 1:
			fprintf(fout,"\n");
			break;
		case 2:
			fprintf(fout,"-------------------\n");
			fprintf(fout,"\n");
			break;
		}
	}
printf("Done.\n");
}
