Drive:			Pioneer DVR-105/DVR-A05 (DVD-R/RW Burner)
Firmware Rev.:		v1.30
Patch:			RPC-1 (Region Free) + 4xDVD-R/2xDVD-RW - RC1
Date:			2003.04.06 - 18:55 GMT
Author:			>NIL:
Release Notes:		HIGHLY EXPERIMENTAL. DON'T USE IT UNLESS YOU ARE AN
			EXPERT - I MEAN IT!!! DON'T COME COMPLAINING TO ME IF
			YOU FLASHED THIS FIRMWARE WITHOUT KNOWING THE RISKS!
Flashing Instructions:	You're supposed to know - It's experimental stuff!!!
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		Gradius, FLASHMAN, Depl0y, zaitec2, etc.


==============================================================================
=============  DISCLAIMER - You HAVE TO read the following  ==================
==============================================================================

Neither Pioneer nor myself can be held responsible for any damage occuring to 
your drive/media should you wish to use this firmware. 
Use it at your own risks. I MEAN IT!!!

Before you use this firmware, you MUST understand that 4x burning of DVD-R and
2x burning of DVD-RW is completely different from high speed CD-R burning.
You cannot just pop a writeable DVD media into your drive and expect to be 
able to burn at high speed UNLESS it is ALREADY a 4x DVD-R or 2x DVD-RW media.

This is because, to burn at high speed, a writeable DVD media HAS TO:
1. BE ABLE TO SUSTAIN HIGH SPEED.
2. Provide a write strategy for HIGH speed.

Older media don't provide high speed write strategy simply because they 
were never designed for it, and it is highly probable that trying to write at
these speeds will fail.
IT IS NOT A LIMITATION OF THE FIRMWARE - IT IS A LIMITATION OF THE MEDIA!!!!!

What this firmware does is go over the MEDIA limitation by providing a high 
speed write strategy, so that you can ATTEMPT to burn a media at a higher 
speed than the one it was designed for, and that is all!

What this firmware does NOT do is magically turn your low speed media into 
high speed compatible ones. Again, it will only let you experiment with 
higher speed should you want to do so, but there is ABSOLUTELY NO GUARANTEE
that you will be able to burn properly these speeds.

Also, you need to be AWARE that by attempting to burn at higher speed, you
CAN seriously DAMAGE your media OR EVEN YOUR DRIVE!!

==============================================================================
=====================  !!!YOU HAVE BEEN WARNED!!!  ===========================
==============================================================================
