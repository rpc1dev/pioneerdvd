RPC-1 (region-free) firmware v1.11 for Acer/BenQ DVP-1648A (Pioneer DVD-500M / DVD-118)
Created: February 11th, 2003  ...by: John Lee

New features (in v1.11 vs. the old v1.07):

DVD+RW support!   This new firmware adds DVD+RW support to these DVD-ROM drives!
...and presumably adds improved DVD+R support also.


Included files:

500mx111.hex  -- the RPC-1 (region free) firmware
acma111.hex   -- the original (region-locking) firmware (for reference)
DOS1648A.EXE  -- a newer version of DOSFLASH.EXE (v1.0 instead of v0.8)


Instructions:

Start your system under pure DOS. ( this tool can't work on Windows )

then run:
    DOS1648A 500mx111.hex
...(if you want to use the region-free firmware)

or:
    DOS1648A acma111.hex
...(if you want to use the RPC-2 firmware)


This modified v1.11 firmware (500mx111.hex) was created by John Lee, with a some help from Hijacker of www.rpc1.org ...
