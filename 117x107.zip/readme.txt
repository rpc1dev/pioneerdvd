Procedure of firmware upgrade (DVD-117)

Please see Windows 95/98 Device Manager for details concerning firmware 
information on the drive. 
Please click the start button to access Device Manager.
Next, click "Setting", "Control panel", and "System" tab.
Next, please click the tab of "device manager", and click "+" in the
left of the icon of CD-ROM. 
Please click the drive icon to which the firmware wants to upgrade,
choose "Property", and click "Settings".
The firmware revision number written in this tab is a version of 
a present firmware of this DVD-ROM drive. 

Please go as follows before doing upgrade. 
 �Please pull out the disc from the DVD-ROM drive first. 
 �Please confirm the IDE bus with which the DVD-ROM drive is connected 
  whether is Primary IDE channel or Secaondary IDE channel. 
 �Next, please confirm whether for DVD-ROM to be connected 
  with the IDE bus as Master or to be connected as Slave. 

Please inquire of the personal computer and media manufacturer and 
the motherboard maker when you do not understand the confirm method 
of setting the IDE bus with which DVD-ROM is connected and the drive 
(primary/secondary). 

1.Please download the latest firmware (archive file), and upzip
the archive file.
The place where down-loading and the decompression are done recommends C:\ or A:\. 

2.When the archive file is unzipped, the following file is obtained. 
-Upgrade program UPG5A.EXE
-Firmware file 117x107.HEX (1.07 is the version of the firmware)

3.  Please boot the MS-DOS 6.0 or later, or Windows 95/98 MS-DOS mode. 

* This program does not work in WindowsNT and Windows 95/98 DOS window. 
* When OS is Windows NT, please use MS-DOS 6.0 or later, or Windows 95/98
  start-up disks and start the MS-DOS mode.

[ MS-DOS mode start procedure by Windows 95/98 ]
  After starts Windows 95/98, "Exit" of Windows is selected from "Start" button. 
  Please select "Restart in the MS-DOS mode". 
  The computer goes to the MS-DOS mode. 

4. Please move the current directory to the directory which defrosts the file. 
   C:Please type and push Enter Key with "C" when defrosting to \. 
   Next, please type and push Enter Key with "Cd \". 
   When defrosting to the floppy disk, the floppy disk is inserted in the floppy 
   disk drive, and please type and push Enter Key with "A". 
   Next, please type and push Enter Key with "Cd \". 

5. Next, please type as follows and push Enter Key. 

   upg5a /n 117x107.HEX

   Please fill in the following only one numerical values on "n". 
   n=1 primary slave 
   n=2 secondary master
   n=3 secondary slave

   Please do not drop without not using the personal computer at all 
   until the firmware change is completed.
   Never turn off the power supply while upgrade is proceeding. 
   It causes the breakdown which cannot be recovered. 

6. When the firmware change is normally completed, the version of 
   the firmware is displayed. Please confirm this version. 

  We recommend that connect DVD-117 to secondary IDE with master setting
  and disconnecting all other CD/DVD units before executing upgrade of drive's
  firmware.
  When completing the upgrade, please once turn off the 
  power supply of the computer before use your PC.
