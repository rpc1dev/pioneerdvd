Drive:			Pioneer DVR-106/DVR-A06 (Dual format DVD+/- Burner)
Firmware Rev.:		v1.07
Patch:			RPC-1 (Region Free) + 2xDVD-R + 12xRip (pressed DVDs)
Date:			2003.09.22 - 23:03 GMT
Author:			>NIL:
Release Notes:		This is the release version of the 2x4all DVD-R 
			including the anti 2x Rip Speed limitation patch
			The 2xDVD-R patch DOES NOT alter the write strategy for
			Pioneer 2x authorized media, or any media that is burnt
			at 1x or 4x
			PROPER BURN OF 2X NON AUTHORIZED MEDIA IS NOT GUARANTEED!
Flashing Instructions:	Make sure you don't have Intel Application Accelerator
			installed. Then run UPGRADE.BAT.
			You shouldn't have to downgrade if you flash from Windows
Useful Links:		http://forum.rpc1.org/  	(See: DVD-R/RAM/+RW)
			http://pioneerdvd.rpc1.org/
Thanks to:		Flash, nicw, Gradius, zaitec2, Vlad & Igor...
