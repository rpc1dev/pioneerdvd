Drive:                  Pioneer DVR-108XL (Dual format 16x speed DVD+/-/DL Burner *XL*)
Also known as:          DVR-108XLA, DVR-108XLB, DVR-A08XLA, DVR-A08XLB, etc.
Firmware Rev.:          v1.18
Author:                 >NIL:
Date:                   2004.01.30 - 21:59 GMT (MY LAST FIRMWARE RELEASE EVER!!!)

                * * * * * * * * * * * * * * * * * * * * * *
                * * *   I M P O R T A N T   N O T E   * * *
                * * * * * * * * * * * * * * * * * * * * * *

Patched:                o RPC-1 (Region Free):
                          Remember, patching your drive to region free is only half
                          the job. A region free drive will not turn your system 
                          region free by itself. For more info, please read
                          http://forum.rpc1.org/viewtopic.php?t=239
                        o 12xRip (Unlimited ripping speed):
                          The official firmware from Pioneer limits the ripping 
                          speed on video discs. This limitation has been removed.
                          12x is only the maximum THEORETICAL speed that the drive
                          can achieve, but not the sustained speed you are likely to
                          get when ripping. Most DVD's will start ripping around 2x 
                          to 4x and end up around 8x or 10x. THIS is normal.
                        o nx4all : All speeds for -R/+R/+R9 media 
                          This firmware allows you to select ALL burning speeds on 
                          -R/+R/+R9 media. The official firmware from Pioneer only 
                          allows a limited set of Pioneer approved media to use these 
                          speeds but this patch removes that limitation. Write 
                          strategies for approved media should not be altered by the
                          patch.
                          PROPER BURN OF NON APPROVED MEDIA IS NOT GUARANTEED!
Not patched:            - Bitsetting (" Come back to your senses and Burn on -R media
                          instead, people!!!")
			- nx4all on RW media. Tests have shown that burning RW media
			  at higher than rated speed was a bad idea 
Flashing Instructions:  1/ Download the latest version of DVRFlash from
                        http://pioneerdvd.rpc1.org and extract the executable you 
                        need (Windows, DOS or Linux) in the directory where you 
                        extracted the patched firmwares
                        2/ READ THE DVRFLASH INSTRUCTIONS!!!
                        3/ If you are flashing from windows, and I: is your DVR-108
                        drive, open a DOS window and type a command like:
                          DVRFlash -v I: R8143108.118
                        or, *IF* you need to flash the kernel (Rebadged -> Pioneer):
                          DVRFlash -vf I: R8143008.118 R8143108.118
                        Alternatively, if all of the above looks too advanced to you
                        you can use the graphical user interface addon to DVRFlash
Useful Links:           http://forum.rpc1.org/          (DVD-R/RAM/+RW section)
                        http://pioneerdvd.rpc1.org/
Release notes:		This my last firmware release EVER!!!
Thanks to:              All of you out there who supported my work! It's been a great
                        3&1/2 years, but now's the time for me to say goodbye...
                        See you in another virtual universe! ;)

NB: This archive also contains a DVR-108XL kernel. 
DO NOT TRY TO FLASH AN STANDARD DRIVE WITH THIS FIRMWARE - IT IS ONLY MEANT FOR THE XL
