DVD-K11TA - RPC-1 ;) 
patch by >NIL: - 2001.10.14 

Upgrade procedure is as the following.

1. DVD-K11TA connect to Secondary IDE channel with master configuration.
2. Boot the PC with MS-DOS mode.
(Attention ! : Upgrade utility cannot work on MS-DOS window.)
3. Execute up.bat

This Floppy Disk includes the following files.

K11F105.HEX (Firmware file)
Note: This is actually not a v1.05 firmware, but a v1.03 RPC-1 disguised
The true v1.05 RPC-1 patch will come later on...
UPG4.EXE (Upgrade Utility)
UP.BAT (Upgrade Batch File)
README.TXT (This File)
