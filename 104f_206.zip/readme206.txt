****************************************************************************

   Region Free Firmware Upgrade Instructions (DVD-104S/DVD-A04S)
   -------------------------------------------------------------

 This firmware update will be convert your Pioneer DVD-104/04 drive in
 protectionless region-free drive! After update your drive name will
 become PIONEER DVD-104F Firmware version 2.06. This patch is based
 on original Pioneer firmware for DVD-104/04 version 2.06.

 Enjoy!!!

The Ripper

**************************************************************************

Firmware Upgrade Instructions(DVD-104S/DVD-A04S)

If you are not experiencing problems with your DVD-ROM drive, there 
is no need to upgrade your firmware.  For more information about 
what firmware revision your drive contains, look in the 
Device Manager in Windows 95/98.  To access the Device Manager,
click the start button, settings, control panel, system.  Click on 
the tab "Device Manager".  Click on the "+" next to the CD-ROM icon.  
Click on the appropriate Pioneer DVD-ROM drive you wish to update, 
then click the "Properties" tab.  Next click on the tab "settings".  On 
this tab is located the current firmware revision of this drive.


Steps to take before update process:
-Make sure the target DVD-ROM drive is free of any disc.
-Find out for which IDE bus the target DVD-ROM drive is configured.  
(Primary or Secondary)
-Find out whether the target DVD-ROM drive is set as a Master or Slave.
If you are uncertain as to how to find what IDE bus your DVD-ROM 
drive is connected to, consult your system builder.

1.  Download the appropriate zip file for the target DVD-ROM drive.
Recommended save locations are C:\ or A:\.(Because Directory names more 
than 8 characters are truncated in MS-DOS, it is recommended the 
name of the directory to which the zip file is saved be no longer
than 8 characters)

2.  Unzip the zip file.  Extract the unzipped files either to your 
Hard disk drive or floppy disk drive.  

Confirm the following files have been unzipped:
	Upgrade program........	UPG4A.EXE
	Firmware file..........	104F206.HEX 

3.  Enter DOS 6.0 or later/Windows 95/98 MS-DOS mode.(A Windows 95/98 DOS 
Window will not work properly)
	How to enter MS-DOS mode(in Winodws 95/98)
	Click the start button, shut down, restart in MS-DOS mode, then OK.  
	If running a pure Windows NT environment, use a DOS 6.0 or 
	later/Windows95/98 startup disk.

4.  Move to the directory to which the zip files were extracted.  
If the files are located at C:\, type "C:\" and press the ENTER key, then
type "cd \" and press the ENTER key.
You should now be at C:\

If the files are located at A:\, insert the floppy disk with the unzipped
files into your system and type "A:\" and press the ENTER key, then
type "cd \" and press the ENTER key.
You should now be at A:\

Firmware update command
Type the following and press the ENTER key at the end:

	UPG4A /n 104F206.HEX

  -/n will vary depending on which IDE bus the target DVD-ROM drive is 
configured for. Type one of the following, depending on which IDE bus 
(Primary/Secondary) and setting(Master/Slave)the target DVD-ROM drive 
is configured:
	n=1:	Primary Slave
	n=2:	Secondary Master
	n=3:	Secondary Slave
	**please make certain you choose the correct number**
If you are uncertain as to how to find what IDE bus your DVD-ROM drive is 
connected to, consult your system builder.  It is recommended to connect 
the DVD-104S/DVD-A04S to the secondary IDE as a Master and begin the update 
process.
  -In the xxx's, type the exact .HEX filename as the one downloaded.
Example:  Downloaded .HEX filename:  104F206.HEX
	  Command:  UPG4A /2 104F206.HEX
	(*CAUTION-This example has the drive set as Secondary Master)

The update process shall begin.  This may take a few minutes.
DO NOT operate your PC in any way(clicking the mouse buttons, typing on the 
keyboard, etc.)or turn off the power on your system during the update process. 
If the upgrade process is interrupted mid-transfer, it may result in an 
inoperable drive.

5.  After the process is completed, you shall be notified of a firmware 
revision.  Make certain this is the firmware revision you intended to use.

6. After this process has been completed, turn the power supply of your system 
OFF before using it again.