Drive:                  Pioneer DVR-107 (Dual format 8x speed DVD+/- Burner)
Also known as:          DVR-A07, DVR-107D, DVR-A07D, etc.
Firmware Rev.:          v1.18
Author:                 >NIL:
Date:                   2004.07.26 - 23:48 GMT 
Patched:                o RPC-1 (Region Free):
                          Remember, patching your drive to region free is only half
                          the job. A region free drive will not turn your system 
                          region free by itself. For more info, please read
                          http://forum.rpc1.org/viewtopic.php?t=239
                        o 12xRip (Unlimited ripping speed):
                          The official firmware from Pioneer limits the ripping 
                          speed on video discs. This limitation has been removed.
                          12x is only the maximum THEORETICAL speed that the drive
                          can achieve, but not the sustained speed you are likely to
                          get when ripping. Most DVD's will start ripping around 2x 
                          to 4x and end up around 8x or 10x. THIS is normal.
                        o nx4all : All *workable* speeds for all media!
                          This firmware allows you to select ALL burning speeds on 
                          ALL media. The official firmware from Pioneer only allows 
                          a limited set of Pioneer approved media to use these 
                          specific speeds but this patch removes that limitation. It
                          should NOT alter the write strategies for approved media 
                          however.
                          PROPER BURN OF NON APPROVED MEDIA IS NOT GUARANTEED!
Not patched:		- Bitsetting ("Burn on -R media instead, people!!!")
			- nx4all on +RW media. For the reason behind that, see:
			    http://forum.rpc1.org/viewtopic.php?p=108571
			  Tests showed that burning +RW media at higher speed than
			  the manufacturer recommended was a bad idea - ACCEPT IT!
Release Notes:          This firmware was used succesfully to burn *QUALITY* 4x +/-R
                        media at 6x and 8x speed and *QUALITY* 2x -RW media at 4x. 
                        If you are not sure whether the media you are using will 
                        burn properly at high speed, please look for other users 
                        experience at http://forum.rpc1.org 
                        AGAIN, HIGH SPEED BURN OF LOW GRADE MEDIA IS NOT GUARANTEED
Flashing Instructions:  1/ Download the latest version of DVRFlash from
                        http://pioneerdvd.rpc1.org and extract the executable you 
                        need (Windows, DOS or Linux) in the directory where you 
                        extracted the patched firmwares
                        2/ READ THE DVRFLASH INSTRUCTIONS!!!
                        3/ If you are flashing from windows, and I: is your DVR-107
                        drive, open a DOS window and type a command like:
                          DVRFlash -v I: R7100107.118
                        or, *IF* you need to flash the kernel (Rebadged -> Pioneer):
                          DVRFlash -vf I: R7100007.118 R7100107.118
                        Alternatively, if all of the above looks too advanced to you
                        you can use the graphical user interface addon to DVRFlash
Useful Links:           http://forum.rpc1.org/          (DVD-R/RAM/+RW section)
                        http://pioneerdvd.rpc1.org/
Thanks to:              Flash, Agent Smith and the generous contributor who sent 
                        me a DVR-107 drive ;�
                        Thanks should also go for Herrie who helped identify the 
                        best strategy for +R media

NB: The kernel file in this patch is just the 1.09 kernel firmware, with revision 
    bumped up. The binary data of the kernel is unmodified.