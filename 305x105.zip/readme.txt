Firmware Upgrade Instructions(DVD-305S/DVD-U05S)

Steps to take before update process:
-Make sure the target DVD-ROM drive is free of any disc.
-Set the drive ID to 0 via the jumper pin on the rear of the drive.
-Disable SCAM, Reconnect, and synchronous transfer on your SCSI card

-Because this update program uses ASPI manager, add a command line that 
enables ASPI manger into the CONFIG.SYS, if it is not already included.
Consult your SCSI card's user's manual for further explanation.
(Example of how to add ASPI manger to CONFIG.SYS for Adaptec AHA-2940)
	In Windows 95/98, open CONFIG.SYS with an editor, such as "Notepad"
	and type in the command line:
	DEVICE=C:\ASPI8DOS.SYS /D
	After entering the command line, save, then exit
* Please use caution when making changes to the CONFIG.SYS.  Back up the 
information contained within the CONFIG.SYS before attempting any changes.
* The file CONFIG.SYS is located at C:\.
* If running a pure Windows NT environment, use a DOS 6.0 or later/Windows
95 or 98 Startup Disk


1.  Download the appropriate zip file for the target DVD-ROM drive.
Recommended save locations are C:\ or A:\. (Because Directory names more
than 8 characters are truncated in MS-DOS, it is recommended the 
name of the directory to which the zip file is saved be no longer 
than 8 characters)

2.  Unzip the zip file.  Extract the unzipped files either to your
Hard disk drive or flopy disk drive.

Confirm the following files have been unzipped:
	VersionUp program	UPG5S.EXE
	Firmware file		305x105.HEX(105's refer to the firmware
	revision)

3.  Enter MS-DOS 6.0 or later/Windows 95/98 MS-DOS mode.(A Windows 95/98 
MS-DOS Window will not work properly)
	How to enter MS-DOS mode(in Winodws 95/98)
	Click the start button, shut down, restart in MS-DOS mode, then OK.  
	If running a pure Windows NT environment, use a DOS 6.0 or 
	later/Windows95/98 startup disk.

4.  Move to the directory to which the zip files were extracted.
If the files are located at C:\, type "C:\" and press the ENTER key, then 
type "cd \" and press the ENTER key.
You should now be at C:\

If the files are located at A:\, insert the floppy disk with the unzipped 
files into your system and type "A:\" and press the ENTER key, then 
type "cd \" and press the ENTER key.
You should now be at A:\

Firmware update command
Type the following and press the ENTER key at the end.
	UPG4S /0 305x105.HEX

	(*CAUTION-This example has the drive set for SCSI ID = 0)

The update process shall begin.  This may take a few minutes.
DO NOT operate your PC in any way(clicking the mous buttons, typing on the
keyboard, etc.) or turn off the power on your system druing the update process.
If the upgrade process is interrupted mid-transfer, it may result in an 
inoperable drive.

5.  After the process is completed, you shall be notified of a firmware 
revision.  Make certain this is the firmware revision you intended to use.

6. After this process has been completed, turn the power supply of your system 
OFF before using it again.

It is highly recommended to use an Adaptec brand SCSI board, ASPI manager, and
setting the DVD-305S/U05S SCSI ID = 0 when changing the firmware revision.
